/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/appl_exit.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/06 21:12:31 $
 *   $Revision: 1.2 $
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "globals.h"
#include "cookie.h"
#include "fsel.h"
#include "wsystem.h"

static int __CDECL (*icfs)( int f, ...);

int ApplExit( void) {
	int dum;

	/* lib conf */
	if( __confapp_buffer)
		free( __confapp_buffer);
	if( __confdef_buffer)
		free( __confdef_buffer);
	
	if( get_cookie( ICFS_COOKIE, (long*)&icfs))
		for( dum = 0; dum<MAX_ICON; dum++)
			if( __iconlist[dum]) (*icfs)( ICF_FREEPOS, dum);

	if( !(CONF(app)->flag & FLG_NOPAL))
		w_setpal( app.palette);
	free( app.palette);
	if( app.gdos)
		vst_unload_fonts( app.handle, 0);
	if( __bubble_quit != -1 ) {
		evnt.buff[0] = AP_TERM;
        evnt.buff[1] = (WORD)app.id;
        evnt.buff[2] = 0;
        appl_write( __bubble_quit, 16, evnt.buff);
	}
	v_clsvwk( app.handle);
	EvntClear( NULL);
	if( app.pipe) Mfree( app.pipe);
	if( app.mnbind) free( app.mnbind);
	return( appl_exit());
}
