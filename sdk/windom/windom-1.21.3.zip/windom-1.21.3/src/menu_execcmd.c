/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/menu_execcmd.c,v $
 *
 * CVS info:
 *   $Author: bereziat $
 *   $Date: 2003/07/17 15:36:14 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "scancode.h"

/* retourne 1 si la commmande a �t� ex�cut�, 0 sinon
   si win == NULL on travaille sur le menu du bureau
   Condition d'utilisation: l'entre du menu
   		doit contenir la s�quence espace-racourci clavier-espace
   		Les raccourcis claviers sont:
   			^=control
   			=alternate
   			=shift
   			A-Z,F1-F10
   			ESC,UNDO,HELP,TAB,BACK,DEL,HOME,INSERT
   		ex:
   			" I "
   			" ^C "
   			" UNDO "
   			" F3 "
   			" DEL "  etc ...
   		Les combinaison entre Shift, alternate, control ne sont
   		pas permis pour l'instant. 
   */

int menu_exec_cmd( WINDOW *win) {
	int titre, entre;
	char cmd[10], rac[10], *str, *p;
	OBJECT *menu;

	menu = win?win -> menu.root:app.menu;
	if( !menu) /* Y'a pas de menu */
		return 0;
	
	/* On transforme le scancode en cha�ne */
	GemCode2Ascii( evnt.keybd, evnt.mkstate, rac);

	if( *rac == '\0' || *rac == ' ')
		return 0;
		
	/* analyse du raccourci clavier */
	strcpy( cmd, " ");
	if( evnt.mkstate & K_ALT)
		strcat( cmd, "");
	else if( evnt.mkstate & K_CTRL)
		strcat( cmd, "^");
	else if( evnt.mkstate & K_RSHIFT || evnt.mkstate & K_LSHIFT)
		strcat( cmd, "");
	strcat( cmd, rac);
	strcat( cmd, " ");
	titre = entre = 3;
	
	while( menu[entre].ob_type != G_BOX)
		entre ++;
	
	while( 1) {
		do {
			entre ++;
			if( menu[entre].ob_type == G_BOX)
				break;
			if( menu[titre].ob_state & DISABLED ||
				menu[entre].ob_state & DISABLED )
				continue;
			
			str = ObjcString( menu, entre, NULL);
			p = strstr( str, cmd);
			if( p != NULL && str+1 != p) {
				ApplWrite( app.id, MN_SELECTED, titre, entre, ADR(menu), obj_root(menu,entre));
				return 1;
			}
		} while( !(menu[ entre].ob_flags & LASTOB));
		if( menu[ entre].ob_flags & LASTOB)
			return 0; /* Commande pas trouv� */
		titre ++;
	}
}
