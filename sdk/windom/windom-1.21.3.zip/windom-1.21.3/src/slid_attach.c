/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/slid_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/01 20:42:30 $
 *   $Revision: 1.3 $
 */

#include <stdlib.h>
#include "globals.h"

int slid_newpos( void *_slid) {
	SLIDER *slid = _slid;
	double norma, large;
	int new, ret;
	OBJECT *tree = ObjcTree( slid->mode, slid->win);

	/* No cursor in the slider, so we return 0 */	
	if( slid->bsld == -1)
		return 0;

	if (slid->ori == SLD_HORI) 
		large = (double)(tree[slid->bsld].ob_width - tree[slid->sld].ob_width - 2*SLID_OFFSET);
	else
		large = (double)(tree[slid->bsld].ob_height - tree[slid->sld].ob_height - 2*SLID_OFFSET);

	norma = (slid->value - slid->min) / (slid->max - slid->min);
	new = (int) (norma*large) + SLID_OFFSET;
	
	if (slid->ori == SLD_HORI) {
		ret = (new != tree[slid->sld].ob_x);
		tree[slid->sld].ob_x = new;
	} else {
		ret = (new != tree[slid->sld].ob_y);
		tree[slid->sld].ob_y = new;
	}
	return ret;
}

/* Les routines objets */

static void slid_up( WINDOW *win, int index, int mode, SLIDER *slid ) {
	int rdw;
	float old;
	INT16 dum, but;

	ObjcChange( mode, win, index, SELECTED, TRUE);
	do {
		graf_mkstate( &dum, &dum, &but, &dum);
		/* new value */
		old = slid->value;
		slid -> value = MAX( slid -> min, slid -> value - slid -> sinc);
		if( old == slid->value) continue;
		/* new slider position */
		rdw = slid_newpos( slid);
		if( slid->upd == SLD_IMME && slid->doslid)	
			(*slid->doslid)( win, mode, slid->value, slid->data);
		/* redraw object */
		if( rdw) ObjcDraw( mode, win, slid->bsld, MAX_DEPTH);	
	} while( but) ;
	if( slid->upd == SLD_DIFF && slid->doslid)	
		(*slid->doslid)( win, mode, slid->value, slid->data);
	ObjcChange( mode, win, index, ~SELECTED, TRUE);
}

static void slid_dn( WINDOW *win, int index, int mode, SLIDER *slid ) {
	int rdw;
	float old;
	INT16 dum, but;

	ObjcChange( mode, win, index, SELECTED, TRUE);
	do {
		graf_mkstate( &dum, &dum, &but, &dum);
		old = slid->value;
		slid -> value = MIN( slid -> max, slid -> value + slid -> sinc);
		if( old == slid->value) continue;
		rdw = slid_newpos( slid);
		if( slid->upd == SLD_IMME && slid->doslid)	
			(*slid->doslid)( win, mode, slid->value, slid->data);
		if( rdw) ObjcDraw( mode, win, slid->bsld, MAX_DEPTH);
	} while( but) ;
	if( slid->upd == SLD_DIFF && slid->doslid)	
		(*slid->doslid)( win, mode, slid->value, slid->data);	
	ObjcChange( mode, win, index, ~SELECTED, TRUE);
}

static void slid_bg( WINDOW *win, int index, int mode, SLIDER *slid ) {
	int rdw, dir, sel;
	INT16 xc, yc, xm, ym, dum, but;
	OBJECT *tree = ObjcTree( mode, win);
	float old = 0;
	
#define DIR_UP 0
#define DIR_DN 1

	UNUSED(index);
	/* get the direction */
	objc_offset( tree, slid->sld, &xc, &yc);
	graf_mkstate( &xm, &ym, &but, &dum);
	if( slid->ori == SLD_HORI) {
		dir = (xm < xc)?DIR_UP:DIR_DN;
		sel = (xm < xc)?slid->up:slid->dn;
	} else { 
		dir = (ym < yc)?DIR_UP:DIR_DN;
		sel = (ym < yc)?slid->up:slid->dn;
	}
	if( sel != -1) ObjcChange( mode, win, sel, SELECTED, TRUE);		
	do {
		graf_mkstate( &xm, &ym, &but, &dum);
		/* nouvelle valeur */
		if( dir == DIR_UP)
			slid -> value = MAX( slid -> min, slid -> value - slid -> linc);
		else
			slid -> value = MIN( slid -> max, slid -> value + slid -> linc);
		if( slid->value == old)
			continue;
		else
			old = slid->value;
		/* position objet */
		rdw = slid_newpos( slid);
		if( slid->upd == SLD_IMME && slid->doslid)	
			(*slid->doslid)( win, mode, slid->value, slid->data);
		/* redessin des objets */
		if( rdw) ObjcDraw( mode, win, slid->bsld, MAX_DEPTH);
	} while( but);
	if( sel != -1) ObjcChange( mode, win, sel, ~SELECTED, TRUE);
	if( slid->upd == SLD_DIFF && slid->doslid)	
		(*slid->doslid)( win, mode, slid->value, slid->data);
}

static void slid_sld( WINDOW *win, int index, int mode, SLIDER *slid ) {
	int rdw;
	INT16 xm, ym, xc, yc, but, dum;
	OBJECT *tree = ObjcTree( mode, win);
	double val;
	int dxm, dym;
	
	ObjcChange( mode, win, index, SELECTED, TRUE);

	if( app.aes4 & AES4_XGMOUSE) graf_mouse( M_SAVE, 0L);
	graf_mouse( FLAT_HAND, NULL);
	
	graf_mkstate( &xm, &ym, &but, &dum);
	objc_offset( tree, slid->sld, &xc, &yc);
	dxm = (xm - xc);
	dym = (ym - yc);

	do {
		graf_mkstate( &xm, &ym, &but, &dum);

		objc_offset( tree, slid->bsld, &xc, &yc);
		/* Position relative % bsld*/
		xm -= xc+1;
		ym -= yc+1;

		if( slid->ori == SLD_HORI) {
			xm -= dxm;
			if( xm < SLID_OFFSET) xm = SLID_OFFSET;
			if( xm > tree[slid->bsld].ob_width-tree[slid->sld].ob_width-2*SLID_OFFSET) 
				xm = tree[slid->bsld].ob_width-tree[slid->sld].ob_width-2*SLID_OFFSET;
			if( xm != tree[slid->sld].ob_x) {
				
				val = (slid->max - slid->min) / (tree[slid->bsld].ob_width - tree[slid->sld].ob_width - 2);
				/* IL FAUT ARRONDIR LE RESULTAT A UN MULTIPLE DE SINC */
				slid -> value = val * (double) xm + slid->min;
				slid -> value = MIN( slid -> value, slid -> max);
				slid -> value = MAX( slid -> value, slid -> min);

				rdw = slid_newpos( slid);
				if( slid->upd == SLD_IMME && slid->doslid)	
					(*slid->doslid)( win, mode, slid->value, slid->data);
				if( rdw) ObjcDraw( mode, win, slid->bsld, MAX_DEPTH);
			}
		} else {
			ym -= dym;
			if( ym < SLID_OFFSET) ym = SLID_OFFSET;
			if( ym > tree[slid->bsld].ob_height-tree[slid->sld].ob_height-2*SLID_OFFSET) 
				ym = tree[slid->bsld].ob_height-tree[slid->sld].ob_height-2*SLID_OFFSET;
			if( ym != tree[slid->sld].ob_y) {
				val = (slid->max - slid->min) / (tree[slid->bsld].ob_height - tree[slid->sld].ob_height - 2);
				slid -> value = val * (double) ym + slid->min;
				slid -> value = MIN( slid -> value, slid -> max);
				slid -> value = MAX( slid -> value, slid -> min);

				rdw = slid_newpos( slid);	
				if( slid->upd == SLD_IMME && slid->doslid)	
					(*slid->doslid)( win, mode, slid->value, slid->data);
				if( rdw) ObjcDraw( mode, win, slid->bsld, MAX_DEPTH );
			}
		}

		/* Pour ne pas �crouler la machine */
		evnt_timer( 100L); 
	} while( but);
	if( slid->upd == SLD_DIFF && slid->doslid)	
		(*slid->doslid)( win, mode, slid->value, slid->data);

	if( !(app.aes4 & AES4_XGMOUSE) || graf_mouse( M_RESTORE, 0L) == 0 )
		graf_mouse(ARROW,NULL);

	ObjcChange( mode, win, index, ~SELECTED, TRUE);	
}

/* Attache un slider a une structure d'objet */

void SlidAttach( void *_slid, int mode, WINDOW *win, int up, int bsld, int sld, int dn) {
	SLIDER *slid = _slid;

	/* Chaque objet recoit une routine sp�cifique */
	slid -> win = win;
	slid -> mode = mode;
	slid -> up = up;
	slid -> dn = dn;
	slid -> sld = sld;
	slid -> bsld = bsld;

	slid_newpos( slid);

	if( up != -1) ObjcAttach( mode, win, up, BIND_FUNC, slid_up, slid);
	if( dn != -1) ObjcAttach( mode, win, dn, BIND_FUNC, slid_dn, slid);
	if( bsld != -1) ObjcAttach( mode, win, bsld, BIND_FUNC, slid_bg, slid);
	if( sld != -1) ObjcAttach( mode, win, sld, BIND_FUNC, slid_sld, slid);
}
