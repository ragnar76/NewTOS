/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_string.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/04 19:51:09 $
 *   $Revision: 1.3 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "userdef.h"

#define PARM( ldata)	(((W_PARM *)(ldata))->wp_spec)


/*
 *	Retourne l'adresse du texte d'un objet (quelconque)
 *	->� pr�voir si on veut une compatibilit� totale
 *	  avec MyDials de reconnaitre les objets MyDials
 */

char *ObjcString( OBJECT *tree, int idx, char *put) {
	static char p[]="";
	USERBLK *user;
#ifdef MODIF_XEDIT
	W_XEDIT *xedit;
#endif

	switch ( tree[idx].ob_type & 0x00FF) {
	case G_BUTTON:
	case G_STRING:
	case G_TITLE:
		if( put)
			tree[idx].ob_spec.free_string = put;
		return( tree[idx].ob_spec.free_string);
			
	case G_TEXT:
	case G_BOXTEXT:
	case G_FTEXT:
	case G_FBOXTEXT:
		if( put)
			tree[idx].ob_spec.tedinfo->te_ptext = put;
		return (tree[idx].ob_spec.tedinfo->te_ptext);
	case G_ICON:
	case G_CICON:
		if( put)
			tree[idx].ob_spec.iconblk->ib_ptext = put;
		return (tree[idx].ob_spec.iconblk->ib_ptext);
	case G_USERDEF:
		switch ( (tree[idx].ob_type & 0xFF00)>>8) {
		case DCRBUTTON:
		case TITLEBOX:
		case UNDERLINE:
		case CIRCLEBUT:
		case ONGLET:
		case KPOPUPSTRG: /*  a v�rifier */
		case MENUTITLE:		
		case XFREESTR:
			user = tree[idx].ob_spec.userblk;
			if( put)
				(char*)((W_PARM*)user->ub_parm)->wp_spec = put;
			return ( (char*)((W_PARM*)user->ub_parm)->wp_spec);

#ifdef MODIF_XEDIT

		case XEDIT:
			xedit = (W_XEDIT *)tree[idx].ob_spec.userblk->ub_parm;
			if( put) {
				int size = (int) realloc_xedit( xedit->size, strlen(put)+1);
				if( size) {
					xedit->size = size;
					xedit->line = realloc( xedit->line, size);
				}
				strcpy( xedit->line, put);
			}
			xedit->flags = 0;
			xedit->curs = xedit->pos = 0;
			return xedit->line;

#endif

		case XTEDINFO:
			user = tree[idx].ob_spec.userblk;
			((TEDINFO *)PARM(user->ub_parm))->te_fontid = 0;			
			if( put)
				((TEDINFO *)PARM(user->ub_parm))->te_ptext = put;
			return ((TEDINFO *)PARM(user->ub_parm))->te_ptext;

		case XCICON:
			user = tree[idx].ob_spec.userblk;
			if( put)
				((ICONBLK *)user->ub_parm)->ib_ptext = put;
			return ((ICONBLK *)user->ub_parm)->ib_ptext;
		}
		break;
	}
	return (p);
}
