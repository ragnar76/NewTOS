/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_wdraw.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:01 $
 *   $Revision: 1.1 $
 */


#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 *	Dessine un objet dans une fen�tre (n'importe quelle fenetre)
 */

int ObjcWindDraw( WINDOW *win, OBJECT *tree, 
				  int index, int depth, int xclip, int yclip, 
				  int wclip, int hclip) {
	int res=0;
	GRECT r1, win_rect;

	graf_mouse( M_OFF, 0L);
	rc_set( &win_rect, xclip, yclip, wclip, hclip);
	wind_get( win->handle, WF_FIRSTXYWH, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
	while (r1.g_w && r1.g_h) {
		if ( rc_intersect( &win_rect, &r1)) 
			res = objc_draw( tree, index, depth, r1.g_x, r1.g_y, r1.g_w, r1.g_h);
		wind_get( win->handle, WF_NEXTXYWH, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
	}
	graf_mouse( M_ON, 0L);
	return res;
}
