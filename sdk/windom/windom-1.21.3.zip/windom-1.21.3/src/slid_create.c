/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/slid_create.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:57:43 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/* Cr�er une structure SLIDER */

void *SlidCreate( float min, float max, float sinc, float linc, float value,
					int ori, int upd) {
	SLIDER *slid = malloc( sizeof(SLIDER));

	if( !slid) return NULL; /* erreur d'allocation */
	slid -> min = min;
	slid -> max = max;
	slid -> sinc = sinc;
	slid -> linc = linc;
	slid -> ori = ori;
	slid -> upd = upd;
	slid -> value = MIN(MAX(value,min),max);
	slid -> doslid = NULL;
	slid -> data = NULL;
	slid -> win = NULL;
	return slid;
}
