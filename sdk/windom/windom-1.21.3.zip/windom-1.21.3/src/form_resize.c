/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_resize.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:22:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/* 
 * If a form has changed its size, this function computes the
 * new window size and parameters to host the form. 
 * If the window is already opened (eg created with FormCreate()
 * parameters x, y, w, h have no effect and can be set to NULL.
 * If the window is not yet open, x, y, w, h are filled with 
 * correct values for WindOpen().
 */
 
void FormResize( WINDOW *win, INT16 *x, INT16 *y, INT16 *w, INT16 *h) {
	OBJECT *tree = FORM(win);
	int outlined = 0;
	INT16 xi, yi, wi, hi, d;
	
	if( tree -> ob_state & OUTLINED)
		outlined = OUTLINED_WIDTH;

	/* Gestion des ascenseurs */
	graf_handle( &win -> w_u, &win -> h_u, x, x);
	win -> xpos = win -> ypos = 0;
	win -> xpos_max = (tree[0].ob_width+2*outlined)/win -> w_u;
	win -> ypos_max = (tree[0].ob_height+2*outlined)/win -> h_u;

	/* taille maxi */
	WindCalc( WC_BORDER, win, 0, 0, tree[0].ob_width+2*outlined, 
			  tree[0].ob_height+2*outlined, &xi, &xi, &wi, &hi);
	GrectCenter( wi, hi, &xi, &yi);
	win->w_max = wi;
	win->h_max = hi;

	/* Change window widget if form too big */
	if( wi >= app.w || hi >= app.h) {
		INT16 wx, wy, ww, wh;
		WindGet( win, WF_CURRXYWH, &wx, &wy, &ww, &wh);
		WindClose( win);
		wind_delete( win->handle);
		if( wi >= app.w)
			win->attrib |= HSLIDE|LFARROW|RTARROW|SIZER;
		if( hi >= app.h)
			win->attrib |= VSLIDE|DNARROW|UPARROW|SIZER;
		win->handle = wind_create( win->attrib, app.x, app.y, app.w, app.h);
		WindOpen( win, wx, wy, ww, wh);
	}

	if( win->status & WS_OPEN) {
		WindGet( win, WF_CURRXYWH, &xi, &yi, &d, &d);
		WindSet( win, WF_CURRXYWH, xi, yi, wi, hi);
		EvntRedraw( win);
	} 
	*x = xi;
	*y = yi;
	*w = wi;
	*h = hi;
}
