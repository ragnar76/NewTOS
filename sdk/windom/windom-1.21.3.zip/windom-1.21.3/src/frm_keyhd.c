/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frm_keyhd.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:18:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"
#include "scancode.h"
#include "userdef.h"

/*
 *	Routine de gestion du clavier
 */

void frm_keyhd( WINDOW *win) {
	W_FORM *form = DataSearch( win, WD_WFRM);
	OBJECT *dial;
	char scancode;
	int res, x2, y2;
	INT16 x, y;

	scancode = evnt.keybd >> 8;
	dial = form->root;
	
	/* Raccour�i claviers */
	
	if( (res = frm_keybd_ev( dial)) != -1)
		;
	else if ( scancode == SC_RETURN || scancode == SC_ENTER) 
		res = obj_fd_flag( dial, ROOTS, DEFAULT);
	else if( scancode == SC_UNDO) {
		res = obj_fd_xtype( dial, res, UNDOBUT);
		if( res == -1)
			res = obj_fd_flag( dial, res, FLAGS11);
	}
	else if( scancode == SC_HELP)
		res = obj_fd_xtype( dial, res, HELPBUT);
	else if (form->edit != -1) { 
		
		/* Gestion des Editables */
		
		/* passage au champ suivant */
		if ( scancode == SC_DWARW && evnt.mkstate == 0) {
			for( res=(form->edit+1)%form->nb_ob; (res % form->nb_ob) != form->edit; res++)
				if( (dial[res%form->nb_ob].ob_flags & EDITABLE) &&
					!(dial[res%form->nb_ob].ob_flags & HIDETREE))
					break;

			if ( res%form->nb_ob != form->edit) {
				ObjcEdit( OC_FORM, win, form->edit, 0, &form->cursor, ED_END);
				form->edit = res%form->nb_ob;
				form->cursor = 0;
				ObjcEdit( OC_FORM, win, form->edit, 0, &form->cursor, ED_INIT);
			}
		}
		/* passage au champ pr�c�dent */
		else if ( scancode == SC_UPARW && evnt.mkstate == 0) {
			res = form->edit-1;			
			while( res != form->edit) {
				if( res<0)
					res = form->nb_ob-1;
				if( (dial[res].ob_flags & EDITABLE) && !(dial[res].ob_flags & HIDETREE))
					break;
				res --;
			}
			if ( res != form->edit) {
				ObjcEdit( OC_FORM, win, form->edit, 0, &form->cursor, ED_END);
				form->edit = res;
				form->cursor = 0;
				ObjcEdit( OC_FORM, win, form->edit, 0, &form->cursor, ED_INIT);
			}
		}
		/* Sinon, insertion caractere */
		else 
			ObjcEdit( OC_FORM, win, form->edit, evnt.keybd, &form->cursor, ED_CHAR);
		res = -1;
	}

	if( res != -1) {
		objc_offset( dial, res, &x, &y);
		x2 = evnt.mx; y2 = evnt.my;
		evnt.mx = x + dial[res].ob_width/2-1;
		evnt.my = y + dial[res].ob_height/2-1;
		res = frm_buttn_ev( win, OC_FORM);
		if( res == -1)
			return ;
		evnt.mx = x2; evnt.my = y2;
		snd_msg( win, WM_FORM, res, evnt.mkstate, 0, 0);
	}
}
