/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frame_init.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 19:24:15 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include "globals.h"
#include "sliders.h"
#include "sliders.rh"
#include "sliders.rsh"

OBJECT * get_frame_slider ( void) {
	return rs_trindex[ FRAME_SLIDER];
}

void FrameInit( void) {
	OBJECT *tree = rs_trindex[FRAME_SLIDER];
	static int init = 1,i;
	
	if( init) {
		for( i=0; i<NUM_OBS; rsrc_obfix( rs_object, i++));
		init = 0;
	}
	if( CONF(app)->fwidsize != -1)
		__frame_set_widget( CONF(app)->fwidsize);

	/* monochrome resolution case (or less than 16 colors) */
	if( app.color < 16 ) {
		tree[M_V_PG].ob_spec.obspec.fillpattern = 1;
		tree[M_H_PG].ob_spec.obspec.fillpattern = 1;		
	}

	i = -1;
	do {
		i++;
		switch( tree[i].ob_type) {
		case G_BOXCHAR:
            align_obj3d( tree, i, 1);
			init_type( tree, i, ub_boxchar3d, 0);
			break;
		case G_BOX:
            align_obj3d( tree, i, 1);
			init_type( tree, i, ub_box3d, 0);
			break;
		} 
	} while ( !(tree[i].ob_flags & LASTOB)) ;

	__calc = FrameCalc;
	__swgt = set_gadget_pos;
	__rfrm = remove_frame_from_list;
}

void FrameExit( void) {
	OBJECT *tree = rs_trindex[FRAME_SLIDER];	
	int extype;
	int i = -1;

	do {
		i++;
		extype = tree[i].ob_type >> 8;
		if( extype == G_BOXCHAR || extype == G_BOX ) {
            align_obj3d( tree, i, 0);
			free_type( tree, i);
		}
	} while ( !(tree[i].ob_flags & LASTOB)) ;

}
