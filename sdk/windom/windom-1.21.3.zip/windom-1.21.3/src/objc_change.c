/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_change.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:08 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"


int ObjcChange( int mode, void *win, int index, int state, int redraw) {
	OBJECT *tree;
	int res = E_OK;
	
	switch( mode) {
	case OC_FORM:
		tree = FORM((WINDOW*)win);
		break;
	case OC_TOOLBAR:
		tree = TOOL((WINDOW*)win);
		break;
	case OC_OBJC:
		tree = (OBJECT *)win;
		redraw = redraw?2:3;
		break;
	case OC_MENU:
		tree = ((WINDOW*)win)->menu.root;
		break;
	default:
		return EBADRQ;
	}

	/* on filtre les �tats */
	if( (state & 0xFF00) == 0xFF00)  /* �tats du genre '~SELECTED' */
		state &= tree[ index].ob_state;
	else
		state = (tree[ index].ob_state & 0xFFC0) | (state & 0x003F);
	
	switch( redraw) {
	case 3:
	case 2:
		res = objc_change( tree, index, 0, app.x, app.y, app.w, app.h, state, (redraw==2)?1:0);
		break;
	case 1:
		ObjcWindChange( win, tree, index, app.x, app.y, app.w, app.h, state);
		break;
	case OC_MSG:
		tree[ index].ob_state = state;
		res = ObjcDraw( mode, win, index,  MAX_DEPTH | OC_MSG);
		break;
	case 0:
		res = objc_change( tree, index, 0, app.x, app.y, app.w, app.h, state, 0);
		break;
	}
	return res;
}

