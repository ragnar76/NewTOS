/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_create.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/04/18 20:07:42 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 *  This function creates and open easily at screen a 
 *	window form.
 */

WINDOW *FormCreate( OBJECT *tree, int GemAttrib, void *proc, char *nom, GRECT *taille, int grow, int dup) {
	register WINDOW *win = wglb.first;
	GRECT coord;
	INT16 x, y, w, h, dum;
	int outlined = 0;
	W_FORM *form;
	
	/* Case the window is already created */
	if( !dup)
	while( win) {
		if( win -> status & WS_FORM) {
			form = DataSearch( win, WD_WFRM);
			if( form->root == tree) {
				if( win -> status & WS_ICONIFY) {
					WindGet( win, WF_UNICONIFY, &x, &y, &w, &h);
					snd_msg( win, WM_UNICONIFY, x, y, w, h);
				} else if( win -> status & WS_OPEN) 
					/* window opened */
					wind_set( win -> handle, WF_TOP, 0, 0, 0, 0);
				else {
					wind_get( win->handle, WF_PREVXYWH, &x, &y, &w, &h);
					WindOpen( win, x, y, w, h);
				}
				return win;
			}
		}
		win = win -> next;
	}
	
	for( dum = 0; dum < 10; app.work_in[dum++] = 1);
	app.work_in[10] = 2;
	win = WindCreate( GemAttrib, app.x, app.y, app.w, app.h);
	if( win == NULL) return NULL;

	if( tree -> ob_state & OUTLINED)
		outlined = OUTLINED_WIDTH;

	if( !taille) {
		coord.g_w = tree->ob_width + 2*outlined;
		coord.g_h = tree->ob_height + 2*outlined;
		WindCalc( WC_BORDER, win, 0, 0, coord.g_w, coord.g_h, &x, &y, &coord.g_w, &coord.g_h);
		GrectCenter( coord.g_w, coord.g_h, &coord.g_x, &coord.g_y);

		/* Si le formulaire est trop grand, on force les
		 * assenceurs 
		 */

		if( coord.g_w >= app.w || coord.g_h >= app.h) {
			WindDelete( win);
			if( coord.g_w >= app.w)
				GemAttrib |= HSLIDE|LFARROW|RTARROW|SIZER;
			if( coord.g_h >= app.h)
				GemAttrib |= VSLIDE|DNARROW|UPARROW|SIZER;
			win = WindCreate( GemAttrib, app.x, app.y, app.w, app.h);
		}
	} else
		coord = *taille;
	
	win -> name = nom;
	if( grow) win -> status |= WS_GROW;
	WindOpen( win, coord.g_x, coord.g_y, coord.g_w, coord.g_h);
	FormAttach( win, tree, proc);
	form = DataSearch( win, WD_WFRM);

	/* Form have to be duplicated */
	if( dup) {
		win -> status |= WS_FORMDUP;
		form->root = ObjcDup( tree, win);
		if( form->root == NULL) {
			WindDelete( win);
			return 0;
		}	
	}

	WindSetStr( win, WF_NAME, nom);
	WindSet( win, WF_BEVENT, BEVENT_WORK, 0, 0, 0);
	WindSlider(win, HSLIDER|VSLIDER);
	return( win);
}
