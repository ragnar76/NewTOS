/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_open.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "av.h"

int WindOpen( WINDOW *win, int x, int y , int w, int h) {
	int res = 0;
	INT16 dum;
	INT16 _x;
	INT16 _y;

	add_windowlist( win->handle);
	if( app.avid != -1) ApplWrite( app.avid, AV_ACCWINDOPEN, win->handle,0,0,0,0);
	if( x == -1) {
		GrectCenter( w, h, &_x, &dum); x = _x;
	}
	if( y == -1) {
		GrectCenter( w, h, &dum, &_y); y = _y;
	}
	w = MAX( w, win->w_min);
	w = MIN( w, win->w_max);
	h = MAX( h, win->h_min);
	h = MIN( h, win->h_max);
	/* special effects are always optional */
	if( win -> status & WS_GROW && CONF(app)->weffect == TRUE)
		graf_growbox( 0, 0, 0, 0, x, y, w, h);
	res = wind_open( win->handle, x, y, w, h);
#ifdef WINDOMDEBUG
	if( res == 0) form_alert( 1, "[1][WINDOM warning:|Impossible to open a window.][Ok]");
#endif
	win->status |= WS_OPEN;
	wglb.appfront = win;
	WindSlider( win, HSLIDER|VSLIDER);
	return res;
}
