/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/remove_frame.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:03:52 $
 *   $Revision: 1.1 $
 */


#include <stdlib.h>
#include "globals.h"

int remove_frame_from_list( WINDOW *win, WINDOW *child) {
	FRAME *frame = DataSearch( win, WD_WFRA);
	WINDOW *scan = frame->list;
	WINDOW *prev = NULL;
	
	while( scan) {
		if( child && child == scan ) {
			/* on retire scan de la liste */
			if( prev == NULL)
				frame->list = scan -> next;
			else
				prev -> next = scan -> next;
			/* on remet a jour les variables de win->frame */
			frame->front = frame->list;
			/* pas fini */
			return 1;
		}
		prev = scan;
		scan = scan->next;
	}
	return 0;
}
