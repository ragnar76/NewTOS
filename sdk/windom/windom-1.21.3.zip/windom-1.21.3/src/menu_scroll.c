/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/menu_scroll.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:03 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

void MenuScroll( WINDOW *win, int dir) {
	INT16 x, y, w, h;
	OBJECT *menu = win->menu.root;

	wind_get( win->handle, WF_WORKXYWH, &x, &y, &w, &h);
	if( dir == 0) { /* RIGTH */
		if( menu[3+win->menu.scroll].ob_next != 2 ) {
			menu[3+win->menu.scroll].ob_flags |= HIDETREE;
			menu[3+win->menu.scroll].ob_state |= DISABLED;
			win -> menu.scroll ++;
			snd_msg( win, WM_REDRAW, x, y, w, menu[1].ob_height);
		}
	} else {
		if( win->menu.scroll > 0) {
			win -> menu.scroll --;
			menu[3+win->menu.scroll].ob_flags &= ~HIDETREE;
			menu[3+win->menu.scroll].ob_state &= ~DISABLED;
			snd_msg( win, WM_REDRAW, x, y, w, menu[1].ob_height);
		}	
	}
}
