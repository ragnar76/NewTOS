/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frm_drw.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:18:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

void frm_drw( WINDOW *win) {
	INT16 x, y, w, h;
	int outlined = 0;
	W_FORM	*dial = DataSearch( win, WD_WFRM);

	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	if( dial->root->ob_state & OUTLINED)
		outlined = OUTLINED_WIDTH;
	dial->root[ROOT].ob_x = x - (int)win->xpos * win->w_u + outlined;
	dial->root[ROOT].ob_y = y - (int)win->ypos * win->h_u + outlined;
	objc_draw( dial->root, ROOT, MAX_DEPTH, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
	/* Cas des champs �ditables */
	if ( dial->edit != -1) {
		wind_get( win -> handle, WF_TOP, &x, &y, &w, &h);
		if ( x == win -> handle)
			ObjcEdit( OC_FORM, win, dial->edit, 0, &dial->cursor, ED_INIT);
	}
}
