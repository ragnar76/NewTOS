/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/mouse_objc.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:11 $
 *   $Revision: 1.1 $
 */

#include "globals.h"

void MouseObjc( OBJECT *tree, int index) {
	INT16 x, y;
	long rec[2];
		
	objc_offset( tree, index, &x, &y);
	x += tree[index].ob_width/2-1;
	y += tree[index].ob_height/2-1;

	rec[0] = 2;
	rec[1] = (long)y + ((long)x << 16);
	appl_tplay( rec, 1, 100);
}


