/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/bubble_call.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:32:15 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"
#include "cookie.h"

/* code retour de la fonction:
	0, pas d'�rreur
	-1, bubble pas en m�moire
	-2, la variable d'environnement BUBBLE= est incorrecte
	-3, erreur d'allocation m�moire
 */

int BubbleCall( char *help, int x, int y) {
	INT16 msg[8];
	int bubble_id;
	long bubble_save;
	
	bubble_id = BubbleGet();

    if (bubble_id >= 0) {
		if( app.pipe == NULL) return -3;

		/* Config locale */
		get_cookie (BHLP_COOKIE, &bubble_save);
 		if( __bubble_conf != -1 ) set_cookie( BHLP_COOKIE, __bubble_conf);
 		
 		/* Requ�te fonte */
 		ApplWrite( bubble_id, BUBBLEGEM_FONT, CONF(app)->bubble.font, CONF(app)->bubble.size, 0, 0, 0);
	
		/* Affichage de la bulle */
		strcpy( app.pipe, help);
		ApplWrite( bubble_id, BUBBLEGEM_SHOW, x, y, ADR(app.pipe),  BGS7_MOUSE);
 		
 		/* Attente accus� de reception, max, une seconde d'attente */
 		AvWaitfor( BUBBLEGEM_ACK, msg, 1000);

        /* Restauration config */
        set_cookie( BHLP_COOKIE, bubble_save);
        return 0;
    }
    return bubble_id;
}
