/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/bubble_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:32:16 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

int BubbleAttach( OBJECT *tree, int index, char *help) {
	struct bubble *b=bubble_index;
	
	if( b == NULL) {
		b = (struct bubble *)malloc(sizeof(struct bubble));
		if( b == NULL) return -1; /* erreur */
		b->tree=tree;
		b->index=index;
		b->help=help;
		b->next=NULL;
		bubble_index = b;
	} else {
		while( b->next) b = b->next;
		b->next = (struct bubble *)malloc(sizeof(struct bubble));
		if( b->next == NULL) return -1; /* erreur */
		b->next->tree=tree;
		b->next->index=index;
		b->next->help=help;
		b->next->next=NULL;
	}
	return 0;
}
