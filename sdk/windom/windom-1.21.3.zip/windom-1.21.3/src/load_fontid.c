/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/load_fontid.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:06 $
 *   $Revision: 1.1 $
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "globals.h"

int load_fontid( void) {
	FILE *fconf( char *path, char *name);
	FILE *fp;
	char *p, *q;
	int i;
	char path[255];

	fp = fopen( "fontid", "r");
	if( !fp) {
		shel_envrn( &p, "ETCDIR=");
		if( p) {
			strcpy( path, p);
			strcat( path, "\\fontid");
			fp = fopen( path, "r");
		}
	}
	if( !fp) {
		shel_envrn( &p, "HOME=");
		if( p) {
			strcpy( path, p);
			strcat( path, "Defaults\\fontid");
			fp = fopen( path, "r");
		}
	}
	if( !fp) {
		shel_envrn( &p, "FONTDIR=");
		if( p) {
			strcpy( path, p);
			strcat( path, "\\fontid");
			fp = fopen( path, "r");
		}
	}
	if( !fp)
		fp = fopen( "C:\\gemsys\\fontid", "r");

	if( fp) {
		char buf[LINE_SIZE];
		int count = 0;
		
		/* Compte des entr�es */
		while( fgets( buf, LINE_SIZE, fp)) {
			if( *buf == '#' ||
				*buf == '\n')
				continue;
			count ++;
		}
		rewind( fp);
		maxfontid = count;
		listfontid = (struct fontid *)malloc( sizeof(struct fontid)*count);
		if( !listfontid) {
			fclose( fp);
			return -69;	/* memory error */
		}

		/* Puis lecture */
		while( fgets( buf, LINE_SIZE, fp)) {
			if( *buf == '#' ||
				*buf == '\n')
				continue;

			/* format ligne : num "Name" id flags */

			sscanf( buf, "%d", &i);
			p = strchr( buf, '"');
			if( p && i < maxfontid) {
				q = strchr( p+1, '"');
				if( q) {
					*q = '\0';
					strcpy( listfontid[i].name, p+1);
					sscanf( q+1, "%d %x", &listfontid[i].id, &listfontid[i].flags);
				}
			}
				/* ELSE : Erreur de format */
		}
		
		return maxfontid - 1;
	} else {
		/* La fonte syst�me est toujours dispo */
		listfontid = (struct fontid *)malloc( sizeof(struct fontid));
		if( !listfontid) {
			maxfontid = 2;
			strcpy( listfontid[0].name, "system font");
			listfontid[0].id = 1;
			listfontid[0].flags = FNT_MONO;
		}
		
		return -33;	/* file not found */
	}
}
