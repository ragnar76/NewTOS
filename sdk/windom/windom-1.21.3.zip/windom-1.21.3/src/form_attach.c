/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:22:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 *	On attache un formulaire � une fen�tre
 */

int FormAttach( WINDOW *win, OBJECT *tree, void *proc) {
	W_FORM *form;

	/* Attach a form */
	if( tree != NULL) {
		int outlined=0;
		INT16 dum, x, y;

		form = (W_FORM *)malloc( sizeof(W_FORM));
		if( !form) return ENSMEM;
		
		/* A form was already attached */
		if( win->status & WS_FORM)	
			FormAttach( win, NULL, NULL);
	
		if( tree -> ob_state & OUTLINED)
			outlined = OUTLINED_WIDTH;

		EvntAttach( win, WM_REDRAW, frm_drw);
		EvntAttach( win, WM_FORM, proc);
		EvntAttach( win, WM_MOVED, frm_mvd);
		EvntAttach( win, WM_TOPPED, frm_tpd);
		EvntAttach( win, WM_FULLED, frm_fld);
		EvntAttach( win, WM_XBUTTON, frm_click);
		EvntAttach( win, WM_XKEYBD, frm_keyhd);
		EvntAdd	  ( win, WM_DESTROY, frm_dstry, EV_TOP);
		
		DataAttach( win, WD_WFRM, form);
		win->status |= WS_FORM;

		form->root = tree;
		form->real = tree;
		form->save = NULL;
		form->bind = NULL;
		form->edit = obj_fd_flag( tree, 0, EDITABLE);
		
		/* Num�ro du premier TEDINFO, -1 s'il n'y en a pas */
		form->cursor = 0;		  
		
		/* Position curseur */
		/* if( form->edit != -1) */
		/* Nombre d'objets dans le dialogue */
		form->nb_ob = obj_nb( tree);
		
		/* Index de l'objet racine */
		WindGet( win, WF_WORKXYWH, &x, &y, &dum, &dum);
		form->root->ob_x = x - (int)win->xpos * win->w_u + outlined;
		form->root->ob_y = y - (int)win->ypos * win->h_u + outlined;
		
		/* Gestion des ascenseurs */
		graf_handle( &win -> w_u, &win -> h_u, &dum, &dum);
		win -> xpos = win -> ypos = 0;
		win -> xpos_max = (tree[0].ob_width+2*outlined)/win -> w_u;
		win -> ypos_max = (tree[0].ob_height+2*outlined)/win -> h_u;

		/* taille maxi */
		WindCalc( WC_BORDER, win, 0, 0, tree[0].ob_width+2*outlined, 
				  tree[0].ob_height+2*outlined, &x, &x, &win->w_max, &win->h_max);
	} else {
		/* On lib�re le formulaire de la fen�tre */	
			
		form = DataSearch( win, WD_WFRM);

		RsrcUserFree( form->root);
		if( form->bind) free( form->bind);
		if( form->save) free( form->save);
		if( win->status & WS_FORMDUP) ObjcFree( form->root);
		DataDelete( win, WD_WFRM);
		free( form);

		win -> status &= ~WS_FORM;

		EvntAttach( win, WM_REDRAW, WindClear);
		EvntRemove( win, WM_DESTROY, frm_dstry);
		EvntDelete( win, WM_FORM);
		EvntAttach( win, WM_MOVED, std_mvd);
		EvntAttach( win, WM_TOPPED, std_tpd);
		EvntDelete( win, WM_XKEYBD);

		win -> xpos = win -> ypos = 0;
		win -> xpos_max = win -> ypos_max = 1;
	}
	return 0;
}
