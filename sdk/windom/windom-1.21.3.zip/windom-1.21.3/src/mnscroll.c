/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/mnscroll.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/19 20:30:39 $
 *   $Revision: 1.5 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

#include "mnscroll.h"
#include "mnscroll.rh"
#include "mnscroll.rsh"

void init_scroll_menu( void) {
	int dum;
	for( dum=0; dum<NUM_OBS; rsrc_obfix( rs_object, dum++));
}
/*  Menu en fenetres */

/* Cette fonction dessine la barre de menu - Elle sera appell�
	automatiquement par evnt_windows lors d'un �v�nement REDRAW */

void menu_draw(WINDOW *win, int xc, int yc, int wc, int hc) {
	OBJECT *menu;
	INT16 xy[4], x, y, w, h, i;

	wind_get( win->handle, WF_WORKXYWH, &x, &y, &w, &h);
	menu = win -> menu.root;
	menu->ob_x = x;
	menu->ob_y = y;
	menu[1].ob_width  = w;
	if( CONF(app)->flag & FLG_MNSCRL) {
		/*	D�caler le menu */
		for( i = 0; i < win->menu.scroll; i++)
			menu->ob_x -= menu[3+i].ob_width;
	
		/* Devrait aller dans WindSet */
		menu[0].ob_width = 10000;
		menu[1].ob_width = 10000;
		menu[2].ob_width = 10000;
		/* --------------------- */
		objc_draw( menu, 1, 2, xc, yc, wc, hc);
		
		rs_trindex[MNSCROLL][MENULF].ob_flags =  menu[1].ob_flags;
		rs_trindex[MNSCROLL][MENURT].ob_flags =  menu[1].ob_flags;
		rs_trindex[MNSCROLL]->ob_height =  menu[1].ob_height;

		/* Afficher les scrolls */
		if( win->menu.scroll > 0)
			rs_trindex[MNSCROLL][MENULF].ob_state &= ~DISABLED;
		else
			rs_trindex[MNSCROLL][MENULF].ob_state |= DISABLED;
		
		if( menu[3+win->menu.scroll].ob_next != 2 )
			rs_trindex[MNSCROLL][MENURT].ob_state &= ~DISABLED;
		else
			rs_trindex[MNSCROLL][MENURT].ob_state |= DISABLED;

		rs_trindex[MNSCROLL]->ob_y = y;
		rs_trindex[MNSCROLL]->ob_x = x;
		objc_draw( rs_trindex[MNSCROLL], 0, 1, xc, yc, wc, hc);
	} else
		objc_draw( menu, 1, 2, xc, yc, wc, hc);

	vsl_color( app.handle, BLACK);
	vsl_width( app.handle, 1);
	vsl_type( app.handle, 1);
	xy[0] = xc; xy[1] = yc;
	xy[2] = xc + wc - 1;
	xy[3] = yc + hc - 1;
	vs_clip( app.handle, 1, xy);
	objc_offset( menu, 1, &xy[0], &xy[1]);
	xy[ 1] += menu[1].ob_height;		/* +1 pour la ligne */
	xy[ 2] = xy[0] + menu[1].ob_width - 1;
	xy[ 3] = xy[ 1];
	v_pline( app.handle, 2, xy);
	vs_clip( app.handle, 0, xy);
}

/*
 *  Cette fonction g�re le menu d'une fenetre - elle sera appell�
 *	automatiquement par evnt_windows lors d'un click souris dans
 *	une fenetre menu. Retourne -1 si on a selectionn� aucun
 *	titre.
 */

int frm_menu( WINDOW *win) {
	int title;
	int item;
	int index, box;
	OBJECT *menu;
	INT16 x, y, w, h, xob, yob;
	INT16 mx, my, mbut, mkey;
	INT16 msg[8], ev;
	INT16 dum;
	MFDB fond;
	short ob_x, ob_y;

	menu = win -> menu.root;
	wind_get( win->handle, WF_WORKXYWH, &x, &y, &w, &h);

	if( CONF(app)->flag & FLG_MNSCRL) {
		rs_trindex[MNSCROLL] -> ob_x = x;
		rs_trindex[MNSCROLL] -> ob_y = y;

		title = objc_find( rs_trindex[MNSCROLL], 0, MAX_DEPTH, evnt.mx, evnt.my);
		switch( title) {
		case MENURT:
			MenuScroll( win, 0);
			return -1;
		case MENULF:
			MenuScroll( win, 1);
			return -1;
		}
	}

	while( !wind_update( BEG_MCTRL));

	/* on attend qu'on relache le bouton */
	
	do
		graf_mkstate( &evnt.mx, &evnt.my, &evnt.mbut, &evnt.mkstate);
	while( evnt.mbut);


	title = objc_find( menu, 0, MAX_DEPTH, evnt.mx, evnt.my);
	if( title == -1 || !is_title(menu,title)) {
		wind_update( END_MCTRL);
		return -1;
	}

	item = -1;
	title = -1;
	box = 0;
	do {
		ev = 
		evnt_multi( MU_TIMER|MU_BUTTON, 1, 1, 1,
					0,0,0,0,0,
					0,0,0,0,0,
					msg,
					0L,
					&mx, &my, &mbut, &mkey,
					&dum, &dum);
		
		/***********************************************/
				
		index = objc_find( menu, 0, MAX_DEPTH, mx, my);
		if( index == -1 || menu[index].ob_type == G_BOX)
			continue;

		if( is_title(menu, index)
			&& !(menu[ index].ob_state & DISABLED)
			&& index != title) 	/* on change de menu d�roulant */
		{
			if( mx<x || mx>x+w-1 || my <y || my>y+h-1)
				continue;
			if( wind_find( mx, my) != win->handle)
				continue;
			if( title !=-1)	/* Un menu est-il deja s�lectionn� ? */
			{				/* on ferme le menu pr�cedent */
				if( item != -1) 
					objc_change( menu, item, 0, x, y, w, h, NORMAL, 0);
				box = GetIndexMenu( menu, title);
				objc_offset( menu, box, &xob, &yob);
				w_put_bkgr( xob-10, yob-10, menu[box].ob_width+20, menu[box].ob_height+20, &fond);
				objc_offset(menu, title, &ob_x, &ob_y);
				menu[title].ob_state &= ~SELECTED;
				ObjcWindDraw( win, menu, 1, 2, ob_x, ob_y, menu[title].ob_width, menu[title].ob_height);
			}
			title = index;
			objc_offset(menu, title, &ob_x, &ob_y);
			menu[title].ob_state |= SELECTED;
			ObjcWindDraw( win, menu, 1, 2, ob_x, ob_y, menu[title].ob_width, menu[title].ob_height);
			box = GetIndexMenu( menu, title);
			objc_offset( menu, box, &xob, &yob);
			w_get_bkgr( xob-10, yob-10, menu[box].ob_width+20, menu[box].ob_height+20, &fond);
			objc_draw( menu, box, MAX_DEPTH, xob-10, yob-10, 
					   menu[box].ob_width+20, menu[box].ob_height+20);
			if( win->menu.hilight) 
				(*win->menu.hilight)( win, title, -1);
		} else { 
			
			/* on change d'entr�e de menu */
			
			index = objc_find( menu, box, MAX_DEPTH, mx, my);
			if( item != -1 && item != index 
				&& !(menu[item].ob_state & DISABLED)) {
				objc_offset(menu, item, &ob_x, &ob_y);
				menu[item].ob_state &= ~SELECTED;
				objc_draw( menu, box, 2, ob_x, ob_y, menu[item].ob_width, menu[item].ob_height);
			}
			if( index != -1 && index != item
				&& !(menu[index].ob_state & DISABLED)) {
				objc_offset(menu, index, &ob_x, &ob_y);
				menu[index].ob_state |= SELECTED;
				objc_draw( menu, box, 2, ob_x, ob_y, menu[index].ob_width, menu[index].ob_height);
				if( win->menu.hilight)
					(*win->menu.hilight)( win, title, index);
			}
			item = index;

		}
	} while( ! (ev & MU_BUTTON));

	if( item != -1 && !(menu[item].ob_state & DISABLED))
		for( dum=0; dum < CONF(app)->menu_effect; dum++)
		{
			evnt_timer( 50L);
			objc_change( menu, item, 0, xob, yob,menu[box].ob_width, 
					 	 menu[box].ob_height, NORMAL, 1);
			evnt_timer( 50L);
			objc_change( menu, item, 0, xob, yob,menu[box].ob_width, 
					 	 menu[box].ob_height, SELECTED, 1);
		}
	
	if(box)
		w_put_bkgr( xob-10, yob-10, menu[box].ob_width+20, menu[box].ob_height+20, &fond);

	do
		graf_mkstate( &mx, &my, &mbut, &mkey);
	while( mbut);

	wind_update( END_MCTRL);
	
	if( item != -1 && !(menu[item].ob_state & DISABLED) ) {
		objc_change( menu, item, 0, x, y, w, h, NORMAL, 0);
	} else 
		item = -1;

	/* R�sultat du traitement envoy� � l'AES */
	ApplWrite( app.id, MN_SELECTED, title, item, ADR(menu), obj_root(menu,item));
	return 0;
}


#ifdef BETAMENU
#define WMNU 678

static void click_menu( WINDOW *win) {

}

static WINDOW *open_menu( WINDOW *root, int index) {
	WINDOW *win;
	GRECT coord;
	OBJECT *tree;

	tree = MENU(root);
	coord.g_x = tree[index].ob_x;
	coord.g_y = tree[index].ob_y;
	coord.g_w = tree[index].ob_width;
	coord.g_h = tree[index].ob_height;
	win = FormCreate( &tree[index], 0, NULL, "", &coord, 0, 0);
	DataAttach( win, WMNU, root);
	EvntAttach( win, WM_XBUTTON, click_menu);
	win->type = WMNU;
	return win;
}

static void close_menu( WINDOW *win) {
	DataDelete( win, WMNU);
	EvntExec( win, WM_DESTROY);
}

int frm_menu_beta( WINDOW *win) {
	int title, item;
	int index, box, ev;
	OBJECT *menu;
	INT16 x, y, w, h;
	EVNTvar old;
	WINDOW *wbox = NULL;
	int EvntWindom( int);
	int ObjcChange( int, void*, int, int, int);
		
	menu = win -> menu.root;
	wind_get( win->handle, WF_WORKXYWH, &x, &y, &w, &h);


	while( !wind_update( BEG_MCTRL));
	index = objc_find( menu, 0, MAX_DEPTH, evnt.mx, evnt.my);

	if( CONF(app)->flag & FLG_MNSCRL) {
		rs_trindex[MNSCROLL] -> ob_x = x;
		rs_trindex[MNSCROLL] -> ob_y = y;

		switch( index) {
		case MENURT:
			MenuScroll( win, 0);
			return -1;
		case MENULF:
			MenuScroll( win, 1);
			return -1;
		}
	}


	/* wait for mouse-button unpressed */	
	do
		graf_mkstate( &evnt.mx, &evnt.my, &evnt.mbut, &evnt.mkstate);
	while( evnt.mbut);


	if( index == -1 || !is_title( menu, index)) {
		if( menu->ac_title != -1) {
			/* invalider le menu */
			menu->ac_title = -1
		}
		
		wind_update( END_MCTRL);
		return -1;
	}

	item = -1;
	title = -1;
	box = 0;
	old = evnt;

	do {

		ev = EvntWindom( MU_MESAG | MU_BUTTON);
		
		if( ev & MU_BUTTON) {
		
			index = objc_find( menu, 0, MAX_DEPTH, evnt.mx, evnt.my);
			if( index == -1)	continue;
		
			/* on change de menu d�roulant */
			if( is_title(menu, index)
				&& !(menu[ index].ob_state & DISABLED)
				&& index != title) {
				if( evnt.mx<x || evnt.mx>x+w-1 || evnt.my<y || evnt.my>y+h-1)
					continue;
				if( wind_find( evnt.mx, evnt.my) != win->handle)
					continue;
			
				/* Un menu est-il deja selectionne? */
				if( title != -1)	{
					/* on ferme le menu pr�cedent */
					if( item != -1)
						objc_change( menu, item, 0, x, y, w, h, NORMAL, 0);
					box = GetIndexMenu( menu, title);
					close_menu( wbox);
					ObjcWindChange( win, menu, title, x, y, w, h, NORMAL);
				}
				ObjcWindChange( win, menu, index, x, y, w, h, SELECTED);
				title = index;
				box = GetIndexMenu( menu, title);
				wbox = open_menu( menu, box);
			} else { 
			
				/* on change d'entr�e de menu */
			
				index = objc_find( menu, box, MAX_DEPTH, evnt.mx, evnt.my);
				if( item != -1 && item != index 
					&& !(menu[item].ob_state & DISABLED))
					ObjcChange( OC_FORM, wbox, item, NORMAL, 1);
				if( index != -1 && index != item
					&& !(menu[index].ob_state & DISABLED))
					ObjcChange( OC_FORM, wbox, index, SELECTED, 1);
				item = index;
			}
		}
		graf_mkstate( &evnt.mx, &evnt.my, &evnt.mbut, &evnt.mkstate);
	} while( !evnt.mbut);

	/* Effet de clignotement */
	if( item != -1 && !(menu[item].ob_state & DISABLED)) {
		int dum;

		for( dum=0; dum < CONF(app)->menu_effect; dum++) {
			evnt_timer( 50L);
			ObjcChange( OC_FORM, wbox, item, NORMAL, 1);
			evnt_timer( 50L);
			ObjcChange( OC_FORM, wbox, item, SELECTED, 1);
		}
	}
	if(box)
		close_menu( wbox);
	do
		graf_mkstate( &evnt.mx, &evnt.my, &evnt.mbut, &evnt.mkstate);
	while( evnt.mbut);

	wind_update( END_MCTRL);
	evnt = old;
	
	if( item != -1 && !(menu[item].ob_state & DISABLED) )
		objc_change( menu, item, 0, x, y, w, h, NORMAL, 0);
	else 
		item = -1;

	/* R�sultat du traitement envoy� � l'AES */
	ApplWrite( app.id, MN_SELECTED, title, item, ADR(menu), obj_root(menu,item));
	return 0;
}
#endif
