/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/vq_xaaes.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/07/21 19:52:53 $
 *   $Revision: 1.2 $
 */

#include <gem.h>

/********************* MagiC Binding ************************/

/*
 *	Get the number version of Xaaes
 */

int vq_xaaes( void) {
	short version;
   	short have_XaAES = wind_get(0, WF_XAAES, &version, 0L, 0L, 0L);
	return have_XaAES?version:0;
}

