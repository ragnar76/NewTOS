/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/snd_mubutton.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:57:42 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/* Appel de Bubble depuis un formulaire
 * bloquant.
 *	-1 : bubble pas en m�moire
 *	-2 : impossible
 *	-3 : erreur m�moire
 *	-4 : version version de Bubble ne supportant pas 
 *		 l'appel en formulaire bloquant
 */
  

void snd_mu_button( int mbut, int nbclick) {
	long rec[2];

	rec[0] = 1;
	rec[1] = (long)nbclick + ((long)mbut << 16);
	appl_tplay( rec, 1, 100);
}

