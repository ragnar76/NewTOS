/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/galloc.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:18:46 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"
#include "cookie.h"

/*
 *	Malloc pour GEM (mode partageable)
 *  Modif d'Arnaud (calqu� sur le ldg_Malloc, plus efficace et fonctionnel)
 */

#define MGLOBAL	0x20

void *Galloc( long size) {
	long val;
	static int type_mxalloc = -1;
	
	if (type_mxalloc < 0) {
		unsigned short v = Sversion();
		if ( (v & 0xff) || (v > 0x1900) ) { /* GEMDOS > 0.19 */
			if ( get_cookie (MAGX_COOKIE, &val) || get_cookie (MiNT_COOKIE, &val))
				type_mxalloc = 2;  /* Mxalloc avec MGLOBAL */
			else
				type_mxalloc = 1;  /* Mxalloc sans MGLOBAL */
		} else
			type_mxalloc = 0; /* Malloc */
	}
	
	switch (type_mxalloc) {
	case 0 : return (void*)Malloc( size);
	case 1 : return (void*)Mxalloc( size, 3);
	case 2 : return (void*)Mxalloc( size, 3|MGLOBAL);
	}
	
	/* ne devrait jamais arriver */
	return NULL;
}
