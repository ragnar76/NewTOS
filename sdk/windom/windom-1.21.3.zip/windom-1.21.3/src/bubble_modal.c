/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/bubble_modal.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:10:04 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "cookie.h"

int BubbleModal( char *hlp, int mx, int my) {
	BGEM *bgem;
	BHLP bhlp;
	INT16  dummy;
	int bmask, bstate, bclicks, ev;
	int bubble_id = appl_find( "BUBBLE  ");
	long bubble_save;

	if( bubble_id == -1)
		return -1;

	if( get_cookie( BGEM_COOKIE, (long*)&bgem)) {
    	/* Demander de la m�moire pour la communication */
		if( app.pipe == NULL) return -3;
		strcpy( app.pipe, hlp);
		
		/* Config locale */
		get_cookie (BHLP_COOKIE, &bubble_save);
 		if( __bubble_conf != -1 ) set_cookie( BHLP_COOKIE, __bubble_conf);

 		/* Requ�te fonte */
 		ApplWrite( bubble_id, BUBBLEGEM_FONT, CONF(app)->bubble.font, CONF(app)->bubble.size, 0, 0, 0);

		/* Envoi message a Bubble */
		ApplWrite( bubble_id, BUBBLEGEM_SHOW, mx, my, ADR(app.pipe), BGS7_USRHIDE);
		evnt_timer( 10L);

		/* en mode modal, � nous de g�rer certaines choses ... */
		graf_mkstate( &dummy, &dummy, &evnt.mbut, &dummy);
        if( (evnt.mbut & 0x3) == 0) {
			bclicks = 258;
			bmask = 3;
			bstate = 0;
		} else {
			bclicks = 0;
            bmask = 3;
            bstate = 0;
		}
		/* forme de la souris */
		graf_mouse(USER_DEF,bgem->mhelp);
     	ev = evnt_multi( MU_KEYBD|MU_BUTTON|MU_M1, 
     					 bclicks, bmask, bstate, 
     					 1, mx-6, my-6, 13, 13, 
     					 0, 0, 0, 0, 0, evnt.buff,
						 0L,
          				 &evnt.mx, &evnt.my,  &evnt.mbut, 
          				 &evnt.mkstate, &evnt.keybd, 
          				 &evnt.nb_click);
        		/* attente */
        if( !get_cookie( BHLP_COOKIE, (long*)&bhlp))
       		bhlp.delay = 200;
		evnt_timer( bhlp.delay);
		/* fin protocole */
        ApplWrite( bubble_id, BUBBLEGEM_HIDE, 0, 0, 0, 0, 0);
        graf_mouse( ARROW, NULL);
        /* Restauration config */
        set_cookie( BHLP_COOKIE, bubble_save);
        if( ev & MU_KEYBD)
        	ApplWrite( app.id, AP_KEYBD, evnt.mkstate, evnt.keybd, 0, 0, 0);
        if( ev & MU_BUTTON)
       	/*	ApplWrite( app.id,  AP_BUTTON, evnt.mx, evnt.my, 
       				   evnt.mbut, evnt.mkstate, evnt.nb_click); */
       		snd_mu_button( evnt.mbut, evnt.nb_click);
        return 0;
	} else {
		/* erreur : ne fonctionne qu'avec un d�mon
					donc depuis bubble 06 et qui
					correspond a l'apparition du 
					cookie 'BGEM' */
		return -4;
	}
}
