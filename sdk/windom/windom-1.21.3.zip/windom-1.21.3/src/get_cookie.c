/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/get_cookie.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/09/11 19:29:09 $
 *   $Revision: 1.2 $
 */

#ifdef __PUREC__
	/* Pure C poss�de des librairies non standard */
	#include <tos.h>
#else
	/* Gnu C, Sozobon, Lattice */
#ifdef __SOZOBONX__
#include <atari.h>  /* MUST be included before osbind.h */
#endif
	#include <osbind.h>
	#include <fcntl.h>
#endif
#include <stdio.h>
#include <stdlib.h>

#ifdef __MINTLIB__
#include <mint/cookie.h>
#endif

#include "globals.h"

/* Une version mieux de get_cookie() */

int get_cookie (long cookie, long *p_value) {
#ifdef __MINTLIB__
	/* Mintlib has Getcookie() with Ssystem support 
	 * Getcookie() returns 0 (success) or EERROR (not found)
	 */
	if (Getcookie(cookie,p_value) == 0)
		return 1;
	return 0;
#else
	long *cookiejar = (long *)Supexec (__cookieptr);
	if (!cookiejar) return 0;

	do {
		if (cookiejar[0] == cookie) {
			if (p_value) *p_value = cookiejar[1];
			return 1;
		}
		cookiejar += 2;
	} while (cookiejar[-2]);

	return 0;
#endif
}
