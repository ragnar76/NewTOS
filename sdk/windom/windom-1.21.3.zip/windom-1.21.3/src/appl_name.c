/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/appl_name.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:37:43 $
 *   $Revision: 1.1 $
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "globals.h"
#include "cookie.h"
#include "fsel.h"
#include "wsystem.h"

/* A faire: ApplGetinfo() et ApplName() */

int ApplName( char *name, int id) {
	INT16 i,m=0x0F;

	if( app.aes4 & AES4_APPSEARCH) {
		if( appl_search(APP_FIRST, name, &m, &i) == 0) {
			*name = '\0';
			return 0;
		}
		if( i == id)
			return 1;
		while( appl_search(APP_NEXT, name, &m, &i)) {
			if( i == id )
				return 1;
		}
	}
	*name = '\0';
	return 0;
}

