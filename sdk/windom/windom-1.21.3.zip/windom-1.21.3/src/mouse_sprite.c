/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/mouse_sprite.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:10 $
 *   $Revision: 1.1 $
 */

#include "globals.h"

void MouseSprite( OBJECT *tree, int index) {
	MFORM mform;
	int dum;
	
	dum = tree[index].ob_spec.iconblk->ib_char;
	mform . mf_nplanes = 1;
	mform . mf_fg = (dum>>8)&0x0F;
	mform . mf_bg = dum>>12;	
	mform . mf_xhot = 0; /* pour �viter que l'animation */
	mform . mf_yhot = 0; /* ne joue � z�bulon */

	for( dum = 0; dum<16; dum ++) {
		mform . mf_mask[dum] = tree[index].ob_spec.iconblk->ib_pmask[dum];
		mform . mf_data[dum] = tree[index].ob_spec.iconblk->ib_pdata[dum];
	}
	graf_mouse( USER_DEF, &mform);
}

