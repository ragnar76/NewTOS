/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_wchange.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:02 $
 *   $Revision: 1.1 $
 */


#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 *	Change l'�tat d'un objet dans une fen�tre (n'importe quelle fenetre)
 */

int ObjcWindChange( WINDOW *win, OBJECT *tree, int index, int x, int y, int w, int h, int state) {
	GRECT r1, r2;
	int res=0;
	int prev_state = tree[index].ob_state;
	
	wind_get( win->handle, WF_FIRSTXYWH, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
	rc_set( &r2, x, y, w, h);
	graf_mouse( M_OFF, 0L);
	while( r1.g_w && r1.g_h) {
		if ( rc_intersect( &r2, &r1)) {
			tree[index].ob_state = prev_state;
			res = objc_change( tree, index, 0, r1.g_x, r1.g_y, r1.g_w, r1.g_h, state, TRUE);
		}
		wind_get( win->handle, WF_NEXTXYWH, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
	}
	graf_mouse( M_ON, 0L);
	return res;
}

