/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/xrsrc.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/01 20:37:19 $
 *   $Revision: 1.3 $
 */


#ifdef MODIF_XEDIT
#include <string.h>
#endif
#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "userdef.h"
#include "cicon.h"
#include "wsystem.rh"
#include "wsystem.rsh"

/* note: ce module n'a pas �t� d�coup� en plusieurs fichiers. Il faut d'abord
   rendre les userdef ind�pendants de windom pour en faire une lib (dynamique?)
   ind�pendante */
   
/* Variables locales et priv�es
 */

static XRSRCFIX     __iconsys;        /* fixe les icones couleurs internes */

/*    Fonctions externes
 */
WORD __CDECL ub_button    ( PARMBLK *pblk);
WORD __CDECL ub_boxtitle  ( PARMBLK *pblk);
WORD __CDECL ub_xboxchar  ( PARMBLK *pblk);
WORD __CDECL ub_onglet    ( PARMBLK *pblk);
WORD __CDECL ub_boxcircle ( PARMBLK *pblk);
WORD __CDECL ub_but3D     ( PARMBLK *pblk);
WORD __CDECL ub_ulinetext ( PARMBLK *pblk);
WORD __CDECL ub_popuptext ( PARMBLK *pblk);
WORD __CDECL user_draw    ( PARMBLK *pblk);
WORD __CDECL ub_mntitle   ( PARMBLK *pblk);
WORD __CDECL ub_dialmover ( PARMBLK *pblk);
WORD __CDECL ub_editable  ( PARMBLK *pblk);
WORD __CDECL ub_but3d     ( PARMBLK *pblk);
WORD __CDECL ub_multiligne( PARMBLK *pblk);
WORD __CDECL ub_box3d     ( PARMBLK *pblk);
WORD __CDECL ub_ibox3d    ( PARMBLK *pblk);
WORD __CDECL ub_boxchar3d ( PARMBLK *pblk);
WORD __CDECL ub_boxtext3d ( PARMBLK *pblk);

#ifdef MODIF_XEDIT
size_t realloc_xedit( size_t old, size_t len);
#endif

#define        FL3DMASK    0x0600    /* 3D objects AES 3.4    */

/*
 *    TEST : realigne les objects 3D pour
 *           le bug du clippage
 *         mode = 1 : aligne l'objet
 *                0 : desaligne
 *    Il faut penser aussi au OUTLINED, SHADOW et aux
 *    objets a bords variables (boxchar, ...).
 */

void align_obj3d( OBJECT *tree, int idx, int mode) {
    int border, e;

    /* notation: border < 0 : outside border */
    /*           border > 0 : inside  border */

    switch (tree[idx].ob_type & 0xFF)
    {
        case G_BOXTEXT :
            border = tree[idx].ob_spec.tedinfo->te_thickness & 0x00FF;
            if (border >= 128) border = border - 256 ;
            break;
        case G_BOX :
        case G_IBOX:
        case G_BOXCHAR:
            border = tree[idx].ob_spec.obspec.framesize;
            break;
        default:
            border = -1;
            if( tree[idx].ob_flags & EXIT) border --;
            if( tree[idx].ob_flags & DEFAULT) border --;
    }

    /* le probleme ne concerne que les cadres � bord ext�rieurs  */
    /* si l'objet � traiter � les bords vers l'int�rieur, il n'y */
    /* � rien � faire (pourquoi ? explication juste en dessous)  */
    if (border>=0) return;
    
    /* Voici maintenant ce que vont subir les objets � bord   */
    /* "ext�rieurs" : lors de l'installation (mode!=0), les   */
    /* dimensions de l'objets sont agrandies pour englober    */
    /* les bordures, et les objets fils sont d�cal�s d'autant */
    /* par rapport � cet objet p�re pour qu'ils conservent    */
    /* la m�me position absolue dans le formulaire.           */
    /* SUBTILITE: le champ "border" est cependant conserv�    */
    /* n�gatif. Les routines userdef devront donc traiter les */
    /* bords ext�rieurs comme �tant des bords int�rieurs !    */
    /* RESTAURATION: avec mode=0, les bords ext�rieurs sont   */
    /* consid�r�s comme des bords int�rieurs car ils ont      */
    /* subits la transformation d�crite au dessus. Pour       */
    /* revenir � la configuration initiale, il suffit de      */
    /* remettre en place les anciennes coordonn�es de l'objet */
    /* et de restaurer les positons ob_x/y des objets fils.    */
    
    if( mode == 0) mode =  1;
    else           mode = -1;

    tree[idx].ob_x -= (border*mode);
    tree[idx].ob_y -= (border*mode);
    tree[idx].ob_width  += ((border<<1)*mode);
    tree[idx].ob_height += ((border<<1)*mode);

    /* on modifie d'autant le ob_x/y des enfants */
    for (e=tree[idx].ob_head; (e>=0) && (e!=idx); e=tree[e].ob_next) {
        tree[e].ob_x += (border*mode);
        tree[e].ob_y += (border*mode);
    }
}

/*
 *    Attribution de routine userdefs
 *        -> Utilisees par RsrcXtype() et les frames
 */

void init_type( OBJECT *tree, int idx, void *func, int extype) {
    USERBLK *user;

    user = (USERBLK *)malloc( sizeof(USERBLK));
    user -> ub_parm = (long)malloc( sizeof(W_PARM));
    user -> ub_code = func;
    ((W_PARM*)user -> ub_parm) -> wp_type = tree[idx].ob_type;
    ((W_PARM*)user -> ub_parm) -> wp_spec = tree[idx].ob_spec.index;
    tree[idx].ob_spec.userblk = user;
    tree[idx].ob_type = G_USERDEF | (extype<<8);
}

void free_type( OBJECT *tree, int idx) {
    long addr;
    int type;

    type = ((W_PARM*)tree[idx].ob_spec.userblk->ub_parm)->wp_type;
    addr = ((W_PARM*)tree[idx].ob_spec.userblk->ub_parm)->wp_spec;
    free( (void*)tree[idx].ob_spec.userblk->ub_parm);
    free( tree[idx].ob_spec.userblk);
    tree[idx].ob_spec.index = addr;
    tree[idx].ob_type = type;
}

#ifdef MODIF_XEDIT

/* 
 * M�me fonction que init_type() mais concerne les objets XEDIT
 */

static void init_xedit( OBJECT *tree, int idx) {
	USERBLK* user = (USERBLK *)malloc( sizeof(USERBLK));
	W_XEDIT* xedit = (W_XEDIT*)malloc( sizeof(W_XEDIT));
	
	user -> ub_parm = (long)xedit;
	user -> ub_code = ub_editable;

	xedit -> size = (int)realloc_xedit( 0, strlen(tree[idx].ob_spec.tedinfo->te_ptext)+1);
	xedit -> line = malloc( xedit->size*sizeof(char));
	strcpy( xedit -> line, tree[idx].ob_spec.tedinfo->te_ptext);
	xedit -> tedinfo = tree[idx].ob_spec.tedinfo;
	xedit -> pos = 0;
	xedit -> curs = xedit -> blcbeg = 0;
	xedit -> flags = 0;
	xedit -> wp_type = tree[idx].ob_type;
	tree[idx].ob_spec.userblk = user;
	tree[idx].ob_type = G_USERDEF | (XEDIT<<8);
}

/* 
 * M�me fonction que free_type() mais concerne les objets XEDIT
 *	peut-etre on fera une recopie partielle du buffer de W_XEDIT
 *	dans le TEDINFO ...
 */

static void free_xedit( OBJECT *tree, int idx) {
	W_XEDIT *xedit;
	void *user;
	
	xedit = (W_XEDIT *)tree[idx].ob_spec.userblk->ub_parm;
	user = tree[idx].ob_spec.userblk;
	tree[idx].ob_spec.tedinfo = xedit->tedinfo;
	tree[idx].ob_type = xedit->wp_type;
	free( xedit);
	free( user);
}
#endif


/*
 *    Interface avec WinDom
 */

/* les objets systemes sont definis
 * statiquement dans le fichier WSYSTEM.RSH
 * cette fonction permet au reste de la librarie
 * d'atteindre ces objets */

OBJECT *__xtype_trindex( int idx) {
    return (rs_trindex[idx]);
}

/*
 *    Fixer les type etendus
 *    principe:
 *        le ob_spec pointe maintenant sur une structure USERBLK
 *        le type etendu vaut le type normal (on garde la valeur)
 *        le type normal vaut G_USERDEF
 *        ub_code pointe sur la nouvelle fonction
 *        ub_parm vaut null ou pointe sur du texte pour les
 *            objets contenant du texte
 */

static void objc_extended( int mode, OBJECT *tree) {
    register int idx;
    int type, extype;
    int _is_menu = 0;

    /* on ne traite pas les menus... trop dangereux ! */
    for( idx=0; ; idx++) {
        if ( (tree[idx].ob_type == G_TITLE) ||
             (tree[idx].ob_type >> 8) == MENUTITLE )
            _is_menu=1;
        if( tree[idx].ob_flags & LASTOB) break;
    }

    for( idx=0; ; idx++) {
        type = tree[idx].ob_type & 0x00FF;
        extype = tree[idx].ob_type >> 8;
        if( type == G_USERDEF)
            continue;

        if (mode & 0x01) { /* fix extended type only if (mode & 0x01) */
	        switch( extype) {
	        case DCRBUTTON:
	            align_obj3d( tree, idx, 1);
	            init_type( tree, idx, ub_button, extype);
	            break;
	        case TITLEBOX:
	            init_type( tree, idx, ub_boxtitle, extype);
	            break;
	        case UNDERLINE:
	            init_type( tree, idx, ub_ulinetext, extype);
	            break;
	        case CIRCLEBUT:
	            init_type( tree, idx, ub_boxcircle, extype);
	            break;
	        case ONGLET:
	            init_type( tree, idx, ub_onglet, extype);
	            break;
	        case KPOPUPSTRG:
	            init_type( tree, idx, ub_popuptext, extype);
	            break;
	        case SLIDEPART:
	 /*           init_type( tree, idx, ub_xboxchar, extype); */
                align_obj3d( tree, idx, 1);
	            init_type( tree, idx, ub_boxchar3d, extype);
	            break;
	        case MENUTITLE:
	            init_type( tree, idx, ub_mntitle, extype);
	            break;
	        case DIALMOVER:
	            init_type( tree, idx, ub_dialmover, extype);
	            break;
#ifdef MODIF_XEDIT
	        case XEDIT:
	            init_xedit( tree, idx);
	            break;
#endif
	        case XBOXLONGTEXT:
	            align_obj3d( tree, idx, 1);
	            init_type( tree, idx, ub_multiligne, extype);
	            break;

	        case XTEDINFO:
	            align_obj3d( tree, idx, 1);
	            init_type( tree, idx, ub_boxtext3d, extype);
	            break;
	        }
	     }
	     
	     if ((mode & 0x02) && (extype==0)) {
            if (_is_menu) 
                ;  /* ne rien faire... trop dangereux... */
            else if ((tree[ idx].ob_state & DRAW3D) || (tree[ idx].ob_flags & FL3DMASK)) {
                /* Transformation des objets 3D standards en userdef */
				tree[ idx].ob_state |= DRAW3D;  /* force flag DRAW3D */
                switch( type) {
                case G_BUTTON:
                    align_obj3d( tree, idx, 1);
                    init_type( tree, idx, ub_but3d, XFREESTR);
                    break;
                case G_BOX:
                    align_obj3d( tree, idx, 1);
                    init_type( tree, idx, ub_box3d, XBFOBSPEC);
                    break;
                case G_IBOX:
                    align_obj3d( tree, idx, 1);
                    init_type( tree, idx, ub_ibox3d, XBFOBSPEC);
                    break;
                case G_BOXCHAR:
                    align_obj3d( tree, idx, 1);
                    init_type( tree, idx, ub_boxchar3d, XBFOBSPEC);
                    break;
                case G_BOXTEXT:
                	/* normalement, un objet G_BOXTEXT ne peut pas */
                	/* �tre �ditable (dans ce cas, c'est un FBOXTEXT) */
                	/* mais pour �tre sur... (anciennement MODIF_DOM) */
					if( !(tree[idx].ob_flags & EDITABLE)) {
	                    align_obj3d( tree, idx, 1);
    	                init_type( tree, idx, ub_boxtext3d, XTEDINFO);
					}
                    break;
                }
                /* supression des flags 3d pour que l'AES ne fasse pas */
                /* des trucs 3d dans notre dos */
                tree[ idx].ob_flags &= ~FL3DMASK;
            }
        }
/* DOM : J'ai un truc a dire la dessus */
#if 0 /* anciennement #if !( MODIF_ARNAUD ) */
        if( extype == 0 && type == G_BUTTON && tree[ idx].ob_state & DRAW3D) {
            align_obj3d( tree, idx, 1);
            init_type( tree, idx, ub_but3D, 0);
        }
      /* Les boutons qui ont le drapeaux Draw3D sont des userdefs, c'est
       * pour la compatibilit� MyDial, mais bon c'est pas important car
       * c'est redondant avec le type 18. et il y a le mode 0x2 de
       * RsrcXtype()
       * Il faut donc changer la doc (tutorial)
       */
#endif
        if( tree[idx].ob_flags & LASTOB) break;
    } 
}

static void objc_extfree( OBJECT *tree) {
    int idx = 0;

    for( idx=0; ; idx++) {
        if( (tree[idx].ob_type & 0x00FF) != G_USERDEF && !(tree[idx].ob_flags & LASTOB))
            continue;
        switch( (tree[idx].ob_type >> 8) )
        {
        case DCRBUTTON:
        case XFREESTR:
        case XTEDINFO:
        case XBFOBSPEC:
        case SLIDEPART:
            free_type( tree, idx);
            align_obj3d( tree, idx, 0);
			break;
        case TITLEBOX:
        case UNDERLINE:
        case CIRCLEBUT:
        case ONGLET:
        case KPOPUPSTRG:
        case MENUTITLE:
        case DIALMOVER:
        /* case ... */
            free_type( tree, idx);
            break;
#ifdef MODIF_XEDIT
		case XEDIT:
			free_xedit( tree, idx);
#endif
        }
#if 0  /* !(MODIF_ARNAUD) */
        if( (tree[idx].ob_type >> 8) == 0
            && (tree[idx].ob_type & 0x00FF) == G_USERDEF
            && tree[ idx].ob_state & DRAW3D )
        {
            free_type( tree, idx);
            align_obj3d( tree, idx, 0);
        }
#endif
        if( tree[idx].ob_flags & LASTOB) break;
    }
}

/*
 *   mode : fixe ou lib�re les objets AES "userdef"
 *   mode & 0x01 : fixe les types �tendus
 *   mode & 0x02 : fixe les objets 3D
 *   mode = 0    : lib�re les types �tendus et les objets 3D
 */

void RsrcXtype( int mode, OBJECT **trindex, int num_tree) {
    OBJECT *tree;
    int dum, num;
    static int init=0;

    /*    Fixer les icones couleurs systeme */
    if( (mode & 0x01) && (init==0) ) { /* 1er appel */
        for( dum=0; dum<NUM_OBS; rsrc_obfix( rs_object, dum++));
        RsrcFixCicon( rs_object, NUM_OBS, NUM_CIB, rgb_palette, &__iconsys);
    }
    if( (init==1) && !(mode & 0x01) )
        RsrcFreeCicon(  &__iconsys);

    if( mode & 0x01)
        init++;
    else
        init--;

    num = (trindex == NULL)?app.ntree:num_tree;
    for( dum = 0; dum < num; dum ++) {
        if( trindex == NULL)
            rsrc_gaddr( 0, dum, &tree);
        else
            tree = trindex[dum];
        if( mode)
            objc_extended( mode, tree);
        else
            objc_extfree( tree);
    }
}

/* EOF */



