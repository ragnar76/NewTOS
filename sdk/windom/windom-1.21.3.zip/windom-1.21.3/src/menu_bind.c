/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/menu_bind.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:05 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

void menu_bind( WINDOW *win, int item, int title) {
	BIND *bind = win?win->menu.bind:app.mnbind;
	
	if( item != -1 && bind) {
		if( bind[item].var) {
			*(bind[item].var) ^= bind[item].bit;
			MenuIcheck( win, item, (*(bind[item].var) & bind[item].bit)?1:0);
		}
		if( bind[item].fnc) {
			void (*f)( WINDOW *,int, int, int, void *);
		
			f = bind[item].fnc;
			(*f)( win, item, OC_MENU, title, bind[item].data);
		}
	}
}
