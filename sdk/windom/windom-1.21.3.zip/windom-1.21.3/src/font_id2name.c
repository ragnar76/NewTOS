/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/font_id2name.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:26:00 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"

int FontId2Name( int id, char *name) {
	int  i, scan;
	
	for( i=0; i<app.gdos; i++) {
		scan = VqtName(app.handle,i,name);
		if( id == scan)
			return 0; /* OK, name contient le nom de la fonte */
	}
	return -1;	/* Pas trouv� */
}

