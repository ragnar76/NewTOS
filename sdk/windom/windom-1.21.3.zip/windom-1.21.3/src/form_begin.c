/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_begin.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:22:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

void FormBegin( OBJECT *tree, MFDB *bckgrnd) {
	INT16 x, y, w, h;
	
	/* form_center( tree, &x, &y, &w, &h); */
	GrectCenter( tree->ob_width, tree->ob_height, &x, &y);
	tree->ob_x = x;
	tree->ob_y = y;
	w = tree->ob_width;
	h = tree->ob_height;
	
	if( bckgrnd)	/* On sauvegarde le fond */
		w_get_bkgr( x-6, y-6, w+11, h+11, bckgrnd);
	else
		form_dial( FMD_START, 0, 0, 0, 0, x-6, y-6, w+11, h+11);
	if( CONF(app)->weffect == TRUE || CONF(app)->weffect == DEFVAL)
		form_dial( FMD_GROW, 0, 0, 0, 0, x, y, w, h);
	while( !wind_update( BEG_MCTRL));
	objc_draw( tree, 0, MAX_DEPTH, x-6, y-6, w+11, h+11);
}

