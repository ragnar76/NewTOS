/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/rsrc_userdraw.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:23:27 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include "globals.h"
#include "userdef.h"

#define MASK_STATE		(DISABLED|CROSSED|CHECKED|OUTLINED|SHADOWED)

#define grect2xy(a,b) grect_to_array((GRECT*)a,b)

static INT16 tab[12];	/* utilis� par v_plines() */
static GRECT r1, r2;		/* pour user_draw */

/*
 *    Insertion d'une routine utilisateur
 */

/*
 *	Routine userdef pour dessiner n'importe nawak : n'est pas
 *  attribu� par le principe des types �tendus mais par la
 *  fonction 
 *		set_user_draw( OBJECT *tree, int index, void (*user)(WINDOW *), GRECT *clip)
 *	
 */

static WORD  __CDECL user_draw( PARMBLK *pblk) {
	USER_DRAW *udraw;
	void (*f)( WINDOW *, PARMBLK *, void *);

	/* R�cup�rer la routine */
	udraw = (USER_DRAW *)pblk->pb_parm;
	f = udraw -> draw;
	/* Rectangle de masquage */
	rc_set( &r1, pblk -> pb_xc, pblk -> pb_yc, pblk -> pb_wc, pblk -> pb_hc);
	rc_set( &r2, pblk -> pb_x, pblk -> pb_y, pblk -> pb_w, pblk -> pb_h);
	if( rc_intersect( &r1, &r2)) {
   		grect2xy( &r2, tab);
		vs_clip( udraw->win->graf.handle, 1, tab);
		/* ex�cuter la routine */
		(*f)( udraw->win, pblk, udraw->data);
		vs_clip( udraw->win->graf.handle, 0, tab);
	}
	return (pblk->pb_currstate & MASK_STATE);
}


int RsrcUserDraw( int mode, WINDOW *win, int index, void *draw, void *data) {
    USERBLK *user;
    USER_DRAW *udraw;
    OBJECT *tree = (mode == OC_FORM)?FORM(win):TOOL(win);

    user = (USERBLK *)malloc( sizeof(USERBLK));
    if( user == NULL) return ENSMEM;
    udraw = (USER_DRAW *)malloc(sizeof(USER_DRAW));
    if( udraw == NULL) {
        free( user);
        return ENSMEM;
    }
    udraw -> win  = win;
    udraw -> draw = draw;
    udraw -> data = data;
    user->ub_code = user_draw;
    user->ub_parm = (long)udraw;
    tree[index].ob_type = G_USERDEF | (USERDRAW << 8);
    tree[index].ob_spec.userblk = user;
    return 0;
}
