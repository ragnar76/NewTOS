/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frame_create.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/01 20:42:30 $
 *   $Revision: 1.5 $
 */


#include <stdlib.h>
#include "globals.h"
#include "sliders.h"

#define TOPPED_ACTIV	0x0004	/* internal */

static void set_frame( INT16 xy[8], int x, int y, int w, int h) {
	xy[8]=xy[0]=x;
	xy[9]=xy[1]=y;
	xy[2]=x+w-1;
	xy[3]=y;
	xy[4]=xy[2];
	xy[5]=y+h-1;
	xy[6]=x;
	xy[7]=xy[5];
}

static void update_scrolls( WINDOW *win) {
	INT16 x,y,w,h;
	INT16 xc,yc,wc,hc;
	
	wind_get( win -> handle, WF_CURRXYWH, &xc, &yc, &wc, &hc); /* instead of WindGet() -- see BUG below */
	WindCalc( 1, win, xc, yc, wc, hc, &x, &y, &w, &h);

	if( w >= win -> xpos_max * win -> w_u)
		win -> xpos = 0;
	else
		win -> xpos = MIN( win -> xpos, win -> xpos_max - w / win -> w_u);

	if( h >= win -> ypos_max * win -> h_u)
		win -> ypos = 0;
	else
		win -> ypos = MIN( win -> ypos, win -> ypos_max - h / win -> h_u);
	WindSlider(win,HSLIDER|VSLIDER);
}

/* redraw subroutine */
/* KNOW BUG: recursive call of WindGet doesn't seems to work properly,
   maybe a VA_ARG issue...
   => that's why we use wind_get instead of WindGet */

static void frame_draw( WINDOW *win) {
	FRAME *frame = DataSearch( win, WD_WFRA);
	WINDOW *scan = frame->list;
	INT16 xy[10];
	INT16 xc, yc, wc, hc, i;
	GRECT r1, oldclip;
	
	wind_get( win -> handle, WF_CURRXYWH, &xc, &yc, &wc, &hc); /* instead of WindGet() */
	WindCalc( 1, win, xc, yc, wc, hc, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);

	/* background */
	if( !(frame->flags & NO_BACKGROUND) ){
		xy[0]=r1.g_x;xy[1]=r1.g_y;
		xy[2]=r1.g_x+r1.g_w-1;xy[3]=r1.g_y+r1.g_h-1;
		vsf_color( win->graf.handle, (app.color>=16)?frame->color:WHITE);
		v_bar( win->graf.handle, xy);
	}
	
	/* draw frames */
	
	oldclip = clip;
	
	while( scan) {
		if( scan->status & WS_OPEN) {
			FrameCalc( scan, 1, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
			/* Drawing borders */
			if( frame->border > 0 && !(GETFINFO(scan)->flags & FRAME_NOBORDER)) {
				if( frame->flags & NO_BACKGROUND) {
					vsl_color( win->graf.handle, frame->color);
					for( i=2; i<frame->border/2+1; i++) {
						set_frame( xy, r1.g_x-i, r1.g_y-i, r1.g_w+2*i, r1.g_h+2*i);
						v_pline( win->graf.handle, 5, xy);
					}
				}
				set_frame( xy, r1.g_x-1, r1.g_y-1, r1.g_w+2, r1.g_h+2);
				vsl_color( win->graf.handle, BLACK);
				v_pline( win->graf.handle, 5, xy);
				if( app.color >= 16) {
					set_frame( xy, r1.g_x-2, r1.g_y-2, r1.g_w+4, r1.g_h+4);
					vsl_color( win->graf.handle, LBLACK);
					v_pline( win->graf.handle, 5, xy);

					vsl_color( win->graf.handle, WHITE);
					v_pline( win->graf.handle, 3, xy+2);
				}
			}
			/* Drawing frame widgets */
			if( frame->front == scan)
				set_gadget_pos( scan, &r1, 0x1);
			else
				set_gadget_pos( scan, &r1, 0x1|0x4);
			
			/* redraw the frame content (work area) */
			/* get the 1st clipping area */
			FrameCalc( scan, 0, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
			if( rc_intersect( &oldclip, &r1)) {
				rc_clip_on( scan->graf.handle, &r1);
				EvntExec( scan, WM_REDRAW);
				rc_clip_off( scan->graf.handle);
			} 
		}
		scan = scan->next;
		clip = oldclip;
	}
}

static void frame_destroy( WINDOW *win) {
	FRAME *frame = DataSearch( win, WD_WFRA);
	WINDOW *scan = frame->list, *next;
	
	while( scan) {
		next = scan->next;
		EvntExec( scan, WM_DESTROY);
		scan = next;
	}
	free( frame);
/*	WindClose( win);
	WindDelete( win); */
}

/* scrolling functions (use the widget field) */

static void frame_vsld( WINDOW *win) {
	WINDOW *frame = ((FRAME*)DataSearch(win,WD_WFRA))->widget;
	
	if( frame && ( frame->status & WS_OPEN))
		EvntExec( frame, WM_VSLID);
}

static void frame_hsld( WINDOW *win) {
	WINDOW *frame = ((FRAME*)DataSearch(win,WD_WFRA))->widget;
	
	if( frame && ( frame->status & WS_OPEN))
		EvntExec( frame, WM_HSLID);
}

static void frame_arw( WINDOW *win) {
	WINDOW *frame = ((FRAME*)DataSearch(win,WD_WFRA))->widget;
	INT16 button, dum;
	
	if( frame && ( frame->status & WS_OPEN))
		do {
			EvntExec( frame, WM_ARROWED);
			graf_mkstate( &dum, &dum, &button, &dum);
		} while( button & 0x1 && win != wglb.front);
}

static void frame_tpd( WINDOW *win) {
	WINDOW *child = FrameFind( win, evnt.mx, evnt.my);
	INT16 x,y,w,h;
	
	if( child == NULL) {
		if( wglb.front == win)
			WindSet( win, WF_BOTTOM, win->handle, 0, 0, 0);
		else
			WindSet( win, WF_TOP, win->handle, 0, 0, 0);
		return;
	}
		
	FrameCalc( child, 0, &x, &y, &w, &h);
	
	if( IS_IN(evnt.mx, evnt.my, x, y, w, h)) {
		EvntExec( child, WM_TOPPED);
		wind_set( win->handle, WF_TOP, win->handle, 0, 0, 0);
		FrameSet( win, FRAME_ACTIV, child);
	} else
		EvntExec( win, WM_XBUTTON);
}

static void frame_untpd( WINDOW *win) {
	GRECT r;
	FRAME *frame = DataSearch( win, WD_WFRA);
	
	if( frame->front && !(win->status & WS_ICONIFY)) {
		FrameCalc( frame->front, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
		set_gadget_pos( frame->front, &r, 0x1|0x2|0x4);
		frame->front = NULL;
	}
}

static void frame_szd( WINDOW *win) {
	int w, h;
	WINDOW *child = ((FRAME *)DataSearch( win, WD_WFRA))->list;
	
	w = MAX( evnt.buff[6], win -> w_min);
	h = MAX( evnt.buff[7], win -> h_min);
	w = MIN( w           , win -> w_max);
	h = MIN( h           , win -> h_max);
	wind_set( evnt.buff[3], WF_CURRXYWH, evnt.buff[4], evnt.buff[5], w, h);
	snd_rdw( win);
	win->status &= ~WS_FULLSIZE;
	while( child) {
		if( child->status & WS_OPEN)
			update_scrolls( child);
		child = child->next;
	}
}

static void frame_fld( WINDOW *win) {
	INT16 x, y, w, h;
	WINDOW *child = ((FRAME *)DataSearch( win, WD_WFRA))->list;
	
	if( win->status & WS_FULLSIZE) {
		wind_get( evnt.buff[3], WF_PREVXYWH, &x, &y, &w, &h);
		wind_set( evnt.buff[3], WF_CURRXYWH, x, y,  w, h);
	} else
		wind_set(evnt.buff[3], WF_CURRXYWH, app.x, app.y, win->w_max, win->h_max);
	
	snd_rdw( win);
	win->status ^= WS_FULLSIZE;
	/* mise-a-jour des scrolls */
	while( child) {
		if( child->status & WS_OPEN)
			update_scrolls( child);
		child = child->next;
	}
}


/* events */

/*  called by frame_click
 *	find the frame column/line at coordinates (x,y) 
 *	return 0 (line) or 
 *             1 (column)	
 *	r will contain the outside coordinates (for movebox effects)
 *
 *  Nota: bottom and the right borders (frontier) of the frame at
 *       (line/column) are part of the (line/column) frame.
 */


static int get_board( WINDOW *win, int x, int y, int *line, int *col, GRECT *r) {
	INT16 xw, yw, ww, hw;
	WINDOW *scan, *begin;
	int max_h, line_h, dum=0;
	FRAME *frame = DataSearch( win, WD_WFRA);
	FRAMEINFO *finfo;
		
	/* area of the parent window */
	
	wind_get( win -> handle, WF_CURRXYWH, &xw, &yw, &ww, &hw);
	WindCalc( 1, win, xw, yw, ww, hw, &xw, &yw, &ww, &hw);
	max_h = 0;
	line_h = 0;
	rc_set( r, xw, yw, ww, hw);
	begin = scan = frame->list;
	*line = GETFINFO(scan)->line;
	for( ; scan; scan=scan->next) {
		finfo = GETFINFO(scan);
		if( *line != finfo->line) {	/* new line */
			line_h += max_h;
			*line = finfo->line;
			if( y >= yw + line_h && y < yw + line_h + frame->border) {
				r->g_y += line_h;
				r->g_h = frame->border;
				return 0;	/* line */
			} 
			if( y < yw + line_h) {
				r->g_y += dum;
				r->g_h = max_h;
				break; /* column */
			}
			line_h += frame->border;
			dum = line_h;
			begin = scan;
			max_h = 0;
		}
		
		/* compute the max height of the cell line */
		max_h = MAX( max_h, PROPOR( finfo->flags & FRAME_HSCALE, hw, finfo->h));
	}
	/* search for the column */
	finfo = GETFINFO(begin);
	if( scan != NULL) *line = finfo->line;
	line_h = max_h = 0;
	*col = finfo->col;
	for( scan=begin; scan; scan=scan->next) {
		finfo = GETFINFO(scan);
		if( *col != finfo->col) {	/* new column */
			line_h += max_h;
			max_h = 0;
			*col = finfo->col;
			if( x >= xw + line_h && x < xw + line_h + frame->border) {
				r->g_x += line_h;
				r->g_w = frame->border;
				return 1;	/* ok */
			}
			line_h += frame->border;
		}
		max_h = MAX( max_h, PROPOR( finfo->flags & FRAME_WSCALE, ww, finfo->w));
	}
	return 1;
}

static void frame_click( WINDOW *win) {
	WINDOW *child = FrameFind( win, evnt.mx, evnt.my), *scan;
	FRAME *frame = DataSearch( win, WD_WFRA);
	FRAMEINFO *finfo;
	INT16 x, y, w, h;
	INT16 xr, yr, wr, hr;
	INT16 x1, y1, res, dum1, dum2;
	int line, col;
	GRECT r;
	OBJECT *tree;
	
	if( child) {
		if( child->status & WS_OPEN) {
			/*
	 		 * manage frame gadget
	 		 */
			finfo = GETFINFO(child);
			if( finfo->flags & FRAME_SELECT) {
				/* Gestion des gadgets */
				tree = get_frame_slider();
				if( frame->front == child || win != wglb.front) {
					FrameCalc( child, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
					set_gadget_pos( child, &r, 0);
				} else
					FrameSet( win, FRAME_ACTIV, child);
				frame->widget = child;
				res = objc_find( tree, M_H_BG, 2, evnt.mx, evnt.my);
				if( res != -1) {
					WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
					switch ( res) {
					case M_H_RT:
						tree[M_H_RT].ob_state |= SELECTED;
						ObjcWindDraw( win, tree, M_H_RT, 1, x, y, w, h);
						do {
							snd_arrw( win, WA_RTLINE);
							EvntWindom( MU_MESAG);
							graf_mkstate( &dum1, &dum1, &res, &dum1);
							
						} while( res);
						tree[M_H_RT].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, M_H_RT, 1, x, y, w, h);
						break;
					case M_H_LF:
						tree[M_H_LF].ob_state |= SELECTED;
						ObjcWindDraw( win, tree, M_H_LF, 1, x, y, w, h);
						do {
							
							snd_arrw( win, WA_LFLINE);
							EvntWindom( MU_MESAG);
							graf_mkstate( &dum1, &dum1, &res, &dum1);
							
						} while( res);
						tree[M_H_LF].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, M_H_LF, 1, x, y, w, h);
						break;
					case M_H_SL:
						if( app.aes4 & AES4_XGMOUSE) graf_mouse( M_SAVE, 0L);
						graf_mouse( FLAT_HAND, NULL);
						while( !wind_update( BEG_MCTRL));
						x = graf_slidebox( tree, M_H_PG, M_H_SL, 0);
						wind_update( END_MCTRL);
						snd_msg( win, WM_HSLID, x, 0, 0, 0);
						if( !(app.aes4 & AES4_XGMOUSE) || graf_mouse( M_RESTORE, 0L) == 0 )
							graf_mouse(ARROW,NULL);
						break;

					case M_H_PG:						
						objc_offset( tree, M_H_SL, &x, &y);
						dum2 = (evnt.mx < x)?WA_LFPAGE:WA_RTPAGE;
						x1   = (evnt.mx < x)?M_H_LF:M_H_RT;
						
						while( !wind_update( BEG_MCTRL));
						tree[x1].ob_state |= SELECTED;
						ObjcWindDraw( win, tree, x1, 1, app.x, app.y, app.w, app.h);
						do {
							snd_arrw( win, dum2);
							EvntWindom( MU_MESAG);
							graf_mkstate( &dum1, &dum1, &res, &dum1);
							
						} while( res);
						tree[x1].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, x1, 1, app.x, app.y, app.w, app.h);
						wind_update( END_MCTRL);
						
						break;
					}
					return;
				}
				res = objc_find( tree, M_V_BG, 2, evnt.mx, evnt.my);
				if( res != -1) {
					WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
					switch ( res) {
					case M_V_UP:
						tree[M_V_UP].ob_state |= SELECTED;
						ObjcWindDraw( win, tree, M_V_UP, 1, x, y, w, h);
						do {
							snd_arrw( win, WA_UPLINE);
							EvntWindom( MU_MESAG);
							graf_mkstate( &dum1, &dum1, &res, &dum1);
							
						} while( res);
						tree[M_V_UP].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, M_V_UP, 1, x, y, w, h);
						break;

					case M_V_DW:
						tree[M_V_DW].ob_state |= SELECTED;
						ObjcWindDraw( win, tree, M_V_DW, 1, x, y, w, h);
						do {
							
							snd_arrw( win, WA_DNLINE);
							EvntWindom( MU_MESAG);
							graf_mkstate( &dum1, &dum1, &res, &dum1);
							
						} while( res);
						tree[M_V_DW].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, M_V_DW, 1, x, y, w, h);
						break;

					case M_V_SL:
						if( app.aes4 & AES4_XGMOUSE) graf_mouse( M_SAVE, 0L);
						graf_mouse( FLAT_HAND, NULL);
						while( !wind_update( BEG_MCTRL));
						x = graf_slidebox( tree, M_V_PG, M_V_SL, 1);
						wind_update( END_MCTRL);
						snd_msg( win, WM_VSLID, x, 0, 0, 0);
						if( !(app.aes4 & AES4_XGMOUSE) || graf_mouse( M_RESTORE, 0L) == 0 )
							graf_mouse(ARROW,NULL);
						break;

					case M_V_PG:
						objc_offset( tree, M_V_SL, &x, &y);
						dum2 = (evnt.my < y)?WA_UPPAGE:WA_DNPAGE;
						x1   = (evnt.my < y)?M_V_UP:M_V_DW;

						while( !wind_update( BEG_MCTRL));
						tree[x1].ob_state |= SELECTED;
						ObjcWindDraw( win, tree, x1, 1, app.x, app.y, app.w, app.h);
						do {
							snd_arrw( win, dum2);
							EvntWindom( MU_MESAG);
							graf_mkstate( &dum1, &dum1, &res, &dum1);
						} while( res);
						tree[x1].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, x1, 1, app.x, app.y, app.w, app.h);
						wind_update( END_MCTRL);
						break;
					}
					return;
				}
				/* Sizer */
				res = objc_find( tree, M_SZ, 0, evnt.mx, evnt.my);
				if( res != -1 && child->attrib & SIZER) {
					wind_get( win->handle, WF_CURRXYWH, &x, &y, &w, &h);
					while( !wind_update( BEG_MCTRL));
					graf_mouse( 4, NULL);
					graf_rubberbox( x, y, win->w_min, win->h_min, &w, &h);
					graf_mouse( 0, NULL);
					wind_update( END_MCTRL);
					snd_msg( win, WM_SIZED, x, y, w, h);
					return;
				}
			}
			
			/* callback the right subroutine */
			
			if( !(child->status & WS_UNTOPPABLE) &&  win != wglb.front) {
				EvntExec( child, WM_TOPPED);
				if( frame->flags & TOPPED_ACTIV)
					FrameSet( win, FRAME_ACTIV, child);
			} else
				EvntExec( child, WM_XBUTTON);
		}
	} else {
		/*
		 * manage frame borders
		 */		

		wind_get( win -> handle, WF_CURRXYWH, &x, &y, &w, &h);
		WindCalc( 1, win, x, y, w, h, &xr, &yr, &wr, &hr);
		res = get_board( win, evnt.mx, evnt.my, &line, &col, &r);
		if( res == -1)
			return;	/* erreur - pas encore g�r� */
		dum1 = dum2 = 0;
		for( scan = frame->list; scan; scan = scan->next) {
			/* on v�rifie si les frames sont resizable et */
			/* taille MAX admissible (ligne) */
			finfo = GETFINFO(scan);
			if( res == 0 && finfo->line == line) {
			 	if( finfo->flags & FRAME_HFIX) 
					return;
				dum1 = MAX( dum1, PROPOR( finfo->flags & FRAME_HSCALE, hr, finfo->h));
			}
			if( res == 0 && finfo->line == line-1) {
				if( finfo->flags & FRAME_HFIX)
					return;
				dum2 = MAX( dum2, PROPOR( finfo->flags & FRAME_HSCALE, hr, finfo->h));
			}
			if( res == 1 && finfo->col == col && finfo->line == line) {
			 	if( finfo->flags & FRAME_WFIX) 
					return;
				dum2 = PROPOR( finfo->flags & FRAME_WSCALE, wr, finfo->w);
				dum2 = dum2-scan->w_min;
			}
			if( res == 1 && finfo->col == col-1 && finfo->line == line) {
				if( finfo->flags & FRAME_WFIX)
					return;
				dum1 = PROPOR( finfo->flags & FRAME_WSCALE, wr, finfo->w);
				dum1 = dum1-scan->w_min;
			}
		}
		if( res == 0) { /* ligne - � l'air OK */
			graf_dragbox( wr+1, frame->border, 
						  xr, r.g_y, xr, 
						  r.g_y-dum2, wr, MIN(r.g_y+dum1, yr+hr)-r.g_y+dum2,
						  &x1, &y1);
			/* resize : � faire */
		} else {
			FRAMEINFO *finfo_n;

			graf_dragbox( frame->border, r.g_h,
						  r.g_x, r.g_y, 
						  r.g_x-dum1, r.g_y, r.g_w+dum1+dum2, r.g_h,
						  &x1, &y1);

			/* bug: la taille de la derniere frame doit correspondre a la fin
			        de l'�cran ou sa vrai taille, ca merde surement a cause des
			        erreurs d'arrondis */
			if( col == 0)	return;
			/* Resizons mes fr�res: deux frames col et col-1*/
			scan = FrameSearch( win, line, col-1);
			finfo = GETFINFO( scan);
			finfo_n = GETFINFO( scan->next);
			FrameCalc( scan, 1, &x, &y, &w, &h);
			dum1 = (int)((finfo->flags & FRAME_WSCALE)?(((long)(x1-x)*100L)/(long)wr):(x1-x));
			
			FrameCalc( scan->next, 1, &x, &y, &w, &h);
			finfo_n->w = (int)((finfo_n->flags & FRAME_WSCALE)?(((long)(w-x1+x)*100L)/(long)wr):(w-x1+x));
			if( (scan->next->next == NULL
				|| finfo_n->line != GETFINFO(scan->next->next)->line)
				&& finfo_n->flags & FRAME_WSCALE)
				finfo->w ++;
			finfo->w = dum1;
			
			update_scrolls( scan);
			update_scrolls( scan->next);
			snd_rdw(win);
		}
	}
}

static void frame_keybd( WINDOW *win) {
	FRAME *frame = DataSearch( win, WD_WFRA);
	WINDOW *child;
	
	if( frame->flags & FLG_KEYMOUSE)
	 	child = FrameFind( win, evnt.mx, evnt.my);
	else
		child = frame->front;
	
	if( child && (child->status & WS_OPEN)) {
		frame->widget = child;
		EvntExec( child, WM_XKEYBD);
	}
}

static void frame_timer( WINDOW *win) {
	WINDOW *child = ((FRAME *)DataSearch( win, WD_WFRA))->list;

	while( child) {
		if( child->status & WS_OPEN)
			EvntExec( child, WM_XTIMER);
		child = child->next;
	}
}


WINDOW *FrameCreate( int attrib) {
	WINDOW *win;
	FRAME *frame;
	
	frame = (FRAME *)malloc( sizeof(FRAME));
	if( !frame) return NULL;
	frame -> list = frame -> front = NULL;
	frame -> border = 1;
	frame -> color = LWHITE;
	frame -> flags = 0;
	win = WindCreate( attrib, app.x, app.y, app.w, app.h);
	EvntAttach( win, WM_REDRAW, frame_draw);
	win -> icon.draw = WindClear;
	EvntAdd   ( win, WM_DESTROY, frame_destroy, EV_TOP);
	EvntAttach( win, WM_VSLID  , frame_vsld);
	EvntAttach( win, WM_HSLID  , frame_hsld);
	EvntAttach( win, WM_ARROWED, frame_arw);
	EvntAttach( win, WM_TOPPED , frame_tpd);
	EvntAttach( win, WM_UNTOPPED, frame_untpd);
	EvntAttach( win, WM_SIZED  , frame_szd);
	EvntAttach( win, WM_FULLED , frame_fld);

	EvntAttach( win, WM_XBUTTON , frame_click);
	EvntAttach( win, WM_XKEYBD , frame_keybd);
	EvntAttach( win, WM_XTIMER , frame_timer);
	
	DataAttach( win, WD_WFRA, frame);
	
	win -> status |= WS_FRAME_ROOT;
	frame->col = frame->line =0;

	WindSet( win, WF_BEVENT, BEVENT_WORK, 0, 0, 0);
	return win;
}

