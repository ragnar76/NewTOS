/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_wdo.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:22:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 *	A voir: FormWinDo( int Evnt);
 */

int FormWindDo( int Evnt) {
	int evnt_res;

	while( 1) {
		evnt_res = EvntWindom( Evnt);
		
		if( (evnt_res & MU_MESAG)) {
			switch( evnt.buff[ 0]) {

			case WM_FORM:
				return( evnt.buff[ 4]);
			case WM_DESTROY:
				return( -1);
			}
		}
		/* else  */
		if( Evnt & FORM_EVNT)
			return (evnt_res|FORM_EVNT);
	}
}
