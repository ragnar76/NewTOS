/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_find.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.3 $
 */

#include <stdarg.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"


/* provide some ways to find a window */

WINDOW *WindFind( int mode, ...) {
	int id=0;
	void *adr=NULL;
	long magic=0L;
	va_list args;
	WINDOW *win;
	
	va_start( args, mode);
	if( mode == WDF_ID)
		id = va_arg( args, int);
	else if( mode == WDF_DATA)
		magic = va_arg( args, long);
	else
		adr = va_arg( args, void*);
		
	va_end( args);
	for( win = wglb.first; win; win = win->next) {
		switch ( mode) {
		case WDF_NAME:
			if( win->name && !strcmp(win->name, (char *)adr) )
				return win;
			break;
		case WDF_INFO:
			if( win->info && !strcmp(win->info, (char *)adr) )
				return win;
			break;
		case WDF_ID:
			if( win->handle == id)
				return win;
			break;
		case WDF_MENU:
			if( win->menu.real == adr)
				return win;
			break;
		case WDF_FORM:
			
			break;
		case WDF_TOOL:
			if( win->tool.real == adr)
				return win;
			break;
			
		case WDF_DATA:
			if( DataSearch( win, magic))
				return win;
			break;
		}
		
	}
	return NULL;
}
