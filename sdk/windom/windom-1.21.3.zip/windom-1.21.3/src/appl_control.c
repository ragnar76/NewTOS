/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/appl_control.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:37:42 $
 *   $Revision: 1.1 $
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "globals.h"
#include "cookie.h"
#include "fsel.h"
#include "wsystem.h"

/*
 * ApplControl() est une fonction de Naes. MagiC offre les
 * m�mes actions mais sous une forme diff�rente. Cette fonction
 * unifie le tout.
 */

#define MA	0x4D41	/* 'MA' */
#define GX	0x4758	/* 'GX' */

int ApplControl( int ap_cid, int ap_cwhat) {
	void *dummy = 0;  /* initialized to avoid GCC warning */
	if( vq_naes() > 0) {
		/* parametre mystere dans appl_control */
		return appl_control( ap_cid, ap_cwhat, dummy);
	} else if( vq_magx() >= 0x0310) {
		switch( ap_cwhat) {
		case APC_HIDE:
			ApplWrite( SCREENMGR, SM_M_SPECIAL, 0, MA, GX, SMC_HIDEACT, 0);
			break;
		case APC_SHOW:
			ApplWrite( SCREENMGR, SM_M_SPECIAL, 0, MA, GX, SMC_UNHIDEALL, 0);
			break;
		case APC_TOP:
			/* on peut le faire diff�rement */
			break;
		case APC_HIDENOT:
			ApplWrite( SCREENMGR, SM_M_SPECIAL, 0, MA, GX, SMC_HIDEOTHERS, 0);
			break;
		}
	}
	return 1;	/* pas d'erreur ? */
}
