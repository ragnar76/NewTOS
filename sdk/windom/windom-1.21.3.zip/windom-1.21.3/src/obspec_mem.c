/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/obspec_mem.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:03:58 $
 *   $Revision: 1.1 $
 */


#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 * Quand un objet est copi� par ObjcDup, il faut conserver qqpart
 * les objets r�serv� par malloc() pour pouvoir les lib�rer par un
 * free() lors de l'appel � ObjcFree().
 * Le probl�me se pose pour les champs ob_spec que l'application
 * peut modifier � son gr� par ObjcString() par exemple.
 * Dans ce cas, il faut lib�rer le bloc r�serv� par malloc() qui
 * n'est plus n�cessairement dans le champ ob_spec de l'objet
 * dupliqu�. D'o� ceci:
 */

struct ty_obspec_dup {
	OBJECT * p_ob;    /* pointeur sur l'objet dupliqu� */
	void   * p_mem;   /* adresse de la m�moire allou�e */
	struct ty_obspec_dup * next;
}; 

static struct ty_obspec_dup * __list_obspec_dup = NULL;

void * __malloc_obspec(OBJECT * p_ob, long size)
{
	struct ty_obspec_dup  * obspec_dup;
	void * p_mem;
	
	if (! size) return NULL;
	
	p_mem = malloc (size);
	if (! p_mem) return NULL;
	
	obspec_dup = (struct ty_obspec_dup *) malloc (sizeof (struct ty_obspec_dup));
	if (! obspec_dup) {
		free (p_mem);
		return NULL;
	}
	
	obspec_dup->p_ob  = p_ob;
	obspec_dup->p_mem = p_mem;
	obspec_dup->next  = __list_obspec_dup;
	__list_obspec_dup = obspec_dup;
	
	return p_mem;
}

void __free_obspec( OBJECT * p_ob)
{
	struct ty_obspec_dup  *here, *prev;
	
	here = __list_obspec_dup;
	prev = NULL;
	
	while ((here) && (here->p_ob != p_ob)) {
		prev = here;
		here = here->next;
	}
	
	if (here) {
		free (here->p_mem);
		if (prev) {
			prev->next = here->next;
		} else {
			__list_obspec_dup = here->next;
		}
		free (here);
	}
}
