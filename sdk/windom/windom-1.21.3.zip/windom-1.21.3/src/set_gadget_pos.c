/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/set_gadget_pos.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:00:13 $
 *   $Revision: 1.1 $
 */


#include <stdlib.h>
#include "globals.h"
#include "sliders.h"

#define ISNT_HIDE(a,b)	(((a)[(b)].ob_flags & HIDETREE)?0:1)

/* Positionne et dessine les gadgets de la frame
   r1   zone courante de la frame
   mode 0x0001	redraw
   		0x0002	redraw par ObjcWindDraw
   		0x0004	deselectionner les gadgets
   		0x0008	mode pour WindSet()
   		0x0010	idem
   		0x0020  idem
   		0x0040	selection des gadgets selon si la fen�tre est
   				topp� (mode pour WindSet())
*/

void set_gadget_pos( WINDOW *frame, GRECT *r1, int mode) {
	OBJECT *tree;
	WINDOW *root;
	BFOBSPEC *obspec;
	FRAMEINFO *finfo = GETFINFO(frame);

	/* tree = rs_trindex[ FRAME_SLIDER]; */
	tree = get_frame_slider();
	
	/* S�lection des gadgets (fonction des attributs) : OKAY */

	tree[M_INFO].ob_spec.tedinfo->te_ptext = frame->info;

	SET_BIT( tree[M_INFO].ob_flags, HIDETREE, !(frame->attrib & INFO));

	SET_BIT( tree[M_V_PG].ob_flags, HIDETREE, !(frame->attrib & VSLIDE));
	SET_BIT( tree[M_V_UP].ob_flags, HIDETREE, !(frame->attrib & UPARROW));
	SET_BIT( tree[M_V_DW].ob_flags, HIDETREE, !(frame->attrib & DNARROW));
	SET_BIT( tree[M_V_BG].ob_flags, HIDETREE, !(frame->attrib & (SIZER+DNARROW+UPARROW+VSLIDE)));

	SET_BIT( tree[M_H_PG].ob_flags, HIDETREE, !(frame->attrib & HSLIDE));
	SET_BIT( tree[M_H_LF].ob_flags, HIDETREE, !(frame->attrib & LFARROW));
	SET_BIT( tree[M_H_RT].ob_flags, HIDETREE, !(frame->attrib & RTARROW));
	SET_BIT( tree[M_H_BG].ob_flags, HIDETREE, !(frame->attrib & (LFARROW+RTARROW+HSLIDE)));

	if( frame->attrib & SIZER ||
		(!(tree[M_H_BG].ob_flags & HIDETREE) &&
		 !(tree[M_V_BG].ob_flags & HIDETREE)) )
		tree[M_SZ].ob_flags &= ~HIDETREE;
	else
		tree[M_SZ].ob_flags |= HIDETREE;

	/* Coordonn�es et tailles des gadgets */

	/* barre d'information : okay */
	tree[M_INFO].ob_x =	r1->g_x;
	tree[M_INFO].ob_y = r1->g_y;
	tree[M_INFO].ob_width = r1->g_w;
	
	/* taille fond des ascenseurs : d�pend de la pr�sence du sizer et de la barre d'info */
	tree[M_H_BG].ob_width  = r1 -> g_w + 3 - ISNT_HIDE(tree,M_SZ)*(tree[M_SZ].ob_width);
	tree[M_V_BG].ob_height = r1 -> g_h + 3 - ISNT_HIDE(tree,M_SZ)*(tree[M_SZ].ob_height)
							 - ISNT_HIDE(tree,M_INFO)*(tree[M_INFO].ob_height+1);
	
	/* position fond des ascenseurs */
	tree[M_V_BG].ob_x =	r1->g_x + r1->g_w - tree[M_V_BG].ob_width + 1;
	tree[M_V_BG].ob_y = r1->g_y + ISNT_HIDE(tree,M_INFO)*(tree[M_INFO].ob_height+1) - 1;

	tree[M_H_BG].ob_x = r1->g_x - 1;
	tree[M_H_BG].ob_y = r1->g_y + r1->g_h - tree[M_H_BG].ob_height + 1;
	
	/* les pagers - depend de la pr�sence des scrollers : - OK */
	tree[M_V_PG].ob_y = (tree[M_V_UP].ob_height-1)*ISNT_HIDE(tree,M_V_UP);
	tree[M_V_PG].ob_height = tree[M_V_BG].ob_height 
							 - ISNT_HIDE(tree,M_V_DW)*(tree[M_V_DW].ob_height-1)
							 - ISNT_HIDE(tree,M_V_UP)*(tree[M_V_UP].ob_height-1);

	tree[M_H_PG].ob_x = (tree[M_H_LF].ob_height-1)*ISNT_HIDE(tree,M_H_LF);

	tree[M_H_PG].ob_width  = tree[M_H_BG].ob_width + 2 
							 - ISNT_HIDE(tree,M_H_RT)*(tree[M_H_RT].ob_width)
							 - ISNT_HIDE(tree,M_H_LF)*(tree[M_H_LF].ob_width);
	/* les sliders */
	tree[M_V_SL].ob_height = (int)((long)finfo->vsldsize * tree[M_V_PG].ob_height/1000L);
	tree[M_V_SL].ob_height = MAX( tree[M_V_SL].ob_height, tree[M_V_SL].ob_width);
	tree[M_V_SL].ob_height = MIN( tree[M_V_SL].ob_height, tree[M_V_PG].ob_height);
	tree[M_V_SL].ob_y = (int)( (long)finfo->vsldpos*(long)(tree[M_V_PG].ob_height-tree[M_V_SL].ob_height)/1000L);	
	tree[M_V_SL].ob_y = MIN( tree[M_V_SL].ob_y, tree[M_V_PG].ob_height-tree[M_V_SL].ob_height);
	
	tree[M_H_SL].ob_width  = (int)((long)finfo->hsldsize*(long)tree[M_H_PG].ob_width/1000L);
	tree[M_H_SL].ob_width = MAX( tree[M_H_SL].ob_width, tree[M_H_SL].ob_height);
	tree[M_H_SL].ob_x = (int)((long)finfo->hsldpos*(long)(tree[M_H_PG].ob_width-tree[M_H_SL].ob_width)/1000L);
	tree[M_H_SL].ob_x = MIN( tree[M_H_SL].ob_x, tree[M_H_PG].ob_width-tree[M_H_SL].ob_width);

	/* les scrollers */
	tree[M_H_RT].ob_x = tree[M_H_BG].ob_width - tree[M_H_RT].ob_width ;
	tree[M_V_DW].ob_y = tree[M_V_BG].ob_height - tree[M_V_DW].ob_height ;

	/* le sizer */
	tree[M_SZ].ob_x = r1->g_x + r1->g_w - tree[M_V_BG].ob_width  + 1;
	tree[M_SZ].ob_y = r1->g_y + r1->g_h - tree[M_H_BG].ob_height + 1;

	obspec = (BFOBSPEC *)&((W_PARM *)tree[M_SZ].ob_spec.userblk->ub_parm)->wp_spec;
	obspec->character = (frame->attrib & SIZER)?'':' ';
	
	tree[M_INFO].ob_state &= ~DISABLED;
	tree[M_H_PG].ob_state &= ~DISABLED;
	tree[M_V_PG].ob_state &= ~DISABLED;
	tree[M_V_UP].ob_state &= ~DISABLED;
	tree[M_V_DW].ob_state &= ~DISABLED;
	tree[M_H_LF].ob_state &= ~DISABLED;
	tree[M_H_RT].ob_state &= ~DISABLED;
	tree[M_SZ  ].ob_state &= ~DISABLED;

	root = WindHandle( frame->handle);
	
	if( mode & 0x4 ||
		(mode & 0x40 && root != wglb.front) ) {
		tree[M_INFO].ob_state |= DISABLED;
		tree[M_H_PG].ob_state |= DISABLED;
		tree[M_V_PG].ob_state |= DISABLED;
		tree[M_V_UP].ob_state |= DISABLED;
		tree[M_V_DW].ob_state |= DISABLED;
		tree[M_H_LF].ob_state |= DISABLED;
		tree[M_H_RT].ob_state |= DISABLED;
		tree[M_SZ  ].ob_state |= DISABLED;
	} 

	/* dessin */
	if( mode & 0x1 || mode & 0x8 || mode & 0x10 || mode & 0x20) {
		if( mode & 0x2 || mode & 0x8 || mode & 0x10 || mode & 0x20) {
			INT16 x, y, w, h;
		
			wind_get( root -> handle, WF_CURRXYWH, &x, &y, &w, &h);
			WindCalc( 1, root, x, y, w, h, &x, &y, &w, &h);
			
			if( mode & 0x2) {
				ObjcWindDraw( root, tree, M_INFO, 0, x, y, w, h);
				ObjcWindDraw( root, tree, M_H_BG, 2, x, y, w, h);
				ObjcWindDraw( root, tree, M_V_BG, 2, x, y, w, h);
				ObjcWindDraw( root, tree, M_SZ  , 0, x, y, w, h);
			}
			if( mode & 0x8)
				ObjcWindDraw( root, tree, M_H_PG, 1, x, y, w, h);
			if( mode & 0x10)
				ObjcWindDraw( root, tree, M_V_PG, 1, x, y, w, h);
			if( mode & 0x20)
				ObjcWindDraw( root, tree, M_INFO, 0, x, y, w, h);
		} else {
			objc_draw( tree, M_INFO, 0, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
			objc_draw( tree, M_V_BG, 2, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
			objc_draw( tree, M_H_BG, 2, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
			objc_draw( tree, M_SZ  , 0, clip.g_x, clip.g_y, clip.g_w, clip.g_h);	
		}
	}		
}




