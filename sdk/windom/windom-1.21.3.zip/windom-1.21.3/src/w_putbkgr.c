/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/w_putbkgr.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:32:32 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/* Restaure un fond d'�cran */

void w_put_bkgr(int of_x, int of_y, int of_w, int of_h, MFDB *img) {
	INT16 pxy[8];
	MFDB ecr = {0};	/* Ecran logique */

	pxy[0] = 0;		/* Remplir le tableau */
	pxy[1] = 0;
	pxy[2] = of_w - 1;
	pxy[3] = of_h - 1;
	pxy[4] = of_x;
	pxy[5] = of_y;
	pxy[6] = of_x + of_w - 1;
	pxy[7] = of_y + of_h - 1;
	v_hide_c ( app.handle);			/* Remettre la souris */
	vro_cpyfm ( app.handle, S_ONLY, pxy, img, &ecr);	/* Copier l'image */
	v_show_c ( app.handle, 1);	/* Virer la souris */
	free ( img->fd_addr);		/* Lib�rer la m�moire */
}

