/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_set.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.7 $
 */

#include <stdarg.h>
#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "cookie.h"


/*
 *	WindSet()  -  Set window parameters
 */

static int __CDECL (*icfs)( int f, ...);

#ifndef __MSHORT__  /* version for 32 bits compiler */

int WindSet( WINDOW *win, int mode, int _x, int _y, int _w, int _h) {
	int res=0;
	INT16 x,y,w,h;			/* short integer type arguments */
	INT16 top, pos, dum;	/* temporary variables */
	INT16 xi, yi, wi, hi;
	void *v1, *v2;			/* pointer type arguments */
	
	x = _x; y = _y; w = _w; h = _h;

	v1 = (void*) (long) ( ((long)_x << 16 ) | ((long)_y & 0xFFFFL) ) ;
	v2 = (void*) (long) ( ((long)_w << 16 ) | ((long)_h & 0xFFFFL) ) ;

#else	/* version for 16 bits compiler */

int WindSet( WINDOW *win, int mode, ...) {
	va_list args;
	int res=0;
	INT16 x,y,w,h;			/* short integer type arguments */
	INT16 top, pos, dum;	/* temporary variables */
	INT16 xi, yi, wi, hi;
	void *v1, *v2;			/* pointer type arguments */
			
	/* get the arguments, they may be of two types */

	va_start( args, mode);
	switch( mode) {
	case WF_NAME:
	case WF_ICONTITLE:
	case WF_ICONDRAW :
	case WF_INFO:
	case WF_MENU:
	case WF_TOOLBAR:
	case WF_HILIGHT:
		/* 1) pointers */
		v1 = va_arg( args, void*);    
		v2 = va_arg( args, void*);
	default:
		/* 2) integers */
		x = va_arg( args, int);
		y = va_arg( args, int);
		w = va_arg( args, int);
		h = va_arg( args, int);	
	}
	va_end( args);

#endif

	/* and now, analyse the "mode" */		

	/* New : if the window is open
	 * the size is adjusted */

	switch( mode){
	case WF_MENU:
		/* Desk ? */
		if( win == NULL) {
			if( v1 == NULL) {
				MenuBar( app.menu, 0);
				EvntDelete( NULL, MN_SELECTED);
			} else {
				MenuBar( v1, 1);
				EvntAttach( NULL, MN_SELECTED, v2);
			}
			break;
		}
		
		if( win -> status & WS_MENU) {
			hi = win -> menu.root[1].ob_height;
			ObjcFree( win -> menu.root);
		} else 
			hi = 0;
		
		if( v1 == NULL) { /* remove the menu */
			win -> status &= ~WS_MENU;
			win -> menu.root = NULL;
			win -> menu.real = NULL;
			EvntDelete( win, MN_SELECTED);
			if( win->status & WS_OPEN && hi) {
				wind_get( win->handle, WF_CURRXYWH, &x, &y, &w, &h);
				h -= hi;
				wind_set( win->handle, WF_CURRXYWH, x, y, w, h);
				ApplWrite( app.id, WM_REDRAW, win->handle, x, y, w, h);
			}
			if( CONF(app)->flag & FLG_MNSYSTEM && 
				app.aes4 & AES4_MENUBAR)
				wind_set_str( win->handle, WF_MENU, NULL);
		} else {
			win -> menu.root = ObjcDup( v1, win);
			win -> menu.real = (OBJECT *)v1;
			win -> menu.scroll = 0;
#ifdef BETAMENU
			win -> menu.ac_title = win -> menu.ac_item = -1;
#endif
			win -> status |= WS_MENU;
			EvntAttach( win, MN_SELECTED, v2);
			if( CONF(app)->flag & FLG_MNSYSTEM && 
				app.aes4 & AES4_MENUBAR)
				wind_set_str( win->handle, WF_MENU, (char*)win -> menu.root);
			if( win->status & WS_OPEN) {
				wind_get( win->handle, WF_CURRXYWH, &x, &y, &w, &h);
				h += (win -> menu.root[1].ob_height-hi);
				wind_set( win->handle, WF_CURRXYWH, x, y, w, h);
				ApplWrite( app.id, WM_REDRAW, win->handle, x, y, w, h);
			}
		}
		break;
	case WF_NAME:
		win -> name = (char*)v1;
		if( !(win -> status & WS_ICONIFY))
			res = wind_set_str( win->handle, WF_NAME, (char*)v1);
		break;
	case WF_ICONTITLE:
		win -> icon.name = (char*)v1;
		if( win -> status & WS_ICONIFY)
			res = wind_set_str( win->handle, WF_NAME, (char*)v1);
		break;
	case WF_ICONDRAW:
		win -> icon.draw = (void*)v1;
		break;
	case WF_INFO:
		win->info = v1;
		if( win->status & WS_FRAME) {
			GRECT r;
			(*__calc)( win, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
			(*__swgt)( win, &r, 0x20);
		}
			res = wind_set_str( win->handle, WF_INFO, (char*)v1);
		break;

	case WF_TOOLBAR:
		if( win -> status & WS_TOOLBAR) {
			wi = ( win -> tool.root -> ob_width > win -> tool.root -> ob_height)?1:0;
			hi = wi ? win -> tool.root -> ob_height : win -> tool.root -> ob_width;
			RsrcUserFree( win -> tool.root);
			ObjcFree( win -> tool.root);
			if( win -> tool.save) free( win->tool.save);
		} else
			hi = 0;
		wind_get( win->handle, WF_CURRXYWH, &x, &y, &w, &h);
		if( win -> tool.root) ObjcFree( win -> tool.root);
		if( win -> tool.bind) free(  win -> tool.bind);
		win -> tool.bind = NULL;
		if( v1 == NULL) {
			win -> tool.root = NULL;
			win -> tool.real = NULL;
			EvntDelete( win, WM_TOOLBAR);
			win -> status &= ~WS_TOOLBAR;
			if( wi) h -= hi;
			else	w -= hi;
		} else {
			win -> tool.root = ObjcDup( v1, win);
			win -> tool.real = (OBJECT *)v1;			
			EvntAttach( win, WM_TOOLBAR, v2);
			win -> tool.save = NULL;
			win -> status |= WS_TOOLBAR;
			if( win -> tool.root -> ob_width > win -> tool.root -> ob_height) {
				win -> tool.root -> ob_width = app.w;
				h += win -> tool.root -> ob_height;
			} else {
				win -> tool.root -> ob_height = app.h;
				w += win -> tool.root -> ob_width;
			}
		}
		if( win->status & WS_OPEN) {
			wind_set( win->handle, WF_CURRXYWH, x, y, w, h);
			ApplWrite( app.id, WM_REDRAW, win->handle, x, y, w, h);
		}
		break;
	case WF_BEVENT:
		if( x & BEVENT_WORK)
			win -> status |= WS_UNTOPPABLE;
		if( (app.aes4 & AES4_BEVENT) && (x & BEVENT_WORK)) {
			x &= ~BEVENT_MODAL;
			wind_set( win -> handle, WF_BEVENT, x, y, w, h);
		}
		if( x & BEVENT_MODAL)
			win -> status |= WS_MODAL;
		else
			win -> status &= ~WS_MODAL;
		break;
	case WF_ICONIFY:
		if( win -> status & WS_ICONIFY)
			break;
		win -> status |= WS_ICONIFY;
		wind_get( win->handle, WF_CURRXYWH, &win->icon.x, &win->icon.y, 
				  &win->icon.w, &win->icon.h);
		if( app.aes4 & AES4_ICONIFY) {
			if( win -> status & WS_GROW)
				graf_shrinkbox( x,y,w,h,win->icon.x,win->icon.y,win->icon.w,win->icon.h);
			wind_set( win->handle, WF_ICONIFY, x, y, w, h);
			if( win->icon.name)
				res = wind_set_str( win->handle, WF_NAME, win->icon.name);
			break;
		}

		/* Is this the top window ? */
		wind_get( 0, WF_TOP, &top, &dum, &dum, &dum);
		dum=(top==win->handle)?0:1;

		if( win -> status & WS_GROW) {
			res = 1;
			win -> status &= ~ WS_GROW;
		}
		else res = 0;
		WindClose( win);
		
		wind_delete( win->handle);
		win->handle = wind_create( NAME|MOVER, app.x, app.y, app.w, app.h);
		
			/* position of icons */
		if( get_cookie( ICFS_COOKIE, (long*)&icfs)) {
			pos = (*icfs)( ICF_GETPOS, &xi, &yi, &wi, &hi);
			if( xi == x && yi == y && wi == w && hi == h)
				__iconlist[ pos] = win->handle;
			else
				(*icfs)( ICF_FREEPOS, pos);
		} else {
			for( pos = 0; __iconlist[ pos]; pos ++);
			xi = app.x + (pos%(app.w/CONF(app)->wicon))*CONF(app)->wicon;
			yi = app.y + app.h -(pos/(app.w/CONF(app)->wicon)+1)*CONF(app)->hicon;
			wi = CONF(app)->wicon;
			hi = CONF(app)->hicon;
			if( xi == x && yi == y && wi == w && hi == h)
				__iconlist[ pos] = win->handle;
		}
		
		if( res == 1)
			graf_shrinkbox( x,y,w,h,win->icon.x,win->icon.y,win->icon.w,win->icon.h);

		WindOpen( win, x, y, w, h);
		if( res == 1)
			win -> status |= WS_GROW;
		
		if( dum)
			wind_set( top, WF_TOP, 0, 0, 0, 0);

		if( win->icon.name)
			wind_set_str( win->handle, WF_NAME, win->icon.name);
		break;

	case WF_UNICONIFY:
		if( (win -> status & WS_ICONIFY) == 0)
			break;
		win -> status &= ~WS_ICONIFY;
		wind_get( win->handle, WF_CURRXYWH, &xi, &yi, &wi, &hi);
		if( app.aes4 & AES4_ICONIFY)
		{
			if( win -> status & WS_GROW)
				graf_growbox( xi,yi,wi,hi,x,y,w,h);
			wind_set( win->handle, WF_UNICONIFY, x, y, w, h);
			if( win->name)
				wind_set_str( win->handle, WF_NAME, win->name);
			break;
		}

		/* free the icon positions */
		for( pos = 0; __iconlist[ pos] != win->handle; pos ++); 
		__iconlist[ pos] = 0;
		if( get_cookie( ICFS_COOKIE, (long*)&icfs))
			(*icfs)( ICF_FREEPOS, pos);

		if( win -> status & WS_GROW) {
			res = 1;
			win -> status &= ~ WS_GROW;
		}
		else res = 0;

		WindClose( win);
		wind_delete( win->handle);
		win->handle = wind_create( win->attrib, win->createsize.g_x, 
								   win->createsize.g_y, win->createsize.g_w, 
								   win->createsize.g_h);

		if( res == 1)
			graf_growbox( xi, yi, wi, hi,x,y,w,h);
		
		WindOpen( win, x, y, w, h);
		if( res == 1)
			win -> status |= WS_GROW;
		
		if( win -> name)
			wind_set_str( win->handle, WF_NAME, win->name);
		if( win -> info)
			wind_set_str( win->handle, WF_INFO, win->info);
		break;
	case WF_UNICONIFYXYWH:
		if( app.aes4 & AES4_ICONIFY)
			wind_set( win->handle, WF_UNICONIFYXYWH, x, y, w, h);
		else {
			win->icon.x = x;
			win->icon.y = y;
			win->icon.w = w;
			win->icon.h = h;
		}
		break;
	case WF_WORKXYWH:
		{
			INT16 xc,yc,wc,hc;
			
			WindCalc( 0, win, x, y, w, h, &xc, &yc, &wc, &hc);
			wind_set( win->handle, WF_CURRXYWH, xc, yc, wc, hc);
		}
		break;
	case WF_BOTTOM:
		/* if this is a modal window 
		 * we do nothing */
		if( is_modal() && x == wglb.appfront->handle)
			break;

		/* Update internal window list */
		if( x == __windowlist[0])
			break;
		for( w=0; __windowlist[w] != x; w = __windowlist[w]);
		__windowlist[ w] = __windowlist[ x];
		__windowlist[ x] = __windowlist[ 0];
		__windowlist[ 0] = x;
			
		if( app.aes4 & AES4_BOTTOM)
			wind_set( x, WF_BOTTOM, x, 0, 0, 0);
		else {
			/* Here we emulates WF_BOTTOM feature */
			y = __windowlist[ x];
			while( y != -1) {
				wind_set( y, WF_TOP, 0, 0, 0, 0);
				y = __windowlist[ y];
			}
		} 

		break;
	case WF_TOP:
		/* Update internal windows list */
		y = 0;
		while( __windowlist[y] != -1)
			y = __windowlist[y];
		if( x != y ) /* another application window was on the top ? */
		{	
			/* w = prec(x) */
			for( w=0; __windowlist[w] != x; w = __windowlist[w]);
			__windowlist[w] = __windowlist[x];
			__windowlist[y] = x;
			__windowlist[x] = -1;
		}
		if( is_modal()) {
			win = wglb.appfront;
			x = win->handle;
		}
		res = wind_set( win?win->handle:x, WF_TOP, x, 0, 0, 0);
		if( (win = WindHandle(x)) != NULL)	/* it's one of our windows */
			wglb.appfront = wglb.front = win;
		break;

	/* Sliders and frame */
	case WF_HSLIDE:
		if( win->status & WS_FRAME) {
			GRECT r;
			GETFINFO(win)->hsldpos= x;
			(*__calc)( win, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
			(*__swgt)( win, &r, 0x8|0x40);
		}
		else
			wind_set( win->handle, mode, x, 0, 0, 0);
		break;
	case WF_VSLIDE:
		if( win->status & WS_FRAME) {
			GRECT r;
			GETFINFO(win)->vsldpos = x;
			(*__calc)( win, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
			(*__swgt)( win, &r, 0x10|0x40);
		}
		else
			wind_set( win->handle, mode, x, 0, 0, 0);
		break;
	case WF_HSLSIZE:
		if( win->status & WS_FRAME) {
			GRECT r;
			GETFINFO(win)->hsldsize = x;
			(*__calc)( win, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
			(*__swgt)( win, &r, 0x8|0x40);
		}
		else
			wind_set( win->handle, mode, x, 0, 0, 0);
		break;
	case WF_VSLSIZE:
		if( win->status & WS_FRAME) {
			GRECT r;
			GETFINFO(win)->vsldsize = x;
			(*__calc)( win, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
			(*__swgt)( win, &r, 0x10|0x40);
		}
		else
			wind_set( win->handle, mode, x, 0, 0, 0);
		break;

	case WF_HILIGHT:
		if( win)
			win->menu.hilight = v1;
		else
			app.hilight = v1;
	/* other wind_set() modes */
	default:
		res = wind_set( win?win->handle:0, mode, x,y,w,h);
		break;
	}
	return res;
}
