/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/userdef.h,v $
 * Module : constants for extended types
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:54:47 $
 *   $Revision: 1.1 $
 */


/* Type d'objets �tendus */
#ifndef __MYDIAL__
#define DIALMOVER  0x11
#define DCRBUTTON  0x12
#define UNDERLINE  0x13
#define TITLEBOX   0x14
#define HELPBUT    0x15
#define CIRCLEBUT  0x16
#define POPUPSTRG  0x17
#define KPOPUPSTRG 0x18
#define SLIDEPART  0x19
#define LONGINPUT  0x1A
#define UNDOBUT    0x1F
#endif
#define USERDRAW   0xFF	/* R�serv� WinDom */

#define FLAGS11    0x0800  /* Pour les objets accessibles avec la touche UNDO */
#define FLAGS15    0x8000  /* objets � lignes de saisie multiples */

/* Objets non MyDials */
#define ONGLET		0x0010	/* bouton formulaire multiple         */
#define	MENUTITLE	0x000F  /* Pour les menus 	*/
#define XEDIT		0x000E	/* champs editable  */
#define XCICON		0x0D  	/* icone couleur userdef */
#define XBOXLONGTEXT 0x09   /* BOXTEXT avec texte sur plusieurs lignes */
#define XFREESTR 	0x0C 	/* objet G_BUTTON 3D (obspec = free_string) */
#define XTEDINFO 	0x0B 	/* objet G_BOXTEXT & co 3D (obspec = tedinfo) */
#define XBFOBSPEC 	0x0A  	/* objet G_BOXCHAR 3D (obspec = bfobspec) */
#define XSMENU   	0x01  	/* pour remplacer le "G_USERDEF|0x0100" dans menu.c */


/* type sp�cial pour routine user_draw */
typedef struct {
		WINDOW *win;
		void *draw, *data;
	} USER_DRAW;
