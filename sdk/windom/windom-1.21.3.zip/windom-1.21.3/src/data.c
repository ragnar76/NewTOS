/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2002 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/data.c,v $
 * Module : interface to Data Library
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:30:05 $
 *   $Revision: 1.1 $
 */


#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

typedef struct _wdata {
		long magic;				/* the magic number idenitfies data */
		void *data; 			/* data address */
		struct _wdata *next; 	/* next item */
	} WDATA;


/*
 * Supprime un element de la liste des donnees d'une
 * fenetre.
 * Retourne 0 si pas d'erreur
 *          ERR_NOT_FOUND si l'element n'existe pas 
 */

int DataDelete( WINDOW *win, long magic) {
	WDATA *scan = win->data;

	/* Cas element en tete */
	if( scan && scan->magic == magic) {
		win->data = scan-> next;
		free(scan);
	} else {
		/* Recherche de l'element */
		for( ; scan->next && scan->next->magic < magic; scan=scan->next);
		/* Supression de l'element */
		if( scan->next && scan->next->magic == magic) {
			WDATA *trash = scan-> next;
			scan->next = scan->next->next;
			free(trash);
		} else
			/* Element non trouve */
			return -1;
	}
	return 0;
}

/*
 * Retourne l'adresse d'une donn�e associ�e � une
 * fenetre ou NULL si la donnee n'existe pas.
 */

void *DataSearch( WINDOW *win, long magic) {
	WDATA *scan;

	for( scan=win->data; scan && scan->magic<magic; scan=scan->next );
	if( scan && scan->magic==magic) 
		return scan->data;
	return NULL;
}

/* 
 * Insert a data inside list data.
 * If a data is found with the same magic number, it
 * will be crashed then lost. In this case, the function
 * returns 1.
 */

int DataAttach( WINDOW *win, long magic, void *data) {
	WDATA *new, *scan;
	int ret = E_OK;
	
	/* look if data exist */
	for( scan = win->data; scan && scan->magic < magic; scan=scan->next);
	if( scan && scan->magic == magic) {
		new = scan;
		ret = 1;
	} else {
		/* Insert a new item in the chained list */
		new = (WDATA *)malloc(sizeof(WDATA));
		if( !new)	return ENSMEM;
		new->next  = NULL;
		/* et insertion */
		scan = win->data;
		/* insert in top position */
		if( !scan || magic < scan->magic) {
			new->next = win->data;
			win->data = new;
		} else {
			while(scan->next && scan->next->magic < magic)
				scan = scan->next;
			new->next  = scan->next;
			scan->next = new;
		}
	}
	new->magic = magic;
	new->data  = data;
	return ret;
}

void DataClear( WINDOW *win) {
	WDATA *next, *scan = win->data;
	
	while( scan) {
		next = scan -> next;
		free( scan);
		scan = next;
	}
	win->data = NULL;
}

#include <stdio.h>

void DataTrace( WINDOW *win) {
	WDATA *scan;
	printf( "window %d:\n", win->handle);
	for( scan=win->data; scan; scan=scan->next)
		printf( "magic=%c%c%c%c data=0x%lX\n", 
									(char)(scan->magic >> 24),
									(char)(scan->magic >> 16),
									(char)(scan->magic >>  8),
									(char)(scan->magic >>  0),
									scan->data);
}

/* EOF */
