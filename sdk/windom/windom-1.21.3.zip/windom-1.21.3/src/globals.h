/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/globals.h,v $
 * Module : definition of internal structures
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/11/17 21:16:54 $
 *   $Revision: 1.8 $
 */


#ifndef __WINDOM_GLOBAL__
#define __WINDOW_GLOBAL__

#include <stddef.h>

#include "wportab.h"
#include "options.h"

/* Libraries TOS */

/* Pure C poss�de des librairies non standard */
#ifdef __PUREC__
# include <tos.h>
#else
# ifdef __SOZOBONX__
#  include <atari.h>  /* for DTA definition */
# endif
# include <osbind.h>
# include <mintbind.h>
# include <fcntl.h>
#endif

/* error codes unified for all libc 
 * (except sozobonx that already has included xdlibs/errno.h
 *  which is similar to this toserror.h)
 */

#ifndef __SOZOBONX__
#include "toserror.h"
#endif


/* Libraries AES / VDI */

#ifdef __PUREC__
# include "..\include\windom.h"
#else
# undef NIL
# include "../include/windom.h"
#endif


#include "cicon.h"

/* Et qqs constantes et structures priv�es � WinDom */

/* Magic */
#define SCREENMGR		1

#define CONF(ap) ((CONFIG *)ap.conf)
#define HI16(a) ((INT16)((long)(a) >> 16) & 0xFFFFL )
#define LO16(a) ((INT16)(long)(a) & 0xFFFFL )
#define DEBUG()	{int printf( const char *, ...); printf( "%s:%d\n", __FILE__, __LINE__);}
/* Vrai si les menus fenetres sont g�r�s par le syst�me */
#define SYSMENU(app) (app.aes4 & AES4_MENUBAR) && (CONF(app)->flag & FLG_MNSYSTEM)

/* defs pour form/toolbar */
#define ROOTS 			0
#define DRAW3D			0x0080
#define OUTLINED_WIDTH	3

typedef struct attrib {
		int font;
		int size;
		int color;
	} ATTRIB;

typedef struct ev_msg {
		int msg;
		void (*proc)(WINDOW *, void *);
		struct ev_msg *next;
		int flags;
		void *data;
	} EV_MSG;


/* Frame structres */

typedef struct {
        struct _window *list, *front,  *widget;
        int border;
        int color;
        int flags;
        int line, col;
    } FRAME;

typedef struct {
        int line, col;
        int x,y,w,h;
        int flags;
        int vsldpos,vsldsize;
        int hsldpos,hsldsize;
    } FRAMEINFO;

#define GETFINFO(win)	((FRAMEINFO*)DataSearch( win, WD_WFRI))

/* Evnt Mesag Flags */
#define EVM_ISWIN		0x1
#define EVM_DISABLE		0x2
#define EVM_IN_USE 		0x4
#define EVM_DELETED 	0x8

/* ApplGet/Set values */
/* note: �quivalent � WFORM dans windom.h */
#define FCENTER		6

#define SYSFONT		0

/* peut-etre a mettre dans gemlib ? */
#define _FSM 0x5F46534DUL

/*
 *	This stucture is private (because, it can
 *	change. It doesn't appear in the header file.
 *	Each member can be set with the function ApplSet()
 * 	(or with the WinDom config file)
 */

typedef struct _config {
		/* Divers drapeaux */
		unsigned int flag;
		/* Fen�tres */
		int	wicon, hicon;
		int	bgcolor;
		int	bgpatt;
		int	bgstyle;
		/* Types �tendus */
		int		key_color;
		ATTRIB	string;
		ATTRIB	button;
		ATTRIB	exit;
		ATTRIB	title;
		ATTRIB	xedit_text;
		ATTRIB	xedit_label;
		int		xedit_curs_color;
		ATTRIB	xlongedit;
		int		xlgedt_smlfnt;
		ATTRIB  xtedinfo;
		int		xtdinf_smlfnt;
		int		actmono;
		int		actcol;
		int		menu_effect;
		/* BubbleGEM */
		ATTRIB	bubble;
		/* Popup */
		int		popcolor;
		int		popborder;
		int		popfcolor;
		int		poppatt;
		int		popwind;		/* -1 (defaut), 0 (bloquant) ou 1 (pr�emptif) */
		/* Autres */
		int		wcenter;		/* CENTER, MOUSE, UP_RIGHT, UP_LEFT, DN_RIGHT, DU_LEFT */
		int		weffect;		/* -1 (defaut), 0 (off), 1 (on)	*/
		int		mwidget;		/* attribut GEM des formulaires modaux */
		int		fwidsize;		/* Frame widgets size */
} CONFIG;

typedef struct _bind {
		int *var;
		void *fnc;
		unsigned int bit;
		void *data;
	} BIND;

/*
 *	Stucture pass� � ub_parm
 *	pour les objets userdefs
 */

typedef struct {
		long  wp_spec;
		int   wp_type;
	} W_PARM;

/*
 *	Stucture pass�e � ub_parm
 *	pour les objets XEDIT
 */

typedef struct {
	TEDINFO *tedinfo;	/* structure Tedinfo originale */
	char *line;			/* le buffer */
	int pos, 			/* premier caractere visible */
		curs, 			/* position curseur */
		blcbeg, blcend;	/* position bloc */
	short flags;		/* drapeaux */
	int size;			/* taille m�moire de la ligne */
	int wp_type;		/* type de l'objet */
} W_XEDIT;

/* Drapeaux de W_XEDIT.flags */
#define XEDIT_CURS_ON 0x1
#define XEDIT_BLOC_ON 0x2

/* modes additionnels - a mettre plus tard dans WINDOM.H */
#define ED_CURS      10 /* retourne la position du curseur */
#define ED_BLC_OFF   11
#define ED_BLC_START 12
#define ED_BLC_END   13

/*
 *	Menus hi�rarchiques
 */

typedef struct {
		char *string;
		OBJECT *mn_tree;
		int mn_menu, mn_item, mn_scroll;
	} SMENU;


/*******************************************************************************
	RSC header and support struct
*******************************************************************************/

typedef struct {		/* fichier ressource �tendu */
  UWORD rsh_vrsn;			/* should be 3														     */
  UWORD rsh_extvrsn;		/* not used, initialised to 'IN' for Interface */
  ULONG rsh_object;
  ULONG rsh_tedinfo;
  ULONG rsh_iconblk; 		/* list of ICONBLKS			  				 	*/
  ULONG rsh_bitblk;
  ULONG rsh_frstr;
  ULONG rsh_string;
  ULONG rsh_imdata;			/* image data					  					*/
  ULONG rsh_frimg;
  ULONG rsh_trindex;
  ULONG rsh_nobs; 			/* counts of various structs 					*/
  ULONG rsh_ntree;
  ULONG rsh_nted;
  ULONG rsh_nib;
  ULONG rsh_nbb;
  ULONG rsh_nstring;
  ULONG rsh_nimages;
  ULONG rsh_rssize;			/* total bytes in resource   */
} RSXHDR;

typedef struct {
	unsigned long	rlen;
	unsigned long	cicon_offset;
} NRSHDR;

#define	NRSC_CIBK			0x0004
#define	NRSC_LONG			0x0003

typedef struct {
	int			type;
	USERBLK		blk;
	long		spec;
	unsigned	user1;
	unsigned	user2;
	unsigned	user3;
	unsigned	user4;
	long		userl;
}	UBLK;

typedef struct _rsc {
	rscHDR	head;			/*	RSC Header			*/
	long	adr;			/*	Adr of memory bloc	*/
	long	len;			/*	Len of memory bloc	*/
	UBLK	*ublk;			/*	userdef array		*/
	CICON	*cicon;			/*	color icon array	*/
	XRSRCFIX fix;			/*  icone couleurs 		*/
} RSC;

typedef
struct slider {
	float min, max;
	float sinc, linc;
	int ori;		/* HORI,VERT*/
	int upd;		/* */
	float value;	/* valeur courante */
	void (*doslid)( WINDOW *win, int mode, float value, void *data); /* Pas fix� sur les sp�cifs */
	void *data;		/* user data for user function */
	int mode;
	WINDOW *win;
	int up, dn, sld, bsld;
} SLIDER;

/* Adpate la position de la boite curseur a la valeur 
 * Le curseur est place a 1 et non 0 par rapport au pere
 * c'est pour que ce soit joli (en frame = -2) */
#define SLID_OFFSET 0

int slid_newpos( void *_slid);

typedef struct _thumb {
	/* liens boutons <-> onglets */
	int *idxthb;
	int *idxbut;
	/* nombre d'onglets */
	int nbbut;
	/* onglet actif (index dans idxthb et idxbut) */
	int selbut;
} THUMB;

OBJECT *__xtype_trindex( int idx);

void frm_drw( WINDOW *win);
void frm_mvd( WINDOW *win);
void frm_tpd( WINDOW *win);
void frm_fld( WINDOW *win);
void frm_click( WINDOW *win);
void frm_keyhd( WINDOW *win);
void frm_dstry( WINDOW *win);
void frm_cls( WINDOW *win);


size_t realloc_xedit( size_t old, size_t len);
int xedit_mouse2curs( OBJECT *tree, int __index, int mx);
void win_xedit_bloc( WINDOW *win, W_FORM *wform, int __index);
void win_xedit_bloc_erase( WINDOW *win, W_FORM *wform, int __index);
void cell_curs( INT16 *wcell, INT16 *hcell);
int width_curs( W_XEDIT *xedit, int curs);
void shift_left( char *buf);
void xedit_add_char( W_XEDIT *xedit, char val);
void xedit_bloc( OBJECT *tree, int __index);
void xedit_curs( OBJECT *tree, int __index);

void * __malloc_obspec(OBJECT * p_ob, long size);
void __free_obspec( OBJECT * p_ob);

/*
 *  ajout de fonctions (arnaud 08/2001)
 */
int   scrap_txt_write( char *str);
char *scrap_txt_read ( void);

extern int 	(*__calc)	( struct _window *, int, INT16 *, INT16 *, INT16 *, INT16 *);
extern void (*__swgt)	( struct _window *, GRECT *, int);
extern int	(*__rfrm)	( struct _window *, struct _window *);

extern OBJECT * get_frame_slider ( void);
extern void set_gadget_pos( WINDOW *frame, GRECT *r1, int mode);
extern void __frame_set_widget( int parm1);
extern int remove_frame_from_list( WINDOW *win, WINDOW *child);
#define PROPOR( mode, wmax, w)	((mode)?((int)((long)wmax * (long)(w) / 100L)):(w))
#define NO_BACKGROUND	0x0002	/* interne */

extern void RsrcUserFree( OBJECT *);
extern int  is_modal 	( void);
extern int  obj_fd_flag	( OBJECT *, int, int);
extern int  obj_fd_xtype( OBJECT *dial, int racine, int flag);
extern int 	obj_nb		( OBJECT *);
extern int  obj_root    ( OBJECT *tree, int idx);
extern void	DataClear	( WINDOW *win);
extern void	AddWindow	( WINDOW *win);
extern void	RemoveWindow( WINDOW *win);
extern void	add_slash	( char *path);
extern void	init_scroll_menu( void);
extern WORD __CDECL draw_submenu( PARMBLK *pblk);
extern int is_title( OBJECT *tree, int __index);
extern void GemCode2Ascii( int key, int kstate, char *txt);
extern int GetIndexMenu( OBJECT *menu, int title);

extern void	menu_bind	( WINDOW *win, int item, int title);
extern void snd_rdw		( WINDOW *win);
extern void snd_msg		( WINDOW *win, int msg, int par1, int par2, int par3, int par4);

WORD __CDECL ub_xboxchar( PARMBLK *pblk);
WORD __CDECL ub_boxchar3d( PARMBLK *pblk);
WORD __CDECL ub_box3d	( PARMBLK *pblk);
void init_type			( OBJECT *tree, int __index, void *func, int extype);
void free_type			( OBJECT *tree, int __index);
int  get_next_obj		( OBJECT *tree, int __index);
void align_obj3d		( OBJECT *tree, int __index, int mode);

/* routines standards de stdcode.c 
 */

void std_cls	( WINDOW *);
void std_tpd	( WINDOW *);
void std_mvd	( WINDOW *);
void std_szd	( WINDOW *);
void std_fld	( WINDOW *);
void std_icn	( WINDOW *);
void std_unicn	( WINDOW *);
void std_allicn	( WINDOW *);
void std_arw	( WINDOW *);
void std_dnlnd	( WINDOW *);
void std_uplnd	( WINDOW *);
void std_lflnd	( WINDOW *);
void std_rtlnd	( WINDOW *);
void std_dnpgd	( WINDOW *);
void std_uppgd	( WINDOW *);
void std_rtpgd	( WINDOW *);
void std_lfpgd	( WINDOW *);
void std_vsld	( WINDOW *);
void std_hsld	( WINDOW *);
void std_dstry	( WINDOW *);
void std_btm	( WINDOW *);

void std_fntchg( WINDOW *win);

void move_screen( int vhandle, GRECT *screen, int dx, int dy);
void move_work(WINDOW *win, int dx, int dy);
void draw_page( WINDOW *win, int x, int y, int w, int h);
void std_mwk( WINDOW *win);


int  menu_exec_cmd( WINDOW *win);						/* menu.c */
void menu_draw	  ( WINDOW *win, int, int, int, int);	/* menu.c */
int  frm_menu	  ( WINDOW *win);						/* menu.c */
int  frm_keybd_ev ( OBJECT *tree);						/* dialog.c */
int  is_menu	  ( WINDOW *win);						/* menu.c */
/* Directive pour mon �tude de la taille des ex�cutables */
#if GFORM
int  frm_buttn_ev ( WINDOW *win, int mode);	 			/* dialog.c */
#endif
void _do_update( WINDOW *win);

void list_ev_msg( WINDOW *win, char *str);

void get_appname( char *name);

/*	Emulation des fonts Gdos */
struct fontid {
	char name[44];
	int  id;
	int flags;		/* monospaced, vectoriel, etc ... */
};
extern struct fontid *listfontid;
extern int maxfontid;
extern int load_fontid( void);
extern void close_fontid( void);

/* bubble GEM */
struct bubble {
	OBJECT *tree;
	int index;
	char *help;
	struct bubble *next;
};
extern struct bubble *bubble_index;
extern long __bubble_conf;
extern void snd_mu_button( int mbut, int nbclick);

extern long __cookieptr(void);

extern char __confpath [];

extern char *__confapp_buffer;
extern int __confapp_line_top;
extern int __confapp_line_pos;
extern char *__confdef_buffer;
extern int __confdef_line_top;
extern int __confdef_line_pos;


extern char *__av_name;					/* nom du client (notre appli) */
extern char __av_server[9];				/* nom du serveur AV */
extern INT16 __av_status[3];			/* action support�s par le serveur */

extern int _res;
extern int __bubble_quit;
extern int _menu_disabled;
extern WORD __windowlist[];
extern WORD __iconlist[];

#ifdef WINDOMDEBUG
	#define	LOGFILE	"C:\\gemsys\\log\\windom.log"
#endif

#endif /* __WINDOM_GLOBAL__ */
