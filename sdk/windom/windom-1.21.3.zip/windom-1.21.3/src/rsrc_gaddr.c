/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/rsrc_gaddr.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:22:06 $
 *   $Revision: 1.2 $
 */


#include <stddef.h>
#include <stdlib.h>
#include "globals.h"


/* utilisation avec RsrcXtype:
	RsrcXtype( mode, RsrcHdr(rsc)->trindex, RsrcHdr(rsc)->ntree);
 rem :  Les icones couleurs sont fix� avec RsrcXload()
 */


/*
 *	Lire un objet
 */

int RsrcGaddr( void *_rsc, int type, int index, void *addr) {
	RSC *rsc = _rsc;
	if( rsc) {
		switch( type) {
		case R_TREE:
			*(long*)addr = (long) (rsc->head.trindex[index]);
			break;
		case R_OBJECT:
			*(long*)addr = (long) (&rsc->head.object [index]);
			break;
		case R_TEDINFO:
			*(long*)addr = (long) (&rsc->head.tedinfo[index]);
			break;
		case R_ICONBLK:
			*(long*)addr = (long) (&rsc->head.iconblk[index]);
			break;
		case R_BITBLK:
			*(long*)addr = (long) (&rsc->head.bitblk[index]);
			break;
		case R_STRING:
		case R_FRSTR:
			*(long*)addr = (long) (rsc->head.frstr[index]);			
			break;
		case R_IMAGEDATA:
		case R_FRIMG:
			*(long*)addr = (long) (rsc->head.frimg[index]);
			break;
		case R_OBSPEC:
			*(long*)addr = (long) (&rsc->head.object[index].ob_spec);
			break;
		case R_TEPTEXT:
			*(long*)addr = (long) (rsc->head.tedinfo[index].te_ptext);
			break;
		case R_TEPTMPLT:
			*(long*)addr = (long) (rsc->head.tedinfo[index].te_ptmplt);
			break;
		case R_TEPVALID:
			*(long*)addr = (long) (rsc->head.tedinfo[index].te_pvalid);
			break;
		case R_IBPMASK:
			*(long*)addr = (long) (rsc->head.iconblk[index].ib_pmask);
			break;
		case R_IBPDATA:
			*(long*)addr = (long) (rsc->head.iconblk[index].ib_pdata);
			break;
		case R_IBPTEXT:
			*(long*)addr = (long) (rsc->head.iconblk[index].ib_ptext);
			break;
		case R_BIPDATA:
			*(long*)addr = (long) (rsc->head.bitblk[index].bi_pdata);
			break;
		default:
			return -1;
		}
		return 0;
	} else
		return rsrc_gaddr( type, index, addr);
}

