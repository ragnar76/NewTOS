/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/bubble_get.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:30:36 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 * Trouver l'id de BubbleGEM. Au besoin, le charger.
 */

int BubbleGet( void) {
	int bubble_id = appl_find("BUBBLE  ");

	if( bubble_id < 0 && _AESnumapps != 1) {
		char *value;
    	
    	shel_envrn( &value, "BUBBLE=");
    	if( !value) shel_envrn( &value, "BUBBLEGEM=");
    	if( value)
    		shel_write( 1, 1, 100, value, "");
    	else 
    		return -2;

    	evnt_timer( 500);
    	__bubble_quit = bubble_id = appl_find("BUBBLE  ");
	}
	return bubble_id;
}
