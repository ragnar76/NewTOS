/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_delete.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.3 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

int WindDelete( WINDOW *win) {
	int res=0;
	
	if( win->status & WS_OPEN)
		res = WindClose( win);

	DataClear( win);
	
	if( win->status & WS_FRAME)
		(*__rfrm)( WindHandle( win->handle), win);
	else {
		/* Pour ne pas d�truire la fen�tre */
		if( win->handle != -1)
			res = wind_delete( win -> handle);
		RemoveWindow( win);
	} 

	v_clsvwk( win -> graf.handle);
	if( win -> status & WS_TOOLBAR) {
		RsrcUserFree( win -> tool.root);
		ObjcFree( win -> tool.root);
		if( win -> tool.save) free( win -> tool.save);
		if( win -> tool.bind) free( win -> tool.bind);
	}
	if( win -> status & WS_MENU)
		ObjcFree( win -> menu.root);
	EvntClear( win);
	free( win);
	return res;
}

