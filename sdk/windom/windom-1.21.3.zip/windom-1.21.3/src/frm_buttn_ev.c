/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frm_buttn_ev.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/01 20:42:30 $
 *   $Revision: 1.3 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "userdef.h"


/*  Cette fonction remplace les fonctions form_().
 *	On ne peut pas utiliser ces fonctions principalement
 *	� cause de la s�lection des objets en arri�re plan
 *	qui merde : le dessin des objets ne tient pas compte
 *	des fen�tres.
 *
 *  Ces routines devraient logiquement aller dans FORM.C
 */	

static int __win_form_do( WINDOW *win, W_FORM *wform) {
	int res, debut; 
	OBJECT *tree = wform->root;
	INT16 mx, my, mbut, dum;
	BIND *bind = wform->bind;
	
	mx = evnt.mx;
	my = evnt.my;

	/* objet s�lectionn� */
	res = objc_find( tree, ROOTS, MAX_DEPTH, mx, my);
	if( res == -1)
		return -1;

	/* Binding variables */
	if( wform->bind && bind[res].var) {
		/* RADIO -> index */
		if( wform->root[res].ob_flags & RBUTTON)
			*(bind[res].var) = res;
		/* NORMAL -> �tat SELECTED */
		else if( wform->root[res].ob_flags & SELECTABLE) {
			if (wform->root[res].ob_state & SELECTED)
				*(bind[res].var) &= ~bind[res].bit;
			else
				*(bind[res].var) |= bind[res].bit;
		} else
			; /* A voir le reste */
	}

	/* Gestion des objets 'SELECTABLE' */
	if( tree[res].ob_flags & SELECTABLE) {
		/* Cas des objets desactiv�s */
		if( tree[res].ob_state & DISABLED)
			return -1;
		/* Cas des boutons radios */
		if( tree[res].ob_flags & RBUTTON) {
			if( !(tree[res].ob_state & SELECTED)) {
				debut = dum = res;
				while ( 1) { /* on deselectionne le bouton radio */
					if( dum != tree[tree[dum].ob_next].ob_tail)
						dum = tree[dum].ob_next;
					else
						dum = tree[tree[dum].ob_next].ob_head;
					if( dum == debut)
						break;
					if( (tree[dum].ob_flags & RBUTTON) && (tree[dum].ob_state & SELECTED)) {
						tree[dum].ob_state &= ~SELECTED;
						ObjcWindDraw( win, tree, dum, MAX_DEPTH, app.x, app.y, app.w, app.h);
						break;
					}
				}
				tree[res].ob_state |= SELECTED;
		    	ObjcWindDraw( win, tree, res, MAX_DEPTH, app.x, app.y, app.w, app.h);
			}
		}

		/* Cas des objets 'EXIT' */
		if( tree[res].ob_flags & EXIT) {
			do {
				dum = objc_find( tree, ROOTS, MAX_DEPTH, mx, my);				
				if( (tree[res].ob_state & SELECTED)==0 && res == dum) {
					tree[res].ob_state |= SELECTED;
					ObjcWindDraw( win, tree, res, MAX_DEPTH, app.x, app.y, app.w, app.h);
				}
				if( res != dum && (tree[res].ob_state & SELECTED)) {
					tree[res].ob_state &= ~SELECTED;
					ObjcWindDraw( win, tree, res, MAX_DEPTH, app.x, app.y, app.w, app.h);
				}
				graf_mkstate( &mx, &my, &mbut, &dum);
			} while( mbut);
			return( tree[res].ob_state & SELECTED)?res:-1;
		}
		/* Cas des boutons ni radio, ni exit, ni disabled */
		if( !(tree[ res].ob_flags & RBUTTON)) {
			if( tree[res].ob_state & SELECTED )
				tree[res].ob_state &= ~SELECTED;
			else
				tree[res].ob_state |= SELECTED;
		}
		ObjcWindDraw( win, tree, res, MAX_DEPTH, app.x, app.y, app.w, app.h);

		/* Cas objet TOUCHEXIT */
		if( tree[res].ob_flags & TOUCHEXIT)
			return res;
		else {
			/* Object non TOUCHEXIT: le bouton doit �tre relach� avant de sortir */
			do
				graf_mkstate( &dum, &dum, &mbut, &dum);
			while( mbut);
			return -1;
		}
	}	/* Fin objets selectable */
	
	/* Cas des objets 'TOUCHEXIT' */
	if( tree[res].ob_flags & TOUCHEXIT)
		return( res);

	if( !(tree[res].ob_state & SELECTABLE) &&
	    !(tree[res].ob_flags & TOUCHEXIT)  &&
	    win != wglb.front)
	    ApplWrite( app.id, WM_TOPPED, win->handle, 0, 0, 0, 0);

#ifdef MODIF_XEDIT

	/* Cas des objets 'XEDIT' systeme */
	if( (tree[res].ob_type & 0x00FF) == G_USERDEF 
		 && (tree[res].ob_type>>8) == XEDIT
		 && tree[res].ob_flags & EDITABLE) {
		
		graf_mkstate( &mx, &my, &mbut, &dum);

		/* �teindre le bloc (si besoin) */
		ObjcEdit( OC_FORM, win, res, 0, &dum, ED_BLC_OFF);

		/* �teindre le curseur du champs pr�c�dent */
		ObjcEdit( OC_FORM, win, wform->edit, 0, &wform->cursor, ED_END);

		/* Un clic � la souris positionne le curseur */
		if( !mbut) { 
	
			/* positionner le curseur */
			wform->cursor = xedit_mouse2curs( tree, res, evnt.mx);
			ObjcEdit( OC_FORM, win, res, 0, &wform->cursor, ED_CURS);

			/* Allumer curseur */
			ObjcEdit( OC_FORM, win, res, 0, &wform->cursor, ED_INIT);		
			
			wform->edit = res;
		} else {
			/* Un clic prolong� s�lectionne un bloc */
			W_XEDIT *xedit = (W_XEDIT *)tree[res].ob_spec.userblk->ub_parm;
			int beg, inter, last;
			INT16 xpos, ypos;
			
			if( app.aes4 & AES4_XGMOUSE)
				graf_mouse( M_SAVE, 0L); 
			graf_mouse( POINT_HAND, 0L); 
			xedit -> blcbeg = beg = xedit_mouse2curs( tree, res, evnt.mx);
			xedit -> blcend = last = beg;
			objc_offset( tree, res, &xpos, &ypos);
			do {
				inter = xedit_mouse2curs( tree, res, mx);
/*				if( inter <= xedit->pos && inter >= 0) {
					xedit->pos --;
					ObjcWindDraw( win, tree, res, 0, xpos, ypos, 
							  	  tree[res].ob_width, tree[res].ob_height);
				} else
 				if( width_curs( xedit, inter) > tree[res].ob_width) {
 					xedit->pos ++;
					ObjcWindDraw( win, tree, res, 0, xpos, ypos, 
							  	  tree[res].ob_width, tree[res].ob_height);
				} */
				if( inter > last) {
					xedit -> blcbeg = last;
					xedit -> blcend = inter;
					win_xedit_bloc( win, wform, res);
					last = inter;
				} else if( inter < xedit -> blcbeg) {
					xedit -> blcend = last;
					xedit -> blcbeg = inter;
					win_xedit_bloc( win, wform, res);
					last = inter;
				}
				graf_mkstate( &mx, &my, &mbut, &dum);

			} while ( mbut);

			if( !(app.aes4 & AES4_XGMOUSE) || graf_mouse( M_RESTORE, 0L) == 0 )
				graf_mouse(ARROW,NULL);
			if( last > beg) {
				xedit -> blcbeg = beg;
				xedit -> blcend = last;
			} else {
				xedit -> blcend = beg;
				xedit -> blcbeg = last;			
			}
			xedit -> flags |= XEDIT_BLOC_ON;
		}
	} else

#endif /* MODIF_XEDIT */

	/* Cas des objets 'EDITABLE' systeme */
	if( tree[res].ob_flags & EDITABLE) {
		int offset;
		INT16 tab[8];
		INT16 x,dx,pos=0;
		char *p;
		int ind, len;
		
		/* �teindre le curseur */
		ObjcEdit( OC_FORM, win, wform->edit, 0, &wform->cursor, ED_END);
		wform->edit = res;

		/*
		 *	Positionner le curseur � la souris
		 *  calculer les coordonn�es du texte ....
		 */
		
		/* Position souris par rapport au cot� gauche de l'objet */
		objc_offset( tree, res, &x, &dx);
		x = evnt.mx-x;

		/* Largeur du champ */ 		
 		p = tree[res].ob_spec.tedinfo->te_ptmplt;
		if( vq_vgdos() == _FSM) 
			vqt_f_extent( app.aeshdl, p, tab);
		else
			vqt_extent(app.aeshdl, p, tab);
		dx = tab[2] - tab[0] /* + offset? */;
		
		/* d�calage du texte par rapport � l'objet */
		switch (tree[res].ob_spec.tedinfo->te_just) {
			case 0:	/* align� � gauche */
				offset = 0;
				break;
			case 1:	/* align� � droite */
				offset = tree[res].ob_width - dx;
				break;
			case 2:	/* centr� */
				offset = (tree[res].ob_width - dx)/2;
				break;
			default:
				offset = 0;
		}
		
		/* Calcul de la position du curseur */
 		p = strdup( tree[res].ob_spec.tedinfo->te_ptmplt);
		pos = (int)strlen( p);
		do {
			if( vq_vgdos() == _FSM) 
				vqt_f_extent( app.aeshdl, p, tab);
			else
				vqt_extent(app.aeshdl, p, tab);
			if( p[pos] != '_' && x >= tab[2]-tab[0]+offset)
				break;
			p[--pos] = '\0';
		} while( pos);

		/* on compte les caract�res non �ditables qui restent */
		for( ind = 0, len = 0; ind < pos; ind ++)
			if( p[ind] != '_')
				len ++;
		
		/* nouvelle position du curseur */
		wform->cursor = MIN( pos - len, (int)strlen(tree[res].ob_spec.tedinfo->te_ptext));
		if( wform->edit != res && wform->edit != -1)
			ObjcEdit( OC_FORM, win, wform->edit, 0, &pos, ED_END);
		ObjcEdit( OC_FORM, win, res, 0, &wform->cursor, ED_INIT);
		wform->edit = res;		
		free(p);
	}
	return( -1);
}

/*
 *	Ev�nement souris dans les formulaires
 */

int frm_buttn_ev( WINDOW *win, int mode) {
	W_FORM *tree;
	int res;
		
	switch( mode) {
	case OC_FORM:
		tree = DataSearch( win, WD_WFRM);
		break;
	case OC_TOOLBAR:
		tree = &win->tool;
		break;
	default:
		return -1;
	}
	
	res = __win_form_do( win, tree);

	/* Binding fonction */
	if( res != -1 && tree->bind && ((BIND *)tree->bind)[res].fnc) {
		void (*f)( WINDOW *, int, int, void *);
		
		f = ((BIND *)tree->bind)[res].fnc;
		(*f)( win, res, mode, ((BIND *)tree->bind)[res].data);
	}
	
	return res;
}

