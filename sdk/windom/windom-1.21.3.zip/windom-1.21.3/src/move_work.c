/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/move_work.c,v $
 * Module : standard event window callback
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/02 20:44:51 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

void move_screen( int vhandle, GRECT *screen, int dx, int dy) {
	INT16 xy[ 8];
	long dum = 0L;
	GRECT g;
	
	/* on intersecte avec l'�cran */
	wind_get( 0, WF_CURRXYWH, &g.g_x, &g.g_y, &g.g_w, &g.g_h);
	rc_intersect( &g, screen);
	xy[ 0] = screen -> g_x;
	xy[ 1] = screen -> g_y;
	xy[ 2] = xy[ 0] + screen -> g_w - 1;
	xy[ 3] = xy[ 1] + screen -> g_h - 1;
	xy[ 4] = xy[ 0] + dx;
	xy[ 5] = xy[ 1] + dy;
	xy[ 6] = xy[ 2] + dx;
	xy[ 7] = xy[ 3] + dy;
	vro_cpyfm( vhandle, S_ONLY, xy, (MFDB *)&dum, (MFDB *)&dum);
}

void move_work(WINDOW *win, int dx, int dy) {
	INT16 x,y,w,h;
	GRECT rect, r1, r2, screen;

	if (dx || dy) 
	{
		WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
		while( !wind_update(BEG_UPDATE));
		graf_mouse( M_OFF, 0L);		
		rc_set( &rect, x, y, w, h);
		wind_get_grect( 0, WF_CURRXYWH, &screen);
		wind_get( win -> handle, WF_FIRSTXYWH, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
		while (r1.g_w && r1.g_h) {
			if( rc_intersect( &rect, &r1) && rc_intersect( &screen, &r1)) {
				if ( (abs(dx) < r1.g_w) && (abs(dy) < r1.g_h) )
				{
					r2 = r1; /* save */
					if (dy > 0) {
						r1.g_y += dy;
						r1.g_h -= dy;
					} else {
						r1.g_h += dy;
					}
					if (dx > 0) {
						r1.g_x += dx;
						r1.g_w -= dx;
					} else {
						r1.g_w += dx;
					}
					move_screen( win->graf.handle, &r1, - dx, - dy);
					if (dx)
					{
						r1 = r2 ;  /* restore */
						if (dx > 0) {
							r1.g_x += r1.g_w - dx;
							r1.g_w = dx;
						} else {
							r1.g_w = - dx;
						}
						if (dy > 0) {
							r1.g_h -= dy;
						} else {
							r1.g_y -= dy;
							r1.g_h += dy;
						}
						rc_clip_on( win->graf.handle, &r1);
						EvntExec( win, WM_REDRAW);
						rc_clip_off( win->graf.handle);
					}
					if (dy)
					{
						r1 = r2 ;  /* restore */
						if (dy > 0) {
							r1.g_y += r1.g_h - dy;
							r1.g_h = dy;
						} else {
							r1.g_h = - dy;
						}
						rc_clip_on( win->graf.handle, &r1);
						EvntExec( win, WM_REDRAW);
						rc_clip_off( win->graf.handle);
					}
				}
				else
				{
					rc_clip_on( win->graf.handle, &r1);
					EvntExec( win, WM_REDRAW);
					rc_clip_off( win->graf.handle);
				}
			}
			wind_get( win -> handle, WF_NEXTXYWH, &r1.g_x, &r1.g_y, &r1.g_w, &r1.g_h);
		}
		graf_mouse( M_ON, 0L);
		wind_update(END_UPDATE);
		if (dx) WindSlider( win, HSLIDER);
		if (dy) WindSlider( win, VSLIDER);
	}
}
