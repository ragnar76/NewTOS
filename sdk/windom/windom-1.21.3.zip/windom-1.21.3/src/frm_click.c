/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frm_click.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:18:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 * Routine de gestion des clics souris
 */
 
void frm_click( WINDOW *win) {
	int res;
#if !GFORM
	W_FORM *form = DataSearch( win, WD_WFRM);
#endif
	if( !(evnt.mbut & 0x01))
		return;
#if GFORM
	res = frm_buttn_ev( win, OC_FORM);
#else
	res = objc_find( form->root, ROOT, MAX_DEPTH, evnt.mx, evnt.my);			
#endif
	if( res != -1)  /* On g�n�re un �v�nement WM_FORM au lieu du MU_BUTTON) */
		snd_msg( win, WM_FORM, res, evnt.nb_click, evnt.keybd, 0);
}
