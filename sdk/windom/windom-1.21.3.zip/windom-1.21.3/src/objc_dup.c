/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_dup.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:07 $
 *   $Revision: 1.1 $
 */


#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "userdef.h"

OBJECT *ObjcDup( OBJECT *src, WINDOW *win) {
	OBJECT *cpy;
	int nb = obj_nb( src), i;
	USERBLK *user;
	USER_DRAW *udraw;
	W_PARM *wparm;
	long mem_size;
	char * mem_adr;
	TEDINFO *tedinfo;
	
	cpy = (OBJECT *)malloc(sizeof(OBJECT)*nb);
	if( !cpy )
		return NULL;
	memcpy( cpy, src, sizeof(OBJECT)*obj_nb( src));
	for( i = 0; i < nb; i++) {
		switch( src[i].ob_type & 0x00FF) {
		case G_TEXT:
		case G_FTEXT:
		case G_BOXTEXT:
		case G_FBOXTEXT:
			cpy[i].ob_spec.tedinfo = (TEDINFO *)malloc( sizeof( TEDINFO));
			memcpy( cpy[i].ob_spec.tedinfo, src[i].ob_spec.tedinfo, sizeof(TEDINFO));
			mem_size = (cpy[i].ob_spec.tedinfo->te_txtlen + 1) * 2;
			mem_size += cpy[i].ob_spec.tedinfo->te_tmplen + 1;
			mem_adr = __malloc_obspec(&cpy[i],mem_size);
			if (src[i].ob_spec.tedinfo->te_ptext) {
				cpy[i].ob_spec.tedinfo->te_ptext = mem_adr;
				strncpy(mem_adr,src[i].ob_spec.tedinfo->te_ptext,cpy[i].ob_spec.tedinfo->te_txtlen);
			}
			mem_adr += cpy[i].ob_spec.tedinfo->te_txtlen + 1;
			if (src[i].ob_spec.tedinfo->te_pvalid) {
				cpy[i].ob_spec.tedinfo->te_pvalid = mem_adr;
				strncpy(mem_adr,src[i].ob_spec.tedinfo->te_pvalid,cpy[i].ob_spec.tedinfo->te_txtlen);
			}
			mem_adr += cpy[i].ob_spec.tedinfo->te_txtlen + 1;
			if (src[i].ob_spec.tedinfo->te_ptmplt) {
				cpy[i].ob_spec.tedinfo->te_ptmplt = mem_adr;
				strncpy(mem_adr,src[i].ob_spec.tedinfo->te_ptmplt,cpy[i].ob_spec.tedinfo->te_tmplen);
			}
			break;
		case G_STRING:
		case G_BUTTON:
		case G_TITLE:
			cpy[i].ob_spec.free_string = __malloc_obspec(&cpy[i],strlen( src[i].ob_spec.free_string)+1);
			strcpy(cpy[i].ob_spec.free_string,src[i].ob_spec.free_string);
			break;
		case G_USERDEF:
			switch (src[i].ob_type >> 8) {
			case XCICON :
/* !!! FIX ME !!! */
				/* cas particulier des icones: on ne fait qu'un    */
				/* lien vers l'original (pas de copie en m�moire   */
				/* de l'icone ni du champ texte associ�).          */
				/* Un volontaire pour faire mieux ?                */
				break;
			case USERDRAW:
				user = (USERBLK *)malloc( sizeof(USERBLK));
				memcpy( user, src[i].ob_spec.userblk, sizeof(USERBLK));
				cpy[i].ob_spec.userblk = user;
				udraw = (USER_DRAW *)malloc( sizeof(USER_DRAW));
				memcpy( udraw, (void*)user->ub_parm, sizeof(USER_DRAW));
				udraw -> win  = win;
				user->ub_parm = (long)udraw;
				break;
			default:
				user = (USERBLK *)malloc( sizeof(USERBLK));
				memcpy(user,src[i].ob_spec.userblk,sizeof(USERBLK));
				cpy[i].ob_spec.userblk = user;
				wparm = (W_PARM*)malloc( sizeof(W_PARM));
				memcpy(wparm,(void*)user->ub_parm,sizeof(W_PARM));
				user -> ub_parm = (long)wparm;
				switch (wparm->wp_type & 0x00FF) {
				case G_TEXT:
				case G_FTEXT:
				case G_BOXTEXT:
				case G_FBOXTEXT:
					tedinfo = (TEDINFO *)malloc( sizeof( TEDINFO));
					memcpy( tedinfo, (void*)wparm->wp_spec, sizeof(TEDINFO));
					mem_size = (tedinfo->te_txtlen + 1) * 2;
					mem_size += tedinfo->te_tmplen + 1;
					mem_adr = __malloc_obspec(&cpy[i],mem_size);
					if (((TEDINFO*)(wparm->wp_spec))->te_ptext) {
						tedinfo->te_ptext = mem_adr;
						strncpy(mem_adr,((TEDINFO*)(wparm->wp_spec))->te_ptext,tedinfo->te_txtlen);
					}
					mem_adr += tedinfo->te_txtlen + 1;
					if (((TEDINFO*)(wparm->wp_spec))->te_pvalid) {
						tedinfo->te_pvalid = mem_adr;
						strncpy(mem_adr,((TEDINFO*)(wparm->wp_spec))->te_pvalid,tedinfo->te_txtlen);
					}
					mem_adr += tedinfo->te_txtlen + 1;
					if (((TEDINFO*)(wparm->wp_spec))->te_ptmplt) {
						tedinfo->te_ptmplt = mem_adr;
						strncpy(mem_adr,((TEDINFO*)(wparm->wp_spec))->te_ptmplt,tedinfo->te_tmplen);
					}
					wparm->wp_spec = (long)tedinfo;
					break;
				case G_STRING:
				case G_BUTTON:
				case G_TITLE:
					mem_adr = __malloc_obspec(&cpy[i],strlen((char*)wparm->wp_spec)+1);
					strcpy(mem_adr,(char*)wparm->wp_spec);
					(char*)wparm->wp_spec = mem_adr;
					break;
				}
			}
			break;
		}
	}
	return cpy;
}
