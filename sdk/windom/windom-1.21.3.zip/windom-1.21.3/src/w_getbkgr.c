/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/w_getbkgr.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:32:32 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 *		Sauvegarde portion d'�cran
 */

void w_get_bkgr(int of_x, int of_y, int of_w, int of_h, MFDB *img) {
	INT16 pxy[8], work[57];
	unsigned long taille;
	MFDB ecr = {0};		/* Ecran logique */

	vq_extnd( app.handle, 1, work);
		
	/* Taille tampon de copie fond */
	/* work[4] = nombre de plans */

	taille = ((((unsigned long)(of_w / 16) + ((of_w % 16) != 0)) * 2 * (long)work[ 4]) * (unsigned long)of_h) + 256; 
#ifdef __SOZOBONX__
	img->fd_addr = lalloc( taille);			/* R�server tampon */
#else
	img->fd_addr = malloc( taille);			/* R�server tampon */
#endif
	img->fd_w = of_w;		/* Remplir la structure MFDB */
	img->fd_h = of_h;
	img->fd_wdwidth = (of_w / 16) + ((of_w % 16) != 0);
	img->fd_stand = 1;
	img->fd_nplanes = work[ 4];

	pxy[0] = of_x;		/* Remplir le tableau */
	pxy[1] = of_y;
	pxy[2] = pxy[0] + of_w - 1;
	pxy[3] = pxy[1] + of_h - 1;
	pxy[4] = 0;
	pxy[5] = 0;
	pxy[6] = of_w - 1;
	pxy[7] = of_h - 1;
	v_hide_c ( app.handle);				/* Virer la souris */
	vro_cpyfm ( app.handle, S_ONLY, pxy, &ecr, img);	/* Copier l'image */
	v_show_c ( app.handle, 1);		/* Remettre la souris */
}
