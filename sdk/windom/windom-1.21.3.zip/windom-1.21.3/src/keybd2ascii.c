/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/keybd2ascii.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:07 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 * R�cup�re le vrai code ascii d'un �vement clavier
 * scancode = valeur associ�e � l'�v�nement MUKEYBD, 
 *			  champ evnt.keybd ou retour de la fonction 
 *			  evnt_keybd()
 * shift = 1 : shift actif, 0 shift non actif.
 * retour: code ascii de la touche ou 0 si la touche n'a pas
 * 		   de valeur ascii (on utilise alors le scancode).
 */

typedef struct {
        char *unshift;
        char *shift;
        char *capslock;
} MY_KEYTAB;

int keybd2ascii( int keybd, int shift) {
	MY_KEYTAB *key;
	key = (MY_KEYTAB *)Keytbl( (char*)-1, (char*)-1, (char*)-1);
	return (shift)?key->shift[keybd>>8]:key->unshift[keybd>>8];
}

