/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/conf_inquire.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:30:11 $
 *   $Revision: 1.1 $
 */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"

/*
 *	Lecture d'une ligne dans un buffer <ptr>
 */
static char *sgets( char *line, long size, char *ptr) {
	char *e=ptr;
	
	line[size-1] = '\0';			/* cas ou l'on d�passe */
	while( *ptr != '\0' &&
		   *ptr != '\n' &&
		   ptr-e < size-1) {
		*line++ = *ptr++;
	}
	if( *ptr =='\n') {
		ptr ++;
		*line = '\0';
	}
	return ptr;
}

/*
 * interrogation d'une variable dans __conf_buffer
 */

static int conf_inquire( char *buffer, char *keyword, char *fmt, va_list args) {
	char buf[LINE_SIZE], cmd[30], *p, *q, *s;
	int res = -1;
	void *ptr;
	unsigned int bit;
	char *pos = buffer;

	if( pos == NULL)
		return -33;
	while( *pos) {
		/* Lire une ligne */
		pos = sgets( buf, LINE_SIZE, pos);
		if(*buf == '#' || *buf=='\n')
			continue;
		sscanf( buf, "%s", cmd);
		if( !stricmp( cmd, keyword)) {
			res = 0;
			/* �valuer les valeurs: a faire nous-meme */
			p = strchr( buf, '=');
/*			va_start( args, fmt); */
			q = fmt;
			while( *q) {
				q = strchr( q, '%');
				if( p)
					p++;
				else
					break;
				res ++;
				if( q)
					switch( *++q) {
					case 'd':
					case 'x':
						ptr = (void*)va_arg( args, int *);
						sscanf( p, (*q=='d')?"%d":"%x", ptr);
						break;						
					case 'f':
						ptr = (void*)va_arg( args, float *);
						sscanf( p, "%f", (float*)ptr);
						break;
					case 'c':
						ptr = (void*)va_arg( args, char *);
						p = strchr( p , '\'');
						if( p) 
							sscanf( p+1, "%c", (char*)ptr);
						else	res --;
						break;
/*
					case 's':
						ptr = (void*)va_arg( args, char *);
						sscanf( p, "%s", ptr);
						s = strchr( ptr, ',');
						if( s) *s='\0';
						break;
					case 'S':
						ptr = (void*)va_arg( args, char *);
						p = strchr( p, '"');
						if( p) {
							strcpy( ptr, p+1);
							*strchr( ptr, '"') = '\0';
							p = strchr( p+1, '"');
						} else res--;
						break;
*/
					case 's':
					case 'S':
						ptr = (void*)va_arg( args, char *);
						s = strchr( p, '"');
						if( s) {
							strcpy( ptr, s+1);
							*strchr( ptr, '"') = '\0';
							p = strchr( s+1, '"');
						} else /* res--; */ {
							sscanf( p, "%s", (char*)ptr);
							s = strchr( ptr, ',');
							if( s) *s='\0';
						}
						break;
					case 'B':
					case 'b':
						ptr = (void *)va_arg( args, unsigned int *);
						if( *q == 'B') bit = va_arg( args, unsigned int);
						else		   bit = 0x1;
						sscanf( p, "%s", cmd);
						s = strchr( cmd, ',');
						if( s) *s='\0';
						if( !stricmp( cmd, "true") ||
							!stricmp( cmd, "on")   ||
							!strcmp ( cmd, "1"))
							SET_BIT( *(unsigned int *)ptr, bit, TRUE);
						else
						if( !stricmp( cmd, "false") ||
							!stricmp( cmd, "off")   ||
							!strcmp ( cmd, "0"))
							SET_BIT( *(unsigned int *)ptr, bit, FALSE);
						else
							res --;
						break;
					default:
						res --;
					}
				p = strchr( p, ',');
			}
	/*		va_end( args); */
			break;
		} else 
			if( !stricmp( cmd, "[end]"))
				break;	/* fin de la boucle */
	}
	return res;
}

int ConfInquire( char *keyword, char *fmt, ...) {
	va_list args;
	int res;
	
	va_start( args, fmt);
	res = conf_inquire( __confapp_buffer, keyword, fmt, args);
	va_end( args);	
	if( res < 0) {
		va_start( args, fmt);
		res = conf_inquire( __confdef_buffer, keyword, fmt, args);
		va_end( args);
	}
	return res;
}


