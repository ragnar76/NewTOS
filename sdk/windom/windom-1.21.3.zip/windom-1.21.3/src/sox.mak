#!make -f
#
# WinDom: a high level GEM library
# Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
#
# $Source: /cvsroot/windom/windom/src/sox.mak,v $
# Makefile for 'WinDOM' an its utility
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/11/30 12:50:20 $
#  $Revision: 1.3 $

#
# makefile for windom 
# sozobonx version


# note:
# CC_SOX must point to your cc.ttp program
# AR_SOX must point to your ar.ttp program

CC     = $(CC_SOX)
AS     = $(AS_SOX)
AR     = $(AR_SOX)

CFLAGS= -O -I../include -DMODIF_XEDIT $(XCFLAGS)

# add bug-free strdup() (the one in xdlibs is bugged)
EXTRAOBJ  = strdup.o

include files.mak

.SUFFIXES:
.SUFFIXES: .c .S .o

.c.o:
	$(CC) $(CFLAGS) -c $*.c -o $*.o

TARGET = $(LIB_SOZOBON)

$(TARGET): $(WINDOMOBJ)
	rm -f $@
	$(AR) -r $@ $^
