/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/menu_disable.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:04 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

int MenuDisable( void) {
	if( !app.menu) return 1;
	if( _menu_disabled == 0) {
	int index = 3;
	
		while( is_title( app.menu, index++))
			app.menu[index].ob_state = DISABLED;
		while( app.menu[ index].ob_type != G_STRING)
			index++;
		app.menu[index].ob_state = DISABLED;
		menu_bar( app.menu, 1);
	}
	_menu_disabled ++;
	return 0;
}
