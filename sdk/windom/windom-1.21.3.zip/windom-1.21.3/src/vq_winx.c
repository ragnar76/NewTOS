/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/vq_winx.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:45:20 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"
#include "cookie.h"

/********************* WinX ***************************/

/* Test la version de WinX */

int vq_winx( void) {
	if( get_cookie( WINX_COOKIE, NULL))	{
		struct winx_version {
				unsigned int beta  :4;
				unsigned int major :4;
				unsigned int minor :4;
				unsigned int intern:4;
			} vers;
		INT16 dummy;
		
		if( wind_get( 0, WF_WINX, (INT16*)&vers, &dummy, &dummy, &dummy) == WF_WINX)
			return ((vers.major << 8) | vers.minor);
		else
			/* version ant�rieur � la 2.1 */
			return 0x0100;
	} else
		return 0;	/* WinX pas en m�moire */
}
