/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frame_set.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/01 20:00:06 $
 *   $Revision: 1.3 $
 */

#include <stdarg.h>
#include <stdlib.h>
#include "globals.h"

void FrameSet( WINDOW *win, int mode, ...) {
	va_list args;
	int parm1=0, parm2=0;
	WINDOW *wparm=NULL;
	FRAME *frame;
	
	va_start( args, mode);
	if( mode == FRAME_ACTIV)
		wparm = va_arg( args, WINDOW*);
	else {
		parm1 = va_arg( args, int);
		parm2 = va_arg( args, int);
	}

	if( win->status & WS_FRAME_ROOT) {
		frame = DataSearch( win, WD_WFRA);
		switch( mode) {
		case FRAME_BORDER:
			frame->border = parm1;
			break;
		case FRAME_COLOR:
			frame->color = parm1;
			break;
		case FRAME_KEYBD:
			SET_BIT( frame->flags, FLG_KEYMOUSE, parm1);
			break;
		case FRAME_NOBG:
			SET_BIT( frame->flags, NO_BACKGROUND, parm1);
			break;
		case FRAME_ACTIV:
			/* set the given frame active, and enable the gadget */
			if( !(GETFINFO(wparm)->flags & FRAME_SELECT))
				break;
			if( win->status & WS_OPEN) {
				GRECT r;
			
				if( frame->front &&
					frame->front != wparm ) {
					FrameCalc( frame->front, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
					set_gadget_pos( frame->front, &r, 0x1|0x2|0x4);
				}
				
				FrameCalc( wparm, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h); 		
				set_gadget_pos( wparm, &r, 0x1|0x2);
			}
			frame->front = wparm;
			frame->widget = wparm;
			break;
		case FRAME_TOPPED_ACTIV:
			SET_BIT( frame->flags, FRAME_ACTIV, parm1);
			break;
		}
	}

	if( win->status & WS_FRAME) {
		FRAMEINFO *finfo = GETFINFO(win);
		switch( mode) {
		case FRAME_SIZE:
			finfo->w = parm1;
			finfo->h = parm2;
			break;
		case FRAME_FLAGS:
			/* set or unset specificied bit */
			SET_BIT( finfo->flags, parm1, parm2);
			break;
		}
	}
	va_end( args);
}
