/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/set_cookie.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:00:17 $
 *   $Revision: 1.1 $
 */

#ifdef __PUREC__
	/* Pure C poss�de des librairies non standard */
	#include <tos.h>
#else
	/* Gnu C, Sozobon, Lattice */
#ifdef __SOZOBONX__
#include <atari.h>  /* MUST be included before osbind.h */
#endif
	#include <osbind.h>
	#include <fcntl.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include "globals.h"

int set_cookie(long cookie, long value) {
	long *cookiejar = (long *)Supexec (__cookieptr);
	
	if (cookiejar) {
		while (*cookiejar) {
			if (*cookiejar==cookie) {
				if (value)
					*++cookiejar = value;
				return( 1);
			}
			cookiejar += 2;
		}
	}
	return( 0);
}
