/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/conf_write.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:30:09 $
 *   $Revision: 1.1 $
 */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"

#ifndef FA_SUBDIR
#define FA_SUBDIR 0x10
#endif

/*
 *	Ecriture dans le fichier de configuration
 */

static char *find_word( char *buffer, char *find) {
	char *p, *q = buffer;
	do {
		p = strstr( q, find);
		if( p && (q == p || *(p-1) == '\n'))
			return p;
		q = p;
	} while( p);
	return 0L;
}


static int is_dir( char *path, char *dir) {
	char buf[255];
	int res;

	strcpy( buf, path);
	add_slash( buf);
	strcat( buf, dir);
	res = Fattrib( buf, 0, 0);
	if( res == -33) return 0;
	if( res & FA_SUBDIR) {
		strcpy( __confpath, buf);
		add_slash( __confpath);
		return 1;
	} else
		return 0;
}

int ConfWrite( char *name, char *fmt, ...) {
	va_list args;
	FILE *fp;
	char *buf, save, *p, *q, *s;
	size_t size;
	char nameprg[20];
	int found = 1;
	
	get_appname( nameprg);	
	fp = fopen( __confpath, "r");
	if( fp == NULL) {
		/* Cr�er un fichier ad�quat */
		shel_envrn( &p, "HOME=");
		if( p && is_dir( p, "Defaults"))
			;
		else if( p && is_dir( p, ""))
			;
		else if( is_dir( ".", ""))
			;
		if( vq_extfs(__confpath))
			strcat( __confpath, ".windomrc");
		else
			strcat( __confpath, "windom.cnf");
		
		fp = fopen( __confpath, "w");

		fprintf( fp, "# WinDom configuration file\n%s\n", nameprg);
		if( fmt) {
			fprintf( fp, "%s = ", name);
			va_start( args, fmt);
			vfprintf( fp, fmt, args);
			va_end( args);
			fprintf( fp, "\n");
		}
		fprintf( fp, "[end]\n");
		fclose( fp);
		return 0;
	}

	/* Charger le fichier,
	 * le modifier,
	 * puis sauvegarder
	 */

	fseek( fp, 0L, 2);
	size = ftell( fp);
	fseek( fp, 0L, 0);
	buf = (char *)malloc(sizeof(char)*size);
	if( !buf) {
		fclose( fp);
		return 0;
	}
	size = fread( buf, sizeof(char), size, fp);
	buf[size] = '\0';

	fclose( fp);
	
	/* Trouvons la bonne balise */
	
	p = find_word( buf, nameprg);

	/* On essai la balise par defaut */
	if( p == NULL) p = find_word( buf, "[Default Settings]");
	
	if( p == NULL) {
		/* Cr�er la balise qui va bien � la fin
		 * du fichier */
		fp = fopen( __confpath, "a");
		fprintf( fp, "\n%s\n", nameprg);
		fprintf( fp, "%s = ", name);
		if( fmt) {
			va_start( args, fmt);
			vfprintf( fp, fmt, args);
			va_end( args);
			fprintf( fp, "\n");
		}
		fprintf( fp, "[end]\n");
		fclose( fp);
		return 0;
	} else {
		/* La balise existe, recherche de la variable */

		/* Pour rester dans le bon champ */
		s = find_word( p, "[end]");
		*s = '\0';
		q = find_word( p, name);
		*s = '[';
		
		if( q == NULL) {
			/* La variable n'existe pas, on l'ajoute */
			q = find_word( p, "[end]");
			found = 0;
		}
		p = q;
		
		/* Ecriture du d�but */
		save = *p;
		*p = '\0';
		fp = fopen( __confpath, "w");
		fwrite( buf, sizeof( char), strlen( buf), fp);
		*p = save;

		if( fmt) {
			/* Ecriture de la variable */
			fprintf( fp, "%s = ", name);
			va_start( args, fmt);		
			vfprintf( fp, fmt, args);
			va_end( args);
			fprintf( fp, "\n");
		}

		/* Ecriture de la fin */	
		if( found) p = strchr( p, '\n')+1;
		size = strlen( p)+1;
		fwrite( p, sizeof( char), size, fp);
		fclose( fp);
	}
	return 0;
}

