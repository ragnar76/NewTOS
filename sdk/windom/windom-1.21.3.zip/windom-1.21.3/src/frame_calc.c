/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frame_calc.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 19:24:15 $
 *   $Revision: 1.2 $
 */


#include <stdlib.h>
#include "globals.h"
#include "sliders.h"

/*
 *	mode = 0: workxywh
 *	     = 1: currxywh
 */


int FrameCalc( WINDOW *win, int mode, INT16 *_x, INT16 *_y, INT16 *_w, INT16 *_h) {
	WINDOW *root = WindHandle( win->handle), *scan;
	int line;
	INT16 xc, yc, wc, hc;
	INT16 x, y, w, h;
	GRECT r1,r2;
	FRAME *frame = DataSearch( root, WD_WFRA);
	FRAMEINFO *finfo;

	/* if the frame is closed */
	if( !(win->status & WS_OPEN)) {
		*_x = *_y = *_w = *_h = 0;
		return 0;
	}
	
	/* Get the size of the root window */
	wind_get( root -> handle, WF_CURRXYWH, &xc, &yc, &wc, &hc);
	WindCalc( 1, root, xc, yc, wc, hc, &x, &y, &w, &h);
	rc_set( &r1, x, y, w, h);
	scan = frame->list;
	line = GETFINFO(scan)->line;
	hc = 0;
	for(; scan;scan=scan->next) {
		/* new line */
		finfo = GETFINFO(scan);
		if( finfo->line > line) {
			line = finfo->line;
			y += hc + frame->border;
			hc = 0;
		} 
 		hc = MAX( hc, PROPOR( finfo->flags & FRAME_HSCALE, h, finfo->h));
		if( scan == win) break;
		/* we've got the right line. Now, go to next column */
		if( finfo->line == GETFINFO(win)->line) 
			x += PROPOR( finfo->flags & FRAME_WSCALE, w, finfo->w) 
				  + frame->border;
	}
	
	/* TODO : Warning, here finfo may be uninitialised */
	w = PROPOR( finfo->flags & FRAME_WSCALE, w, GETFINFO(win)->w);
	h = PROPOR( finfo->flags & FRAME_HSCALE, h, GETFINFO(win)->h);
	
	/* Intersection between root area and frame area */
	rc_set( &r2, x, y, w, h);
	rc_intersect( &r1, &r2);
	x = r2.g_x; y = r2.g_y; w = r2.g_w; h = r2.g_h;
	
	/* the widgets */
	if( mode == 0 && !(win->status & WS_ICONIFY)) {
		OBJECT *tree = get_frame_slider();
		
		if( scan->attrib & (UPARROW|DNARROW|VSLIDE|SIZER))
			w -= tree[M_V_BG].ob_width - 1;
		if( scan->attrib & (LFARROW|RTARROW|HSLIDE))
			h -= tree[M_H_BG].ob_height - 1;
		if( scan->attrib & INFO) {
			y += tree[M_INFO].ob_height+1;
			h -= tree[M_INFO].ob_height+1;
		}
	}
	*_x = x;
	*_y = y;
	*_w = w;
	*_h = h;
	return 0; 
}
