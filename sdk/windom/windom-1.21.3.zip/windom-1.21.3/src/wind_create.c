/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_create.c,v $
 *
 * CVS info:
 *   $Author: bereziat $
 *   $Date: 2003/07/17 15:34:10 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*************************************************************/
/*	======  Pseudo Fonctions librairie Windows	     ======= */
/*************************************************************/

WINDOW* WindCreate( int GemAttrib, int x, int y, int w, int h) {
	WINDOW* win;
	INT16 handle, dum;

	if( !(CONF(app)->flag & FLG_MNSYSTEM)) GemAttrib &= ~MENUBAR;
	handle = wind_create( GemAttrib, x, y, w, h);
	if( handle < 0) {
#ifdef WINDOMDEBUG
		form_alert( 1, "[1][WINDOM warning:|Impossible to create a window.][Ok]");
#endif
		return NULL;
	}
	win = (WINDOW *) malloc( sizeof( WINDOW));
	if( win == NULL) {
		wind_delete( handle);
		return NULL;
	}
	rc_set( &win->createsize, x, y, w, h);
	win->attrib = GemAttrib;
	win->w_min 	= win->h_min = 40;
	win->status = WS_GROW;
	win->w_max 	= w;
	win->h_max 	= h;
	win->graf.handle = graf_handle( &dum, &dum, &dum, &dum);
	v_opnvwk( app.work_in, &win->graf.handle, app.work_out);
	win -> graf.palette = NULL;

	win->next    = NULL;
	win->handle  = handle;
	win->binding = NULL;

	EvntAttach( win, WM_REDRAW, WindClear);
	EvntAttach( win, WM_CLOSED, std_cls);
	EvntAttach( win, WM_TOPPED, std_tpd);
	EvntAttach( win, WM_BOTTOMED, std_btm);
	EvntAttach( win, WM_MOVED , std_mvd);
	EvntAttach( win, WM_SIZED , std_szd);
	EvntAttach( win, WM_FULLED, std_fld);
	EvntAttach( win, WM_ICONIFY, std_icn);
	EvntAttach( win, WM_UNICONIFY, std_unicn);
	EvntAttach( win, WM_ALLICONIFY, std_allicn);
	EvntAttach( win, WM_ARROWED, std_arw);
	EvntAttach( win, WM_UPPAGE, std_uppgd);
	EvntAttach( win, WM_DNPAGE, std_dnpgd);
	EvntAttach( win, WM_LFPAGE, std_lfpgd);
	EvntAttach( win, WM_RTPAGE, std_rtpgd);	
	EvntAttach( win, WM_UPLINE, std_uplnd);
	EvntAttach( win, WM_DNLINE, std_dnlnd);
	EvntAttach( win, WM_LFLINE, std_lflnd);
	EvntAttach( win, WM_RTLINE, std_rtlnd);
	EvntAttach( win, WM_VSLID , std_vsld);
	EvntAttach( win, WM_HSLID , std_hsld);
	EvntAttach( win, WM_DESTROY, std_dstry);

	win -> xpos 	= win -> ypos = 0;
	win -> xpos_max = win -> ypos_max = 1;
	win -> w_u = win -> h_u = 1;
	win -> menu . root = NULL;
	win -> menu . bind = NULL;
	win -> menu . hilight = NULL;
	win -> tool . root = NULL;
	win -> tool . save = NULL;
	win -> tool . bind = NULL;
	win -> icon . draw = NULL;
	win -> icon . name = NULL;
	AddWindow( win);
	win->data = NULL;
	win->type = 0;
	win->name = win->info = NULL;
	return win;	
}
