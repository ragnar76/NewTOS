/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_thumb.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:22:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*******************************************************
 * Gestion automatique des onglets 
 *******************************************************/


/* Fonction qui sera li�e aux boutons des onglets (priv�e) */

static void thumb_do( WINDOW *win, int obj, int dummy, void *data) {
	W_FORM *form = DataSearch( win, WD_WFRM);
	THUMB *thumb = data;
	int i, idx;

	/* index du bouton s�lectionn� dans thumb->button */
	idx = -1;
	for( i=0; i<thumb->nbbut; i++) {
		if( thumb->idxbut[i] == obj) {
			idx = i;
			break;
		}
	}
	
	/* bouton trouv� et nouveau bouton */
	if( idx != -1 && idx != thumb -> selbut) {
		/* montrer le nouvel onglet */
		form->root[thumb->idxthb[idx]].ob_flags &= ~HIDETREE;
		/* cacher l'ancien onglet */
		form->root[thumb->idxthb[thumb->selbut]].ob_flags |= HIDETREE;
		/* button actif */
		thumb->selbut = idx;
		form->edit = -1; 	/* WinDom bug */
		/* dessin de l'onglet */
		ObjcDraw( OC_FORM, win, thumb->idxthb[idx], MAX_DEPTH);
		/* dessin du bouton */
		ObjcDraw( OC_FORM, win, thumb->idxbut[idx], 0);
	}
}

/* Lib�ration de l'onglet, maintenant statique */

static void FormThbFree( WINDOW *win, void *data) {
	THUMB *thumb = data;
	UNUSED (win);
	free( thumb->idxthb);
	free( thumb->idxbut);
	free( thumb);
}

/* Cr�ation de l'onglet */

void *FormThumb( WINDOW *win, int *idxthb, int *idxbut, int nb) {
	W_FORM *form = DataSearch( win, WD_WFRM);
	THUMB *thumb;
	int i;
	
	thumb = (THUMB*)malloc( sizeof( THUMB));
	if( !thumb)	{
		app.error = ENSMEM;
		return NULL;
	}
	thumb -> idxthb = malloc( sizeof(int)*nb);
	if( !thumb -> idxthb) {
		free( thumb);
		app.error = ENSMEM;
		return NULL;
	}
	thumb -> idxbut = malloc( sizeof(int)*nb);
	if( !thumb -> idxbut) {
		free( thumb->idxthb);
		free( thumb);
		app.error = ENSMEM;
		return NULL;
	}
	for( i=0; i<nb; i++) {
		thumb -> idxthb[i] = idxthb[i];
		thumb -> idxbut[i] = idxbut[i];
		ObjcAttach( OC_FORM, win, idxbut[i], BIND_FUNC, thumb_do, thumb);
	}
	thumb -> nbbut = nb;
	thumb -> selbut = 0;
	EvntDataAdd( win, WM_DESTROY, FormThbFree, thumb, EV_TOP);

	if( form) {
		for(i=0; i<nb; i++) {
			form->root[idxthb[i]].ob_flags |= HIDETREE;
			form->root[idxbut[i]].ob_state &= ~SELECTED;
			form->root[idxbut[i]].ob_flags |= RBUTTON;
		}
		form->root[idxthb[0]].ob_flags &= ~HIDETREE;
		form->root[idxbut[0]].ob_state |= SELECTED;
	}
	
	return thumb;
}
