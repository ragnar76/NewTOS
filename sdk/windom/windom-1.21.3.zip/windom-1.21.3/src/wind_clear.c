/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_clear.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/***********************************************************/
/* WindClear: erase the window's work area.                */
/***********************************************************/

void WindClear( WINDOW *win) {
	INT16 x, y, w, h;
	INT16 xy[4];

	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	xy[0] = x;xy[1] = y;xy[2] = x+w-1;xy[3] = y+h-1;
	vsf_interior( win->graf.handle, CONF(app)->bgpatt);
	vsf_style( win->graf.handle, CONF(app)->bgstyle);
	if( CONF(app)->bgcolor < app.color)
		vsf_color( win->graf.handle, CONF(app)->bgcolor);
	else
		vsf_color( win->graf.handle, WHITE);
		
	v_bar( win->graf.handle, xy);
}

