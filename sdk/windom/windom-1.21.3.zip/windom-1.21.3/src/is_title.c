/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/is_title.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:12 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "userdef.h"

int is_title( OBJECT *tree, int idx) {	
	if( tree[idx].ob_type == G_TITLE)
		return 1;
	if( tree[idx].ob_type == ((MENUTITLE << 8) | G_USERDEF)) {
		USERBLK *user = tree[idx].ob_spec.userblk;
		if( ((W_PARM*)user->ub_parm)->wp_type == ((MENUTITLE << 8) | G_TITLE))
			return 1;
	}
	return 0;
}
