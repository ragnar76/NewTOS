/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_free.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:04 $
 *   $Revision: 1.1 $
 */


#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "userdef.h"

#define PARM( ldata)	(((W_PARM *)(ldata))->wp_spec)

void ObjcFree( OBJECT *cpy) {
	int i, nb = obj_nb( cpy);
	for( i=0; i<nb; i++)
		switch( cpy[i].ob_type & 0xFF) {
		case G_TEXT:
		case G_FTEXT:
		case G_BOXTEXT:
		case G_FBOXTEXT:
			__free_obspec( &cpy[i]);
			free( cpy[i].ob_spec.tedinfo);
			break;
		case G_STRING:
		case G_BUTTON:
		case G_TITLE:
			__free_obspec( &cpy[i]);
			break;
		case G_USERDEF:
			switch ( cpy[i].ob_type >> 8 ) {
			case  XCICON:
				/* rien � faire (cf ObjcDup) */
				break;
			case USERDRAW:
				free( (void*)cpy[i].ob_spec.userblk->ub_parm);
				free( cpy[i].ob_spec.userblk);
				break;
			default:
				switch ( ((W_PARM*)(cpy[i].ob_spec.userblk->ub_parm))->wp_type & 0x00FF) {
				case G_TEXT:
				case G_FTEXT:
				case G_BOXTEXT:
				case G_FBOXTEXT:
					__free_obspec( &cpy[i]);
					free( (void*)PARM(cpy[i].ob_spec.userblk->ub_parm));
					break;
				case G_STRING:
				case G_BUTTON:
				case G_TITLE:
					__free_obspec( &cpy[i]);
					break;
				}
				free( (void*)cpy[i].ob_spec.userblk->ub_parm);
				free( cpy[i].ob_spec.userblk);
			}
			break;
		}
	free( cpy);
}
