/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/appl_set.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:37:43 $
 *   $Revision: 1.1 $
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "globals.h"
#include "cookie.h"
#include "fsel.h"
#include "wsystem.h"

static void set_value( int *var, int val) {
	if( val != -1)
		*var = (short)val;
}

int ApplSet( int mode, ...) {
	short v1, v2, v3, v4;
	va_list list;
	
	if( !CONF(app)) return 2;
	
	va_start( list, mode);
	v1 = va_arg( list, short);
	v2 = va_arg( list, short);
	v3 = va_arg( list, short);
	v4 = va_arg( list, short);
	va_end( list);

	switch( mode) {
	case APS_ICONSIZE:
		set_value( &CONF(app)->hicon, v1);
		set_value( &CONF(app)->wicon, v2);
		break;
	case APS_FLAG:
		/* set_value( (int *)&CONF(app)->flag , v1); */
		SET_BIT( CONF(app)->flag , v1, v2);
		break;
	case APS_WINBG:
		set_value( &CONF(app)->bgcolor, v1);
		set_value( &CONF(app)->bgpatt,  v2);
		set_value( &CONF(app)->bgstyle, v3);
		break;
	case APS_KEYCOLOR:
		set_value( &CONF(app)->key_color, v1);
		break;
	case APS_STRSTYLE:
		set_value( &CONF(app)->string.font, v1);
		set_value( &CONF(app)->string.size, v2);
		set_value( &CONF(app)->string.color, v3);
		break;
	case APS_BUTSTYLE:
		set_value( &CONF(app)->button.font, v1);
		set_value( &CONF(app)->button.size, v2);
		set_value( &CONF(app)->button.color, v3);
		break;
	case APS_EXITSTYLE:
		set_value( &CONF(app)->exit.font, v1);
		set_value( &CONF(app)->exit.size, v2);
		set_value( &CONF(app)->exit.color, v3);
		break;
	case APS_TITLESTYLE:
		set_value( &CONF(app)->title.font, v1);
		set_value( &CONF(app)->title.size, v2);
		set_value( &CONF(app)->title.color, v3);
		break;
	case APS_3DEFFECT:
		set_value( &CONF(app)->actmono, v1);
		set_value( &CONF(app)->actcol, v2);
		break;
	case APS_MENUEFFECT:
		set_value( &CONF(app)->menu_effect, v1);
		break;
	case APS_BUBBLESTYLE:
		set_value( &CONF(app)->bubble.font, v1);
		set_value( &CONF(app)->bubble.size, v2);
		break;
	case APS_POPUPSTYLE:
		set_value( &CONF(app)->popcolor, v1);
		set_value( &CONF(app)->popborder, v2);
		set_value( &CONF(app)->popfcolor, v3);
		set_value( &CONF(app)->poppatt, v4);
		break;
	case APS_POPUPWIND:
		set_value( &CONF(app)->popwind, v1);
		break;
	case APS_WINDOWS:
		set_value( &CONF(app)->wcenter, v1);
		set_value( &CONF(app)->weffect, v2);
		set_value( &CONF(app)->mwidget, v3);
		break;
	case APS_XEDITTEXTSTYLE:
		set_value( &CONF(app)->xedit_text.font, v1);
		set_value( &CONF(app)->xedit_text.size, v2);
		set_value( &CONF(app)->xedit_text.color, v3);
		break;
	case APS_XEDITLABELSTYLE:
		set_value( &CONF(app)->xedit_label.font, v1);
		set_value( &CONF(app)->xedit_label.size, v2);
		set_value( &CONF(app)->xedit_label.color, v3);
		break;
	case APS_XTEDINFOSTYLE:
		set_value( &CONF(app)->xtedinfo.font, v1);
		set_value( &CONF(app)->xtedinfo.size, v2);
		set_value( &CONF(app)->xtedinfo.color, v3);
		set_value( &CONF(app)->xtdinf_smlfnt, v4);
		break;
	case APS_XLONGEDITSTYLE:
		set_value( &CONF(app)->xlongedit.font, v1);
		set_value( &CONF(app)->xlongedit.size, v2);
		set_value( &CONF(app)->xlongedit.color, v3);
		set_value( &CONF(app)->xlgedt_smlfnt, v4);
		break;
	case APS_FRAMEWIDGETSIZE:
		{
			void __frame_set_widget( int);
			set_value( &CONF(app)->fwidsize, v1);
			if( v1 != -1) __frame_set_widget( v1);
		}
	default:
		return 1;
	}
	return 0;
}

