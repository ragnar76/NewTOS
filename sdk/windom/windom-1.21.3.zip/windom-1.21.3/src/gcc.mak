#!make -f
#
# WinDom: a high level GEM library
# Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
#
# $Source: /cvsroot/windom/windom/src/gcc.mak,v $
# Makefile for 'WinDOM' an its utility
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/11/30 20:13:12 $
#  $Revision: 1.4 $

#
# makefile for windom 
# gcc >= 2.95.3 (sparemint) version
#

ifeq ($(CROSS),yes)
CC     = m68k-atari-mint-gcc
AR     = m68k-atari-mint-ar
else
CC     = gcc
AR     = ar
endif

WARN = \
	-Wall \
	-Wmissing-prototypes \
	-Winline \
	-Wshadow \
	-Wpointer-arith \
	-Wcast-qual \
	-Waggregate-return
	
CFLAGS= -O2 -fomit-frame-pointer $(WARN) -I../include -DMODIF_XEDIT $(XCFLAGS)

# no extra objects for GCC
EXTRAOBJ  = 

include files.mak

.SUFFIXES:
.SUFFIXES: .c .S .o

.c.o:
	$(CC) $(CFLAGS) -c $*.c -o $*.o

TARGET = $(LIB_GCC)

$(TARGET): $(WINDOMOBJ)
	rm -f $@
	$(AR) cru $@ $^

install:
ifeq ($(CROSS),yes)
	cp -vf ../include/windom.h /usr/m68k-atari-mint/include
	cp -vf ../lib/gcc/libwindom.a /usr/m68k-atari-mint/lib
else
	cp -vf ../include/windom.h /usr/include
	cp -vf ../lib/gcc/libwindom.a /usr/lib
endif
