/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:08 $
 *   $Revision: 1.1 $
 */

#include <stdarg.h>
#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/* Fonctions et variables attach�es aux objets �tendus *
 * Attention aux formulaires multiples et menus 
 * Deux cas :
 *	->	une variable attribu�e � un objet:
 *		sa mise-a-jour se fait dans la routine USERDEF
 *			bouton check : val = 0,1
 *			bouton radio : val = index objet
 *			popup : je ne sais pas faire, il me faudrait un nouveau type.
 *			le reste : rien pour le momment
 *	->	une fonction : elle ne se d�clenche que si l'objet
 *		est effectivement s�lectionn� : dans la routine de gestion
 *		des clicks. Ne marche donc que sur les SELECTABLE.
 */

/* mode = menu,form,toolbar  *
 * type = function, variable */

#define BIND_VAR 	1
#define BIND_FUNC 	2
#define BIND_BIT	3

int ObjcAttach( int mode, WINDOW *win, int index, int type, ...) {
	BIND   *bind = NULL;
	W_FORM *wfrm = NULL;  /* pour ne pas avoir de warning gcc */
	OBJECT *tree = NULL;  /* idem */
	va_list arg;
	
	va_start( arg, type);
	switch( mode) {
	case OC_MENU:
		if( win) {
			/* a faire */
			if( win->menu.bind == NULL)
				win->menu.bind = (BIND*)calloc( obj_nb(win->menu.root), sizeof(BIND));
			bind = win->menu.bind;
			tree = win->menu.root;
		} else {
			if( app.mnbind == NULL)
				app.mnbind = (BIND*)calloc( obj_nb(app.menu), sizeof(BIND));
			bind = app.mnbind;
			tree = app.menu;
		}
		break;
	case OC_TOOLBAR:
		if( win->tool.bind == NULL)
			win->tool.bind = (BIND*)calloc( win->tool.nb_ob, sizeof(BIND));
		bind = win->tool.bind;
		tree = win->tool.root;
		break;
	case OC_FORM:
		if( (wfrm = DataSearch( win, WD_WFRM)) != NULL) {
			if( wfrm->bind == NULL)
				wfrm->bind = (BIND*)calloc( wfrm->nb_ob, sizeof(BIND));
			bind = wfrm->bind;
			tree = wfrm->root;
		}
		break;
	default:
		return EBADRQ;
	}
	if( bind) {
		switch( type) {
		case BIND_VAR:
		case BIND_BIT:
			if( type == BIND_BIT) {
				bind[index].var = (void*) va_arg( arg, unsigned int*);
				bind[index].bit = va_arg( arg, unsigned int);
			} else {
				bind[index].var = va_arg( arg, int*);
				bind[index].bit = 0x1;
			}
			/* En plus, on met � jour l'�tat de l'objet */
			switch( mode) {
			case OC_TOOLBAR:
			case OC_FORM:
				if( tree[index].ob_flags & RBUTTON)
					SET_BIT( tree[index].ob_state, SELECTED, (index == *(int*)bind[index].var)?1:0);
				else if( wfrm->root[index].ob_flags & SELECTABLE)
					SET_BIT( tree[index].ob_state, SELECTED, ((*(int*)bind[index].var) & bind[index].bit)?1:0);
			break;
			case OC_MENU:
				MenuIcheck( win, index, ((*(int*)bind[index].var) & bind[index].bit)?1:0);
				break;
			}
			break;
		case BIND_FUNC:
			bind[index].fnc = va_arg( arg, void*);
			bind[index].data = va_arg( arg, void*);			
			break;
		default:
			return ERANGE;
		}
	}
	va_end( arg);
	return E_OK;
}
