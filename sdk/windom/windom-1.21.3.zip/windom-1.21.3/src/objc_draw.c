/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_draw.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/22 21:05:08 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 *	Du bonne usage des fonction Objc et objc_:
 *
 *	1)
 *	La fonction ObjcDraw() dessine un objet
 *	dans une fenetre. Cela concerne uniquement
 *	les formulaires et les toolbars. Ces fonctions
 *	ne DOIVENT PAS etre appele depuis les routines
 *	de dessin de contenue de fen�tre car elles utilisent
 *  la liste des rectangles de l'AES.
 *	rem: Ces fonctions redessinnent imm�diatement les objects
 *	elles n'envoient pas de message WM_REDDRAW clipp� sur 
 *	l'objet.
 *	2)
 *	pour dessiner un objet dans une fenetre et dans la routine
 *	de dessin, il faut utiliser objc_draw() ou objc_change()
 *	et le clip en utilisant la variable globale clip. Cette
 *	variable contient en permanence la zone clipp� a redessin�.
 *  rem: clip est mise a jour par les fonctions set_clip() et
 *	et clip_off(). Dans une routine de dessin, il ne faut
 *	JAMAIS clipper puis que c'est le systeme (EvntWindom)
 *	qui s'en charge.
 *	3)
 *	Pour les formulaire classique, ie pas en fenetre, on utilise
 *	objc_draw() et objc_change() comme d'hab.
 *
 */

int ObjcDraw( int mode, void *win, int index, int depth) {
	INT16 x,y;
	int r, res;
	OBJECT *tree;
	
	switch( mode) {
	case OC_FORM:
		tree = FORM((WINDOW*)win);
		break;
	case OC_TOOLBAR:
		tree = TOOL((WINDOW*)win);
		break;
	case OC_OBJC:
		tree = (OBJECT *)win;
		break;
	case OC_MENU:
		tree = ((WINDOW*)win)->menu.root;
		break;
	default:
		return EBADRQ;
	}
	objc_offset( tree, index, &x, &y);
	r = 6;
	if( mode == OC_OBJC) 
		res = objc_draw( tree, index, depth, x-r, y-r, 
				tree[index].ob_width + 2*r, 
				tree[index].ob_height + 2*r);
	else if( depth & OC_MSG) {
		snd_msg( win, WM_REDRAW, x - r, y - r, 
					tree[index].ob_width + 2*r, 
					tree[index].ob_height + 2*r);
		res = E_OK;
	} else
		res = ObjcWindDraw( win, tree, index, depth, x - r, y - r, 
							tree[index].ob_width + 2*r, 
							tree[index].ob_height + 2*r);
	return res;
}
