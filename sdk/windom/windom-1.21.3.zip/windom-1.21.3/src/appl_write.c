/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/appl_write.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:37:43 $
 *   $Revision: 1.1 $
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "globals.h"
#include "cookie.h"
#include "fsel.h"
#include "wsystem.h"

/* A more pratical call to appl_write() */

#ifndef __MSHORT__

/* en 32bits, on attend des 'int' plutot que '...' (va_args) en parametre */
/* car c'est le seul moyen d'�viter l'utilisation du code genre           */
/* ApplWrite( to, msg, "tralala");                                        */
/* qui fonctionne uniquement en 16 bits si on utilise va_args             */

int ApplWrite( int to, int msg, int b3, int b4, int b5, int b6, int b7) {
	INT16 buf[8];

	buf[0] = msg;
	buf[1] = app.id;
	buf[2] = 0;
	buf[3] = b3;
	buf[4] = b4;
	buf[5] = b5;
	buf[6] = b6;
	buf[7] = b7;
	return appl_write( to, 16, buf);
}

#else 

int ApplWrite( int to, int msg, ...) {
	va_list args;	
	short buf[8];

	buf[0] = msg;
	buf[1] = app.id;
	buf[2] = 0;
	va_start( args, msg);
	buf[3] = va_arg( args, short);
	buf[4] = va_arg( args, short);
	buf[5] = va_arg( args, short);
	buf[6] = va_arg( args, short);
	buf[7] = va_arg( args, short);
	va_end( args);
	return appl_write( to, 16, buf);
}
#endif

