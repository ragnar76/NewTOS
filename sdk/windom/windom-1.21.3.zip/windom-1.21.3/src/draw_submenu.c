/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/draw_submenu.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:26:05 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

WORD __CDECL draw_submenu( PARMBLK *pblk) {
	/* 1er: dessiner l'item
	 * 2nd: afficher le sub menu
	 */
	INT16 tab[10], hcar;
	INT16 mx,my,but,dum;
	OBJECT *tree;
	MFDB scr;
	
	 	/* Clippage */
	tab[0]=pblk->pb_xc;
	tab[1]=pblk->pb_yc;
	tab[2]=pblk->pb_wc+tab[0]-1;
	tab[3]=pblk->pb_hc+tab[1]-1;
	vs_clip( app.handle, 1, tab);

	vqt_attributes( app.handle, tab);
	hcar = tab[7];
	
	tab[0]=pblk->pb_x;
	tab[1]=pblk->pb_y;
	tab[2]=pblk->pb_w+tab[0]-1;
	tab[3]=pblk->pb_h+tab[1]-1;

	vswr_mode( app.handle, MD_REPLACE);
	vsf_color( app.handle, WHITE);
	v_bar( app.handle, tab);

	v_gtext( app.handle, pblk->pb_x, pblk->pb_y + pblk->pb_h/2+hcar/2-1, 
			((SMENU *)pblk->pb_parm)->string);
	
	if( pblk->pb_currstate & SELECTED) {
		vswr_mode( app.handle, MD_XOR);
		vsf_color( app.handle, BLACK);
		vsf_interior( app.handle, 1 /*FIS_SOLID*/ );
		tab[0] --;tab[1] --;
		tab[2] ++;tab[3] ++;
		v_bar( app.handle, tab);
	}
	vs_clip( app.handle, 0, tab);

	if( /*((SMENU *)pblk->pb_parm)->mn_scroll &&*/ pblk->pb_currstate & SELECTED) {
		tree = ((SMENU *)pblk->pb_parm)->mn_tree;
		tree->ob_x = pblk->pb_x+pblk->pb_w;
		tree->ob_y = pblk->pb_y;
		w_get_bkgr( tree->ob_x-3, tree->ob_y-3, tree->ob_width-5, tree->ob_height-5, &scr);
/*		objc_draw( tree, 0, MAX_DEPTH, app.x, app.y, app.w, app.h); */
		v_show_c( app.handle, 1);
		while( !wind_update (BEG_MCTRL));
		do{
			graf_mkstate( &mx, &my, &but, &dum);
			dum = objc_find(tree, 0, 7, mx, my);
		}while( dum != -1 && tree[dum].ob_type != G_TITLE);
		
		v_hide_c( app.handle);
		wind_update (END_MCTRL);
		w_put_bkgr( tree->ob_x-3, tree->ob_y-3, tree->ob_width+5, tree->ob_height+5, &scr);
		((SMENU *)pblk->pb_parm)->mn_scroll = 0;
	}

	if( pblk->pb_currstate & SELECTED)
		((SMENU *)pblk->pb_parm)->mn_scroll = 1;
	else
		((SMENU *)pblk->pb_parm)->mn_scroll = 0;

	return 0;
}
