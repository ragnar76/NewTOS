/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/form_wbegin.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/04/18 20:21:41 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include "globals.h"

/*****************************************
 * Dialogue en fen�tre modale
 *****************************************/

static void _form_wind_close( void) {
	WINDOW *win = WindHandle( evnt.buff[3]);

	FormAttach( win, NULL, NULL);
	WindClose( win);
	WindDelete( win);
	MenuEnable();
}

WINDOW *FormWindBegin( OBJECT *dial, char *nom) {
	WINDOW *win;

	win = FormCreate( dial, CONF(app)->mwidget, NULL, nom, NULL, 1, 0);
	if( win == NULL) return NULL;
	/* EvntDelete( win, WM_DESTROY); */
	EvntAttach( win, WM_DESTROY, _form_wind_close);
	MenuDisable();
	WindSet( win, WF_BEVENT, BEVENT_MODAL, 0, 0, 0);
	return win;
}
