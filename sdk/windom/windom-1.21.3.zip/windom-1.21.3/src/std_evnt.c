/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/std_evnt.c,v $
 * Module : standard event window callback
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/08 18:53:03 $
 *   $Revision: 1.3 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

void std_cls( WINDOW *win) {	
	snd_msg( win, WM_DESTROY,0,0,0,0);
}

void std_mvd( WINDOW *win) {	
	wind_set( evnt.buff[3], WF_CURRXYWH, evnt.buff[4], evnt.buff[5], evnt.buff[6], evnt.buff[7]);
	win->status &= ~WS_FULLSIZE;
}

void std_tpd( WINDOW *win) {
	WindSet( win, WF_TOP, win->handle, 0, 0, 0);
	wglb.appfront = wglb.front = win;
}

void std_szd( WINDOW *win) {
	INT16 x, y, w, h;
	int rdw = 0;
	unsigned long oldx, oldy;
	
	w = MAX( evnt.buff[6], win -> w_min);
	h = MAX( evnt.buff[7], win -> h_min);
	w = MIN( w           , win -> w_max);
	h = MIN( h           , win -> h_max);

	wind_set( evnt.buff[3], WF_CURRXYWH, evnt.buff[4], evnt.buff[5], w, h);

	/* Cas une fenetre de contenu proportionnel ie qui ne 
	   depend pas des win->x etc .. */
	
	if( win->xpos == 0 && win->xpos_max == 1 &&
		win->ypos == 0 && win->ypos_max == 1)
		rdw = 1;
		
	/* Nouvelle version : Gere les cas ou la fenetre est + grande
		que les 'tailles' des donn�es */
		
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	oldx = win -> xpos;
	oldy = win -> ypos;
	if( (unsigned int)w > win -> xpos_max * win -> w_u)
		win -> xpos = 0;
	else
		win -> xpos = MIN( win -> xpos, win -> xpos_max - w / win -> w_u);

	if( (unsigned int)h > win -> ypos_max * win -> h_u)
		win -> ypos = 0;
	else
		win -> ypos = MIN( win -> ypos, win -> ypos_max - h / win -> h_u);

	/*    fin    */

	if( oldx != win -> xpos || oldy != win -> ypos)
		rdw = 1;
	WindSlider( win, HSLIDER|VSLIDER);
	win->status &= ~WS_FULLSIZE;
	if( rdw) snd_rdw( win);
}

void std_fld( WINDOW *win) {
	INT16 x, y, w, h;

	if( win->status & WS_FULLSIZE) {
		wind_get( evnt.buff[3], WF_PREVXYWH, &x, &y, &w, &h);
		wind_set( evnt.buff[3], WF_CURRXYWH, x, y,  w, h);
	} else
		wind_set(evnt.buff[3], WF_CURRXYWH, app.x, app.y, win->w_max, win->h_max);
	
	win->status ^= WS_FULLSIZE;

	/* Cas une fenetre de contenu proportionnel ie qui ne 
	   depend pas des win->x etc .. */
	
	if( win->xpos == 0 && win->xpos_max == 1 &&
		win->ypos == 0 && win->ypos_max == 1)
		snd_rdw( win);
		
	/* Nouvelle version : Gere les cas ou la fenetre est + grande
		que les 'tailles' des donn�es */
		
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	if( (unsigned int)w > win -> xpos_max * win -> w_u)
		win -> xpos = 0;
	else
		win -> xpos = MIN( win -> xpos, win -> xpos_max - w / win -> w_u);

	if( (unsigned int)h > win -> ypos_max * win -> h_u)
		win -> ypos = 0;
	else
		win -> ypos = MIN( win -> ypos, win -> ypos_max - h / win -> h_u);

	/*    fin    */

	WindSlider( win, HSLIDER|VSLIDER);
}

void std_icn( WINDOW *win) {
	WindSet( win, WF_ICONIFY, evnt.buff[4], evnt.buff[5], evnt.buff[6], evnt.buff[7]);
	WindSet( win, WF_BOTTOM, win->handle, 0, 0, 0);
	if( win->icon.name)
		wind_set_str( win->handle, WF_NAME, win->icon.name);
}

void std_unicn( WINDOW *win) {
	if( win->status & WS_ALLICNF) {
		WINDOW *scan;
		
		MenuEnable();
		for( scan=wglb.first; scan; scan=scan->next) {
			if( scan != win && scan->status & WS_ALLICNF) {
				WindOpen( scan, scan->icon.x, scan->icon.y, scan->icon.w, scan->icon.h);
				scan->status &= ~WS_ALLICNF;
			/*	EvntWindom( MU_MESAG); */
			}
		}
		win->status &= ~WS_ALLICNF;
		WindSet( win, WF_TOP, win->handle, 0, 0, 0);
	}
	WindSet( win, WF_UNICONIFY, evnt.buff[4], evnt.buff[5], evnt.buff[6], evnt.buff[7]);
	WindSet( win, WF_TOP, win->handle, 0, 0, 0);
	if( win->name)
		wind_set_str( win->handle, WF_NAME, win->name);
}

void std_allicn( WINDOW *win)
{
	WINDOW *scan;
	
	MenuDisable();

	/* On ferme toutes les fen�tres, sauf celle ci */
	for( scan = wglb.first; scan; scan=scan->next) {
		if( scan->status & WS_OPEN && scan != win) {
			scan->status |= WS_ALLICNF;
			WindGet( scan, WF_CURRXYWH, &scan->icon.x, &scan->icon.y, &scan->icon.w, &scan->icon.h);
			WindClose( scan);
		/*	EvntWindom( MU_MESAG); */
		}
	}
	win->status |= WS_ALLICNF;
	/* On iconifie notre fen�tre */
	std_icn( win);
}



/*
	void std_dnpgd( WINDOW *):
		fonction standart pour le champs win->dnpaged.
*/

void std_dnpgd( WINDOW *win) {
	int page;
	INT16 x,y,w,h;
	long old_pos = win -> ypos;
	int dy;

	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	page = h / win -> h_u;
	if ( win -> ypos < win -> ypos_max - page) {
		win -> ypos = MIN( win->ypos_max, win->ypos) + page;
		win -> ypos = MIN( win -> ypos, win -> ypos_max - page);
		dy = (int) ((win->ypos - old_pos) * win->h_u);
		move_work(win,0,dy);
	}
}

/*
	void std_uppgd( WINDOW *):
		fonction standart pour le champs win->uppaged.
*/

void std_uppgd( WINDOW *win) {
	long pos;
	INT16 d, h;
	int dy;

	if ( win -> ypos > 0L) {
		WindGet( win, WF_WORKXYWH, &d, &d, &d, &h);
		pos = MAX( 0L, win->ypos - h / win->h_u);
		dy = (int) ((pos - win->ypos) * win->h_u);
		win->ypos = pos;
		move_work(win,0,dy);
	}
}

/*
	void std_uplnd( WINDOW*):
		fonction standart pour le champs win->uplined.
*/

void std_uplnd( WINDOW *win) {
	if ( win -> ypos > 0L) {
		win->ypos --;
		move_work(win,0, - win->h_u);
	}
}

/*
	void std_dnlnd( WINDOW *):
		fonction standart pour le champs win->dnlined.
*/

void std_dnlnd( WINDOW *win) {
	INT16 x, y, w, h;

	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	if (( win -> ypos < win -> ypos_max - h / win -> h_u) &&
	    ( win -> ypos_max > h / win -> h_u )) {
		win -> ypos ++;
		move_work(win,0,win->h_u);
	}
}

void std_vsld( WINDOW *win) {
	long pos;
	INT16 h, dum;
	int dy;

	WindGet( win, WF_WORKXYWH, &dum, &dum, &dum, &h);
	pos = (long)(win->ypos_max - h/win->h_u)*(long)evnt.buff[4]/1000L;
	if (pos < 0) pos = 0;
	dy = (int)((pos - win->ypos) * win->h_u);
	win->ypos =  (int) pos;
	if( dy) move_work( win, 0, dy);
}

void std_hsld( WINDOW *win) {
	INT16 w, dum;
	long pos;
	int dx;

	WindGet( win, WF_WORKXYWH, &dum, &dum, &w, &dum);
	pos = (long)(win->xpos_max - w/win->w_u)*(long)evnt.buff[4]/1000L;	
	if (pos < 0) pos = 0;
	dx = (int)((pos - win->xpos) * win->w_u );
	win->xpos =  (int) pos;
	if (dx) move_work(win,dx,0);
}

void std_lflnd( WINDOW *win) {
	if ( win -> xpos > 0) {
		win -> xpos --;
		move_work(win,-win->w_u,0);
	}
}

void std_rtlnd( WINDOW *win) {
	INT16 dum, w;

	WindGet( win, WF_WORKXYWH, &dum, &dum, &w, &dum);
	if( ( win -> xpos < win -> xpos_max - w / win -> w_u) &&
	    ( win -> xpos_max > w / win -> w_u )) {
		win -> xpos ++;
		move_work(win,win->w_u,0);
	}
}

void std_lfpgd( WINDOW *win) {
	long pos;
	INT16 dum, w;
	int dx;

	if ( win -> xpos > 0L) {
		WindGet( win, WF_WORKXYWH, &dum, &dum, &w, &dum);
		pos = MAX( 0L, win->xpos - w / win->w_u);
		dx = (int)((pos - win->xpos) * win->w_u);
		win->xpos = pos;
		move_work(win,dx,0);
	}
}

void std_rtpgd( WINDOW *win) {
	int page;
	INT16 x,y,w,h;
	long old_pos = win -> xpos;
	int dx;
	
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	page = w / win -> w_u;
	if ( win -> xpos < win -> xpos_max - page) {
		win -> xpos = MIN( win -> xpos_max, win -> xpos) + page;
		win -> xpos = MIN( win -> xpos, win -> xpos_max - page);
		dx = (int)((win->xpos - old_pos) * win->w_u);
		move_work(win,dx,0);
	}
}

void std_arw( WINDOW *win) {
	switch( evnt.buff[4]) {
	case WA_UPPAGE:
		std_uppgd( win);
		break;
	case WA_DNPAGE:
		std_dnpgd( win);
		break;
	case WA_RTPAGE:
		std_rtpgd( win);
		break;
	case WA_LFPAGE:
		std_lfpgd( win);
		break;
	case WA_UPLINE:
		std_uplnd( win);
		break;
	case WA_DNLINE:
		std_dnlnd( win);
		break;
	case WA_RTLINE:
		std_rtlnd( win);
		break;
	case WA_LFLINE:
		std_lflnd( win);
		break;
	}
}

void std_btm( WINDOW *win) {
	WindSet( win, WF_BOTTOM, 0, 0, 0, 0);
}

