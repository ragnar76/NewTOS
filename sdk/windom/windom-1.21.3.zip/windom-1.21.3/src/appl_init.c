/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/appl_init.c,v $
 *
 * CVS info:
 *   $Author: bereziat $
 *   $Date: 2003/07/17 15:21:20 $
 *   $Revision: 1.4 $
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "globals.h"
#include "cookie.h"
#include "fsel.h"
#include "wsystem.h"

int ApplReInit( short * global) {
	INT16 dum;
	
	/* A v�rifier */
	app.id = global[2];
	_AESglobal = global;

	app.aeshdl = graf_handle( &dum, &dum, &dum, &dum);
	vq_extnd( app.aeshdl, 0, app.work_out);
	app.color  = app.work_out[ 13];
	vq_extnd( app.aeshdl, 1, app.work_out);
	app.nplanes = app.work_out[ 4];
	/* No color palette with true color modes */
	if( app.nplanes > 8) {
		ApplSet( APS_FLAG, FLG_NOPAL, 1);
		app.palette = NULL;
	} else {
		app.palette = (W_COLOR *) malloc( app.color * sizeof( W_COLOR));
		w_getpal( app.palette);
	}
	wind_get( 0, WF_WORKXYWH, &app.x, &app.y, &app.w, &app.h);
	graf_mouse( ARROW, 0L);
	app.work_in[0] = Getrez() + 2;
/*	for( dum = 1; dum < 10; app.work_in[ dum ++] = 1);
	app.work_in[10] = 2; */
	app.handle = app.aeshdl;
	v_opnvwk( app.work_in, &app.handle, app.work_out);
	_res = ( app.y+app.h-1 >=240)?1:0;
	CONF(app)->hicon = _res?72:36;
	
	for( dum = 1; dum<MAX_WINDOW; __windowlist[dum++]=0);
	__windowlist[0]=-1;
	for( dum = 0; dum<MAX_ICON; __iconlist[dum++]=0);
	app.aes4 = 0;

	/* Interrogation extensions syst�mes 
	 * la fonction appl_getinfo() retourne 1 
	 * quand l'information est disponible, 0 sinon */

	if( has_appl_getinfo() ) {
		INT16 parm1, parm3, parm4;

		if( appl_getinfo( AES_MESSAGE, &parm1, &dum, &parm3, &dum) == 1) {
			if( parm1 & 0x0002 )
				app.aes4 |= AES4_UNTOPPED;
			if( parm1 & 0x0040 )
				app.aes4 |= AES4_BOTTOM;
			if( (parm1 & 0x0080) && (parm1 & 0x0100) && (parm1 & 0x0200)) {
				app.aes4 |= AES4_ICONIFY;
				app.aes4 |= AES4_TOOLBAR;
			}
			if( parm3 & 0x0001 )	/* support des coordonn�es */
				app.aes4 |= AES4_ICONIFYXYWH;
		}
		
		if( appl_getinfo( AES_WINDOW, &parm1, &dum, &parm3, &dum) == 1) {
			if( parm3 & 0x0001 )
				app.aes4 |= AES4_SMALLER;
			if( parm3 & 0x0002 )
				app.aes4 |= AES4_BOTTOMER;
			if( parm1 & 0x0020)
				app.aes4 |= AES4_BEVENT;
		}
		if( appl_getinfo( AES_PROCESS, &dum, &dum, &parm3, &dum) == 1) {
			if( parm3 == 1) app.aes4 |= AES4_APPSEARCH;
		}
		/* Les fonctions fslx_() sont-elles dispos ? */
		if( appl_getinfo( 7 /* AES_EXTENSION */, &parm1, &dum, &dum, &dum) == 1) {
			if( parm1 & 0x0008) app.aes4 |= AES4_FSLX;
		}
		/* Mode extendues de graf_mouse dispo ? */
		if( appl_getinfo( AES_MOUSE, &parm1, &dum, &dum, &dum) == 1) {
			if( parm1 == 1) app.aes4 |= AES4_XGMOUSE;
		}
		/* Menu extensions */
		if( appl_getinfo( AES_MENU, &dum, &dum, &dum, &parm4) == 1) {
			if( parm4 == 1) app.aes4 |= AES4_MNSELECTED;
		}
		if( vq_xaaes() >= 0x0963)
			app.aes4 |= AES4_MENUBAR;
	} else {
		BXKT_STR *value;

		if( _AESversion >= 0x0340) { /* AES Falcon */
			app.aes4 |= AES4_UNTOPPED;
			app.aes4 |= AES4_BEVENT;
		}

		/* Les fonctions fslx_() sont dispos avec BoxKite 2 */
		if( get_cookie( HBFS_COOKIE, (long*)&value) && value->magic == HBFS_MAGIC && value->version >= 0x200 )
			app.aes4 |= AES4_FSLX;
	}
	if( vq_naes() > 0 || vq_magx() >= 0x0310) 
		app.aes4 |= AES4_APPLCONTROL;
	app.gdos = vq_gdos() ? vst_load_fonts( app.handle, 0)+app.work_out[10] : 0;
	app.avid = -1;
	app.ntree = -1;
	app.hilight = NULL;
	app.menu = NULL;
	app.mnbind = NULL;
#ifdef WINDOMDEBUG
	{
		FILE *fp;
		fp = fopen( LOGFILE, "w");
		if( fp) fclose( fp);
	}
#endif
	init_scroll_menu();
	ConfRead();

	/* Default binding */
	EvntAttach( NULL, AP_LOADCONF, ConfRead);
	EvntAttach( NULL, FNT_CHANGED, std_fntchg);

	app.pipe = Galloc( PIPE_SIZE);
	return app.id;
}

int ApplInit( void) {
	if ( appl_init() == -1)
		return -1;
	_AESglobal = aes_global;
	return ApplReInit( _AESglobal);
}

int ApplInit_( short *global) {
	if ( appl_init() == -1)
		return -1;
	return ApplReInit( global);
}
