/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/bubble_evnt.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:32:10 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

int BubbleEvnt( void) {
	WINDOW *win;
	int res;
	char *help;
	W_FORM *form;
	
	win = WindHandle( wind_find(evnt.mx,evnt.my));
	if( win && win->status & WS_FORM) {
		form = DataSearch(win,WD_WFRM);
		res = objc_find( form->root, 0, 8, evnt.mx, evnt.my);
		if( res != -1 && BubbleFind( form->real, res, &help)) {
			BubbleCall( help, evnt.mx, evnt.my);
			return WS_FORM;
		}
	}
	if( win && win->status & WS_TOOLBAR) {
		res = objc_find( TOOL(win), 0, 8, evnt.mx, evnt.my);
		if( res != -1 && BubbleFind( win->tool.real, res, &help)) {
			BubbleCall( help, evnt.mx, evnt.my);
			return WS_TOOLBAR;
		}
	}
	return 0;
}
