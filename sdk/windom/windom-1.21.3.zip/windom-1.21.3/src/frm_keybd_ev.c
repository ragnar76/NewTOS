/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frm_keybd_ev.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:18:47 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "globals.h"
#include "userdef.h"

/*
 *	Ev�n�ment clavier dans les formulaire
 */

int frm_keybd_ev( OBJECT *tree) {
	int dum=0;
	char *p, rac[2];

	if( !(evnt.mkstate & K_ALT))
		return -1;
	GemCode2Ascii( evnt.keybd, evnt.mkstate, rac);

	/* Chercher la commande */
	while(1) {

		if( ((tree[dum].ob_type>>8) == DCRBUTTON || 
			 (tree[dum].ob_type>>8) == ONGLET ||
			 (tree[dum].ob_type>>8) == KPOPUPSTRG )
			 && !(tree[dum].ob_flags & HIDETREE))
		{
			if( (tree[dum].ob_type & 0x00FF) == G_USERDEF)
				p = (char *)((W_PARM*)tree[dum].ob_spec.userblk->ub_parm)->wp_spec;
			else
				p = tree[dum].ob_spec.free_string;
				
			p = strchr( p, '[');
			if( p && toupper( *(p+1)) == rac[0])
				return dum;
		}
		
		dum = get_next_obj( tree, dum);
		if (dum == -1)
			return -1;
	} /* while( !(tree[dum++].ob_flags & LASTOB)); */
}
