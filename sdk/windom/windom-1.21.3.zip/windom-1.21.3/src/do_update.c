/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/do_update.c,v $
 *
 * CVS info:
 *   $Author: bereziat $
 *   $Date: 2003/07/18 09:29:49 $
 *   $Revision: 1.3 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 *	Mise � jour des fenetres ( fonction interne)
 */

void _do_update( WINDOW *win) {
	GRECT rdraw, /* zone to redraw */
		rlist, 	 /* current rectangle in AES list */
		rwork;	 /* work aera of window */
	int dy=0;
	INT16 x, y, w, h;

	while( !wind_update(BEG_UPDATE));
	graf_mouse( M_OFF, 0L);

	/* Dominic Test : execute only one function when one
	 * receives a WM_REDRAW message */
	EvntExec( win, WM_PREREDRAW);

	rc_set( &rdraw, evnt.buff[4], evnt.buff[5], evnt.buff[6], evnt.buff[7]);
	wind_get( win->handle, WF_FIRSTXYWH, &rlist.g_x, &rlist.g_y, &rlist.g_w, &rlist.g_h);
	wind_get( win->handle, WF_WORKXYWH, &x, &y, &w, &h);
	WindGet( win, WF_WORKXYWH, &rwork.g_x, &rwork.g_y, &rwork.g_w, &rwork.g_h);
	while (rlist.g_w && rlist.g_h) {
		if ( rc_intersect( &rdraw, &rlist)) {
			rc_clip_on( win->graf.handle, &rlist);
			if( win -> status & WS_MENU
			   && !( SYSMENU(app) && win->attrib & MENUBAR)
				 && !(win->status & WS_ICONIFY)) {
				menu_draw( win, rlist.g_x, rlist.g_y, rlist.g_w, rlist.g_h);
				dy = win->menu.root[1].ob_height+1;
			}
			if( win -> status & WS_TOOLBAR && !(win->status & WS_ICONIFY)) {				
				win->tool.root->ob_x = x;
				win->tool.root->ob_y = y + dy;
				objc_draw( win->tool.root, 0, MAX_DEPTH, rlist.g_x, rlist.g_y, rlist.g_w, rlist.g_h);
			}
			if( win->status & WS_ICONIFY && win->icon.draw != NULL)
				(*win->icon.draw)( win);
			else if( rc_intersect( &rwork, &rlist)) {
				rc_clip_on( win->graf.handle, &rlist);
				EvntExec( win, WM_REDRAW);
			}
			rc_clip_off( win->graf.handle);
		}
		wind_get( evnt.buff[3], WF_NEXTXYWH, &rlist.g_x, &rlist.g_y, &rlist.g_w, &rlist.g_h);
	}
	graf_mouse( M_ON, 0L);
	wind_update(END_UPDATE);
}

