/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/vqt_xname2.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:45:20 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include <stdio.h>
#include "globals.h"

/*
 * Emule vqt_xname()
 */

int VqtXname( int vh, int id, int index, char *name, int *fl) {
	if( vq_gdos())
		return vqt_xname( vh, id, index, name, fl);
	else {
		/* recherche par id */
		if( index == 0) {
			while( listfontid[index].id != id && index < maxfontid)
				index ++;
		}
		if( index < maxfontid) {
			strcpy( name, listfontid[index].name);
			*fl = listfontid[index].flags;
			return index?listfontid[index].id:index;
		} else
			return -1;
	}
}


