/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_xedit.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/02 20:44:51 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "globals.h"

/* ***************************************************************************
 * Sous-routines d'�dition des champs �ditables XEDIT
 */

/* Calcul de la reallocation (voir OPTIONS.H/REALLOC_XEDIT) 
 * calcul si on doit ou non r�allouer l'espace m�moire 
 * old : taille actuelle
 * len : longueur de la ligne demand�e
 */

size_t realloc_xedit( size_t old, size_t len) {
	size_t new;
	new = (len/XEDIT_REALLOC + 1)*XEDIT_REALLOC;
	if( new > old)	{
	/*	FormAlert( 1, "[1][Reallocation requise|%d %d][OK]",new, old); */
		return new;
	} else
		return 0;
}


/* d�calage vers la droite du buffer */

static
void shift_right( char *buf) {
	int l = (int)strlen(buf);
	
	buf += l;
	*(buf+1) = '\0';
	while( l) {
		*buf = *(buf-1);
		buf --;
		l --;
	}
}

/* d�calage vers la gauche du buffer */

void shift_left( char *buf) {
	do
		*buf = *(buf+1);
	while (*buf++);
}

/* Insertion d'un caract�re,
 * on utilise le champ tedinfo -> pvalid pour cela */

void xedit_add_char( W_XEDIT *xedit, char val) {
	char *p = xedit->line;
	char *pvalid = xedit->tedinfo->te_pvalid;
	int add = FALSE;
	
	switch( *pvalid) {
	case 'X':
	case 'H':		/* Hidden */
		add = TRUE;
		break;
	case 'x':
		val = toupper( val);
		add = TRUE;
		break;
	case '9':
		switch( val) {
		case '-':
		case '+':
			if( (xedit->curs && p[xedit->curs-1] == 'e')
				|| xedit->curs == 0) {
				if( p[xedit->curs] != '+' && p[xedit->curs] != '-')
					add = TRUE;
			}
			break;
		case '.':
		case 'e':
			if( strchr(p, val) == 0)
				add = TRUE;
			break;
		default:
			if( isdigit(val))
				add = TRUE;
		}
		break;

	case 'N': /* 0-9, A-Z and space */
		if( isdigit(val) || isupper(val) || val == ' ')
			add = TRUE;
		break;
	case 'n': /* 0-9, a-z and space */
		if( isdigit(val) || islower(val) || val == ' ')
			add = TRUE;		
		break;
 	case 'A': /* A-Z and space */
		if( isupper(val) || val == ' ')
			add = TRUE;
 		break;
	case 'a': /* a-z and space */
		if( islower(val) || val == ' ')
			add = TRUE;
		break;
	case 'F': /* Valid GEMDOS filename ? * */
		 if( isalnum(val) || strchr( ":-_*?", val))
		 	add = TRUE;
		 break;
	case 'P': /* Valid GEMDOS pathname ? * \ */
		 if( isalnum(val) || strchr( ":-_*?\\", val)) 
		 	add = TRUE;
		 break;
	case 'p': /* Valid GEMDOS pathame , \ */
		 if( isalnum(val) ||  strchr( ":-_\\", val)) 
		 	add = TRUE;
		 break;
	}

	if( add) {
		size_t size = realloc_xedit( xedit->size, strlen(p) + 2);
	
		if( size) p = xedit->line = realloc( xedit->line, size);
				
		/* Insertion du caract�re */
		shift_right( p + xedit->curs);
		p[xedit->curs] = val;
		xedit->curs ++;
	}
}

/*
 * Calcul la position horizontale relative d'une position
 * de curseur (en relatif par rapport � l'objet).
 *   LABEL : Le texte|____
 *   ^---------------^ = retour
 * curs est la position absolue du curseur (tient compte du
 * parametre xedit->pos).
 */

int width_curs( W_XEDIT *xedit, int curs) {
	INT16 tab[10], dum, width;
	char c;

	/* Largeur du label */
	if( vq_gdos() && CONF(app)->xedit_label.font >= 0) 
		vst_font( app.handle, CONF(app)->xedit_label.font);
	if( CONF(app)->xedit_text.size > 0)
		vst_point( app.handle, CONF(app)->xedit_label.size, &dum, &dum, &dum, &dum);
	if( vq_vgdos() == _FSM) 
		vqt_f_extent( app.handle, xedit->tedinfo->te_ptmplt, tab);
	else
		vqt_extent( app.handle, xedit->tedinfo->te_ptmplt, tab);
	width = tab[2]-tab[0];

	/* largeur du champ editable */
	if( vq_gdos() && CONF(app)->xedit_text.font >= 0) 
		vst_font( app.handle, CONF(app)->xedit_text.font);
	if( CONF(app)->xedit_text.size > 0)
		vst_point( app.handle, CONF(app)->xedit_text.size, &dum, &dum, &dum, &dum);

	if( xedit->tedinfo->te_pvalid[0] == 'H') {
		if( vq_vgdos() == _FSM) 
			vqt_f_extent( app.handle, "*", tab);
		else
			vqt_extent( app.handle, "*", tab);
		width += (tab[2]-tab[0])*(curs-xedit->pos);
	} else {
		c = xedit->line[curs];
		xedit->line[curs] = '\0';
		if( vq_vgdos() == _FSM) 
			vqt_f_extent( app.handle, xedit->line+xedit->pos, tab);
		else
			vqt_extent( app.handle, xedit->line+xedit->pos, tab);
		width += tab[2]-tab[0];
		xedit->line[curs] = c;
	}
	return width;
}

/*
 * Retourne la taille d'une cellule de caract�re dans le champ �ditable.
 */

void cell_curs( INT16 *wcell, INT16 *hcell) {
	INT16 dum;
	if( vq_gdos() && CONF(app)->xedit_text.font >= 0) 
		vst_font( app.handle, CONF(app)->xedit_text.font);
	if( CONF(app)->xedit_text.size > 0)
		vst_point( app.handle, CONF(app)->xedit_text.size, &dum, &dum, wcell, hcell);
	else
		vst_point( app.handle, 10, &dum, &dum, wcell, hcell);
	/* ya un truc qui va pas la, taille par d�faut si nulle ? */
}

/*
 * Dessine le curseur
 */

void xedit_curs( OBJECT *tree, int idx) {
	W_XEDIT *xedit = (W_XEDIT*)tree[idx].ob_spec.userblk->ub_parm;
	INT16 bar[4], wcell, hcell;
	
	objc_offset( tree, idx, &bar[0], &bar[1]);
	cell_curs( &wcell, &hcell);
	bar[0] += width_curs( xedit, xedit->curs);
	
	vswr_mode( app.handle, MD_REPLACE);
	vsf_color( app.handle, CONF(app)->xedit_curs_color);
	bar[2] = bar[0] + 1;
	bar[3] = bar[1] + hcell;
	v_bar( app.handle, bar);
}

/* 
 * Affiche le bloc
 */

void xedit_bloc( OBJECT *tree, int idx) {
	W_XEDIT *xedit = (W_XEDIT*)tree[idx].ob_spec.userblk->ub_parm;
	INT16 bar[4], wcell, hcell;
	
	if( xedit->blcbeg != xedit->blcend) {
		objc_offset( tree, idx, &bar[0], &bar[1]);
		cell_curs( &wcell, &hcell);
		bar[2] = bar[0] + width_curs( xedit, xedit->blcend) + 1;
		bar[0] += width_curs( xedit, xedit->blcbeg);
		bar[3] = bar[1] + hcell;

		vswr_mode( app.handle, MD_XOR);
		vsf_color( app.handle, BLACK);
		v_bar( app.handle, bar);
	}
}

/* appel a xedit_bloc dans une fenetre  */

void win_xedit_bloc( WINDOW *win, W_FORM *wform, int idx) {
	GRECT r1, r2, screen;
	OBJECT *tree = wform -> root;

	graf_mouse( M_OFF, 0L);
	objc_offset( tree, idx, &r1.g_x, &r1.g_y);
	r1.g_w = tree[idx].ob_width;
	r1.g_h = tree[idx].ob_height;	
	wind_get_grect( 0, WF_CURRXYWH, &screen);
	WindGet( win, WF_FIRSTXYWH, &r2.g_x, &r2.g_y, &r2.g_w, &r2.g_h);
	while( r2.g_w && r2.g_h) {
		if( rc_intersect( &r1, &r2) && rc_intersect( &screen, &r2)) {
			rc_clip_on( app.handle, &r2);
			xedit_bloc( tree, idx);
			rc_clip_off( app.handle);
		}
		WindGet( win, WF_NEXTXYWH, &r2.g_x, &r2.g_y, &r2.g_w, &r2.g_h);
	}
	graf_mouse( M_ON, 0L);
}

/* Fonction utile pour la s�lection � la souris
 * mx est l'abcisse du pointeur de la souris */

int xedit_mouse2curs( OBJECT *tree, int idx, int mx) {
	W_XEDIT *xedit = (W_XEDIT*)tree[idx].ob_spec.userblk->ub_parm;
	INT16 x, y;
	int curs;
	
	objc_offset( tree, idx, &x, &y);
	mx -= x;
	curs = (int)strlen(xedit->line);
	if(  width_curs( xedit, curs) < mx) return curs;
	curs = xedit->pos;	
	while( xedit->line[curs] && width_curs( xedit, curs++) < mx);
	return curs - 1 ;
}

void win_xedit_bloc_erase( WINDOW *win, W_FORM *wform, int idx) {
	OBJECT  *tree  = wform -> root;
	W_XEDIT *xedit = (W_XEDIT*)tree[idx].ob_spec.userblk->ub_parm;

	win_xedit_bloc( win, wform, idx);
	xedit->curs = xedit->blcbeg;
	xedit->flags &= ~XEDIT_BLOC_ON;
	xedit->flags |= XEDIT_CURS_ON;
	while( xedit->blcend >= xedit->blcbeg)
		shift_left( xedit->line + xedit->blcend --);
}
