/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/vq_extfs.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:45:20 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "cookie.h"

/*
 * teste si une partition (un chemin) supporte les noms longs
 */

int vq_extfs( char *path) {
	int vq_magx(void);
	long n, vers;
	
	if( vq_magx() >= 0x500 ||
		(get_cookie( MiNT_COOKIE,(LONG *)&vers) && vers>=0x90L)) {
		if( path[1] != ':') {
			/* Prendre le chemin courant */
			char newpath[255];
			
			newpath[0] = Dgetdrv() + 'A';
			newpath[1] = ':';
			Dgetpath( newpath+2, 0);
			strcat( newpath, "\\");
			strcat( newpath, path);
			n = Dpathconf( newpath, 3 /*DP_NAMEMAX*/);
		} else
			n = Dpathconf( path, 3 /*DP_NAMEMAX*/);
		if( n>=31) return 1;
	}
	return 0;
}
