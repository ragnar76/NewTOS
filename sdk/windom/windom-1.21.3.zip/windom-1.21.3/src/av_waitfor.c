/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/av_waitfor.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:06:33 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include <string.h>
#include "globals.h"

/* sous fonction: attente d'un message
 * avec time_idle (a faire) */
 
int AvWaitfor( int msg, INT16 *buf, long idle) {
	int res;
	INT16 dum;
	long count = 0;
	
	while(1) {
		res = evnt_multi( MU_TIMER|MU_MESAG,
					0,0,0,
					0,0,0,0,0,
					0,0,0,0,0,
					buf,
					100L,
					&dum,&dum,&dum,
					&dum,&dum,&dum);
		if( res & MU_MESAG) {
			if( buf[0] != msg) {
				appl_write( app.id, 16, buf);
				count += 100;
				evnt_timer(100);
				if( count > idle)
					return 0;
			} else return 1;
		}
		if( res & MU_TIMER) {
			count += 100;
			if( count > idle)
				return 0;
		}
	} 
}

