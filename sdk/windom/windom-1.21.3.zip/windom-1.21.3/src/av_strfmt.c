/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/av_strfmt.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:32:17 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include <string.h>
#include "globals.h"

/* Formatte un nom de fichier au format AV:
 * src: cha�ne � formatter,
 * retour: cha�ne formatt� (au format chaine d'environnement),
 *		   -> a lib�rer avec free()
 * mode: 1:
 *		on enl�ve les quotes s'ils existe
 * 		 0:
 *		on ajoute des quotes si besoin est
 *	(fonctionne aussi avec le D&D de chez Thing et MagXdesk)
 */

char *AvStrfmt( int mode, char *src) {
	char *dst, *r;
	
	r = dst = (char*)malloc(sizeof(char)*strlen(src)+3);
	if( mode) {
		char *p, *q;

		p = src;
		do {
			q = NULL;
			while( *p == ' ') p++;
			if( *p == '\'')
				q = strchr( ++p, '\'');
			else  
				q = strchr( p, ' ');
			if( q) *q++ = '\0';
			strcpy( dst, p);
			dst += strlen( dst)+1;
			p = q;
		} while (q);
		*dst = '\0';
	} else if( strchr( src, ' ')) {
		*dst = '\'';
		strcpy( dst+1, src);
		strcat( dst, "\'");
	}
	return r;
}
