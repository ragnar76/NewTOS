/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_close.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "av.h"

int WindClose( WINDOW *win) {
	INT16 x,y,w,h;
	int res=0;

/*
	if( !(win->status & WS_OPEN))
		return -1;	*/ /* warning : window already closed */
			
	if( win -> status & WS_FRAME) {
		win -> status &= ~WS_OPEN;
		return 0;
	}
	
	wind_get( win->handle, WF_CURRXYWH, &x, &y, &w, &h);
	if( win -> status & WS_OPEN) {
		res = wind_close( win -> handle);
		/* special effects always optional */
		if( win -> status & WS_GROW && CONF(app)->weffect == TRUE)
			graf_shrinkbox( 0, 0, 0, 0, x, y, w, h);
	}
	win -> status &= ~WS_OPEN;

	wind_get( 0, WF_TOP, &x, &y, &w, &h);
	wglb.front = WindHandle( x);

	
	/* la liste d'ordonnance nous permet de choisir trouver la
	   fen�tre sous celle ci */

	for( w=0; __windowlist[w] != win->handle; w = __windowlist[w]);

/* BUG ? FIXME !
 * the WindHandle() parameter type is an AES window handle (win->handle)
 * but w seems to be an index for the __windowlist[] array...
 * maybe " wglb.appfront = WindHandle( __windowlist[w]); " is better ?...
 */

	wglb.appfront = WindHandle( w);

	remove_windowlist( win->handle);
	if( app.avid != -1) ApplWrite( app.avid, AV_ACCWINDCLOSED, win->handle,0,0,0,0);

	return res;
}
