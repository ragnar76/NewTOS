/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_slider.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"


/*********************************************************/
/* Manage the sliders           		 				 */
/*********************************************************/

/*
 *  Set the AES slider position and size computed from
 *  some internal variables (win->h_u, win->ypos_max...).
 *	
 */

void WindSlider( WINDOW *win, int mode) {
	INT16 x,y,w,h;
	unsigned long size, pos;
	
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	if( mode & VSLIDER) {
		if ( win->ypos_max < (long)h/win->h_u)
			size = 1000L;
		else
			size = MAX( 50L, (unsigned long)h*1000L/(unsigned long)(win->h_u*win->ypos_max));
		WindSet( win, WF_VSLSIZE,(int)size , 0, 0, 0);

		if( win->ypos_max > (long)h/win->h_u) {
			pos = (unsigned long)win->ypos *1000L/(unsigned long)(win->ypos_max-h/win->h_u);
			WindSet( win, WF_VSLIDE, (int)pos, 0, 0, 0);
		} else if (win->ypos) {
			win->ypos = 0;
			WindSet( win, WF_VSLIDE, 0, 0, 0, 0); 
		}
	}
	if( mode & HSLIDER) {
		if ( win->xpos_max < (long)w/win->w_u)
			size = 1000L;
		else
			size = MAX( 50L, (unsigned long)w*1000L/(unsigned long)( win->w_u*win->xpos_max));
		WindSet( win, WF_HSLSIZE, (int)size, 0, 0, 0);

		if( win->xpos_max > (long)w/win->w_u) {
			pos = (unsigned long)win->xpos*1000L/(unsigned long)(win->xpos_max-w/win->w_u);
			WindSet( win, WF_HSLIDE, (int)pos, 0, 0, 0);
		} else if (win->xpos) {
			win->xpos = 0;
			WindSet( win, WF_HSLIDE, 0, 0, 0, 0);
		}
	}
}
