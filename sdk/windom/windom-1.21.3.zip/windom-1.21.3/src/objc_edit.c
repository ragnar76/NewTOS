/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/objc_edit.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:04:05 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "userdef.h"
#include "scancode.h"

/*
 *  Pour acc�der aux �ditables et types �tendus de facon transparent
 *	Nouveau prototype pour la rendre publique (proto similaire a objc_edit)
 */

int ObjcEdit( int mode, WINDOW *win, int obj, int val, INT16 *idx, int kind) {
	OBJECT *tree;
	W_FORM *wform;
	INT16 xc, yc;
	int res = E_OK;

	if( obj < 0) return ERANGE;  /* Error, bad value for obj */

	switch( mode) {
	case OC_FORM:
		wform = DataSearch( win, WD_WFRM);
		tree = wform->root;
		break;
	case OC_TOOLBAR:
		wform = &win->tool;
		tree = TOOL((WINDOW*)win);
		break;
	case OC_OBJC:
		tree = (OBJECT *)win;
		wform = NULL;
		break;
	default:
		return EBADRQ;	/* Error, bad value for mode */
	}

	objc_offset( tree, obj, &xc, &yc);
		
	/*
	 * Cas d'un objet XEDIT : WinDom gere le curseur.
	 */

#ifdef MODIF_XEDIT

	if( (tree[obj].ob_type & 0x00FF) == G_USERDEF 
		&& (tree[obj].ob_type>>8) == XEDIT) {
		W_XEDIT *xedit = (W_XEDIT *)tree[obj].ob_spec.userblk->ub_parm;
		char *p = xedit->line;
		INT16 wcell, hcell;
		INT16 mod, dum;
		
		#define RDRW_OFF 0
		#define RDRW_ALL 1
		#define RDRW_CUR 2
		#define RDRW_RT	 3

		int redraw = RDRW_OFF;

		switch( kind) {
		case ED_CURS:
			/* test */
			xedit -> curs = *idx;
			break;
		case ED_BLC_OFF:
			if( xedit -> flags & XEDIT_BLOC_ON) {
				if( wform)
					win_xedit_bloc( win, wform, obj);
				else
					xedit_bloc( tree, obj);
				xedit -> flags &= ~XEDIT_BLOC_ON;
			}
			break;
		case ED_BLC_START:
			xedit -> blcbeg = val;
			break;
		case ED_BLC_END:
			xedit -> flags |= XEDIT_BLOC_ON;
			xedit -> blcend = val;
			if( wform)
				win_xedit_bloc( win, wform, obj);
			else
				xedit_bloc( tree, obj);
			break;

		case ED_INIT:	/* Allumer le curseur */
			xedit -> flags |= XEDIT_CURS_ON;
			val = xedit->pos;
			/* position du scroll */
			if( xedit->curs < xedit->pos)
				xedit->pos = xedit->curs;
			cell_curs( &wcell, &hcell);
			while( width_curs( xedit, xedit->curs) + wcell/2 > tree[obj].ob_width)
				xedit->pos ++;
			redraw = ( val != xedit->pos)?RDRW_ALL:RDRW_CUR;
			*idx = xedit -> curs;
			break;
		case ED_END:	/* Eteindre le curseur */
			xedit -> flags &= ~XEDIT_CURS_ON;
			redraw = RDRW_ALL;
			break;
		case ED_CHAR:	/* Ajouter un caract�re */
			if( (xedit->flags & XEDIT_CURS_ON) ||
				(xedit->flags & XEDIT_BLOC_ON) )
			switch( val) {
			
			case 0x4700:	/* HOME : curseur au d�but du texte */
				if( p[xedit->curs] != '\0') {
					xedit->curs = xedit->pos = 0;
					redraw = RDRW_ALL;
				}
				break;
			case 0x4737:	/* S-HOME : curseur � la fin du texte */
				if( p[xedit->curs] != '\0') {
					redraw = RDRW_ALL;
					xedit->pos = xedit->curs = (int) strlen(p);
					xedit->pos = MAX( 0, xedit->pos-2);
				}	
			case 0x4B00:	/* LFARW : curseur � gauche */
				if( xedit->curs > 0) {
					redraw = RDRW_CUR;
					xedit->curs --;
				}
				break;
			case 0x7300:	/* C-LFARTW : curseur un mot � gauche */
				if( xedit->curs > 0) {
					xedit->curs --;
					/* skip escape */
					while( xedit->curs && p[xedit->curs] == ' ')
						xedit->curs --;
					/* skip word */
					while( xedit->curs && p[xedit->curs] != ' ')
						xedit->curs --;
					if( xedit->curs) xedit->curs ++;
					redraw = RDRW_ALL;
				}
				break;
			case 0x4D00:	/* RTARW : curseur � droite */
				if( p[xedit->curs] != '\0') {
					redraw = RDRW_CUR;
					xedit->curs ++;
				}
				break;
			case 0x7400:	/* C-RTARW : curseur un mot � droite */
				if( p[xedit->curs] != '\0') {					
					/* skip word */
					while( p[xedit->curs] != '\0' && p[xedit->curs] != ' ')
						xedit->curs ++;
					/* skip escape */
					while( p[xedit->curs] != '\0' && p[xedit->curs] == ' ')
						xedit->curs ++;
					redraw = RDRW_ALL;
				/*	xedit->curs --; */
				}
				break;
			case 0x537F: 	/* DEL : effacement devant le curseur */
				if( p[xedit->curs] != '\0')
					xedit->curs ++;

			case 0x0E08:	/* BACK : effacement derriere le curseur */
				if( xedit->curs > 0) {
					redraw = RDRW_RT;
					shift_left( p + xedit->curs-1);
					xedit->curs --;
					if( xedit->curs < xedit->pos) {
						redraw = RDRW_ALL;
						xedit->pos = MIN(xedit->pos-2,0);
					} 
				}
				break;

			case 0x011B:	/* ESC : champ vid�, curseur au d�but */
				redraw = RDRW_ALL;
				p[0] = '\0';
				xedit->curs = 0;
				xedit->pos = 0;
				break;

			default:

				/* Analyse hors scancodes */
				graf_mkstate( &dum, &dum, &dum, &mod);
				if( mod & K_CTRL) {
					
					switch( keybd2ascii(val, mod & (K_LSHIFT+K_RSHIFT))) {
					case 'c':
						scrap_txt_write( p);
						break;
					case 'v':
						{
							char *s, *q = scrap_txt_read();

							if( q) {
								for( s=q; *s; s++)
									xedit_add_char( xedit, *s);
								free( q);
								redraw = RDRW_ALL;
							}
						}
						break;			
					case 'k':
						p[xedit->curs] = '\0';
						redraw = RDRW_RT;
						break;
					}
				} else {
					/* insertion caractere */
					if( val & 0x00FF) {
						redraw = p[xedit->curs]?RDRW_RT:RDRW_CUR;
						if( xedit->flags & XEDIT_BLOC_ON ) {
							win_xedit_bloc_erase( win, wform, obj);
							redraw = RDRW_RT;
						}
						xedit_add_char( xedit, val);
					}
				}
			} /* switch( val>>8) */
			
			val = xedit->pos;
			/* gestion du scroll */
			if( xedit->curs >= 0) {
				if( xedit->curs < xedit->pos)
					xedit->pos = xedit->curs;

				cell_curs( &wcell, &hcell);
				while( width_curs( xedit, xedit->curs) + wcell/2 > tree[obj].ob_width)
					xedit->pos ++;
			}
			if( redraw && val != xedit->pos)
				redraw = RDRW_ALL;

			*idx = xedit -> curs;
			break;
		} /* switch(kind) */

		/* redessin de l'objet */
		if( redraw != RDRW_OFF) {
			switch( redraw) {
			case RDRW_ALL:
				val = width_curs( xedit, xedit->pos);
				wcell = tree[obj].ob_width - val;
				break;
			case RDRW_CUR:
				val = width_curs( xedit, MAX(xedit->pos,xedit->curs-1));
				cell_curs( &wcell, &hcell);
				wcell *= 3;
				break;
			case RDRW_RT:
				val = width_curs( xedit, MAX(xedit->pos,xedit->curs-1));
				wcell = tree[obj].ob_width - val;
				break;
			}
			
			if( wform)
				ObjcWindDraw( win, tree, obj, 0, xc+val-1, yc, 
							  wcell, tree[obj].ob_height);
			else
				objc_draw( tree, obj, 0, xc+val-1, yc, 
						   wcell, tree[obj].ob_height);
		}
	} else 

#endif /* MODIF_XEDIT */

	/* Cas objet editable systeme en fenetre */ 

	if( wform) {
		INT16 curs = *idx;
		
		/* PROBLEME : Il n'est pas possible de modifier la zone de
		 *            masquage de objc_edit() */

		res = objc_edit( tree, obj, val, idx, kind);
		/* Je dois recaler le curseur */
		if( curs > 0 && kind == ED_INIT) {		
			while( *idx != curs)
				objc_edit( tree, obj, 
					((*idx > curs)?SC_LFARW:SC_RTARW)<<8, idx, ED_CHAR);
		}

	} else

		/* cas d'un dialogue classique */
	
		res = objc_edit( tree, obj, val, idx, kind);

	return res;
}

/* FIN MODIF OBJC_EDIT */
