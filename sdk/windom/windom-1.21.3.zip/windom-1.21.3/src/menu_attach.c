/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/menu_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:06 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "userdef.h"

int MenuAttach( int flag, OBJECT *tree, short item, MENU *mdata) {
	char *txt;
	
	if( tree[item].ob_type == G_STRING && flag == ME_ATTACH) {
		SMENU *sub;
		USERBLK *user;
		
		/* on attache, l'entr�e du menu est remplac� par
		   un objet userdef */
		tree[item].ob_type = G_USERDEF | (XSMENU<<8);

		sub = (SMENU *)malloc( sizeof(SMENU));
		txt = tree[item].ob_spec.free_string;
		txt[ strlen(txt)-2] = '';
		sub->string = txt;
		sub->mn_tree = mdata->mn_tree;
		sub->mn_menu = mdata->mn_menu;
		sub->mn_item = mdata->mn_item;
		sub->mn_scroll = 0 /*mdata->mn_scroll*/;

		user = (USERBLK *)malloc( sizeof(USERBLK));
		user->ub_code = draw_submenu;
		user->ub_parm =(long)sub;
		
		tree[item].ob_spec.userblk = user;
		
	} else if( tree[item].ob_type == (G_USERDEF|(XSMENU<<8)) && flag == ME_REMOVE) {		
		txt = ((SMENU *)tree[item].ob_spec.userblk->ub_parm)->string;
		tree[item].ob_type = G_STRING;
		free( (void*)tree[item].ob_spec.userblk->ub_parm);
		free( tree[item].ob_spec.userblk);
		txt[ strlen(txt)-2] = ' ';
		tree[item].ob_spec.free_string = txt;
	} else if( tree[item].ob_type == (G_USERDEF|(XSMENU<<8)) && flag == ME_INQUIRE) {
	
	}
	return 0;
}

