/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frame_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 19:24:15 $
 *   $Revision: 1.2 $
 */


#include <stdlib.h>
#include "globals.h"

void FrameAttach( WINDOW *win, WINDOW *src, int line, int col, int w, int h, int flags) {
	FRAME *frame = DataSearch( win, WD_WFRA);
	WINDOW *scan = frame->list, *prev;
	GRECT r;
	FRAMEINFO *finfo;

	finfo = (FRAMEINFO *)malloc( sizeof(FRAMEINFO));
	if( finfo == NULL) {
		app.error = ENSMEM;
		return;
	}
	DataAttach( src, WD_WFRI, finfo);
	
	/* set the sliders value */
	WindSlider( src, VSLIDER|HSLIDER);
	
	if( src -> status & WS_OPEN) 
		WindClose( src);
	wind_delete( src->handle);
	RemoveWindow( src);

	src -> next = NULL;
	src -> status |= WS_FRAME;
	src -> status |= WS_OPEN;

	finfo -> col = col;
	finfo -> line = line;
	finfo -> w = w;
	finfo -> h = h;
	finfo -> flags = flags;

	frame -> col  = MAX( frame->col, col);
	frame -> line = MAX( frame->line, line);
	frame -> front = src;

	/* we keep some global characteristics of the root window */
	src -> handle = win -> handle;
	src -> icon = win -> icon;

	/* Add to the (sorting) list */
	prev = NULL;

	if( scan == NULL) {
		frame->list = src;
	} else {
		while( scan) {
			finfo = GETFINFO(scan);
			if( finfo->line > line ||
				(finfo->line == line &&
				 finfo->col > col)) { /* inserer */
					src->next = scan;
					if( prev)
						prev -> next = src;
					else
						frame->list = src;
					break;
				}
			prev = scan;
			scan = scan->next;
		}
		if( scan == NULL)
			prev->next = src;
	}
	
	FrameCalc( src, 1, &r.g_x, &r.g_y, &r.g_w, &r.g_h);
	set_gadget_pos( src, &r, 0);
}
