/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/give_iconifyxywh.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:17 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
/*#include "av.h"*/
#include "globals.h"
#include "cookie.h"

/*
 *	Nouveaux messages AES 4 ( fonction interne)
 */

/*
 *	Fonction interne calculant les positions des fenetres
 *  pour les messages WF_ICONIFY ...
 */

static int __CDECL (*icfs)( int f, ...);

void give_iconifyxywh( INT16 *x, INT16 *y, INT16 *w, INT16 *h) {
	int pos=0, pmax;
	
	if( app.aes4 & AES4_ICONIFY) {
		*x = *y = *w = *h = -1;
	} else if( get_cookie( ICFS_COOKIE, (long*)&icfs)) {
		pos = (*icfs)( ICF_GETPOS, x, y, w, h);
		(*icfs)( ICF_FREEPOS, pos);
	} else {
		pmax = app.w/CONF(app)->wicon;
		for(; __iconlist[ pos]; pos ++);
		*x = app.x + (pos % pmax)*CONF(app)->wicon;
		*y = app.y + app.h -(pos / pmax + 1)*CONF(app)->hicon;
		*w = CONF(app)->wicon;
		*h = CONF(app)->hicon;
	}
}

