/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/conf_windom.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/27 18:54:15 $
 *   $Revision: 1.3 $
 */

#include <stdlib.h>
#include <string.h>
#include "globals.h"

/*
 *	Appel de WinConf 
 */

int ConfWindom( void) {
	char *p=NULL;
	char prgname[255], prgcmd[255];
	int locate = FALSE;


	/* Nom du programme */
	shel_read( prgname, prgcmd);

	/* Localisation de WinConf */
	if( shel_envrn( &p, "WINCONF="))
		locate = TRUE;
	else {
		strcpy( prgcmd, "winconf.app");
		locate = shel_find( prgcmd);
		p = prgcmd;
	}

	if( locate)
		return ShelWrite( p, prgname, NULL, TRUE, FALSE);
	else
		return -33;

	
/* Future Extension :

#define WC_SECTION	0x5743	

	ApplWrite( id, WC_SECTION, section);
	return id;
*/
	
}

