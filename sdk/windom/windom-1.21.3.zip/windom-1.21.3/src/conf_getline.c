/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/conf_getline.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:30:12 $
 *   $Revision: 1.1 $
 */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"

/*
 *	Lecture s�quentielle du fichier
 */

int ConfGetLine( char *string) {
	char *line = NULL;  /* modif Arnaud 02/2003 */
	static size_t pos = 0;
	int mode = -1;
	
	if( __confapp_buffer) {
		line = __confapp_buffer;
		mode = 1;
	} else if( __confdef_buffer) {
		line = __confdef_buffer;
		mode = 0;
	}

	/* reinit */
	if( line == NULL || string == NULL) {
		pos = 0;
		__confdef_line_pos = __confdef_line_top;
		__confapp_line_pos = __confapp_line_top;
		return 0;
	}
	line += pos;
	if( *line == '\0')
		return 0;	/* plus rien � lire */
	while( *line != '\n' && *line != '\0') {
		*string++=*line++;
		pos++;
	}
	*string='\0';
	if( *line == '\n')
		pos++;

	if( mode == -1) return 0;
	return (mode ? (__confapp_line_pos++) : (__confdef_line_pos++));
}


