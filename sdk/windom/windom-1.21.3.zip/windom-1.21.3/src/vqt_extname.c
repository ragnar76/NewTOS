/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/vqt_extname.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:45:20 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"
#include "cookie.h"

/*
 *	Fonction inspir�e de la doc d�veloppeur NVDI 4  qui
 *	int�gre les sp�cifit�s de Speedo (caract�re 33) et 
 *  celles de NVDI (caract�re 34).
 */

/* pre   name : buffer de 33 octets 
 * post  voir vqt_ext_name 
 */

int vqt_extname( int handle, int index, char *name, 
				 int *speedo, INT16 *format, INT16 *flags ) {
	int res;

	res = vqt_ext_name ( handle, index, name, format, flags);	
	*speedo = name[32];
	name[32] = '\0';
	
  	return( res);
}

