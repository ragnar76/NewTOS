/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/bubble_do.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:09:15 $
 *   $Revision: 1.2 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 *	Cette fonction remplace form_do() pour permettre
 *	la gestion des bulles d'aides.
 */

int BubbleDo( OBJECT *tree, int edit) {
	INT16 msg[8], mx, my, mbut;
	INT16 dum, keybd, click, obj;
	INT16 ev;
	INT16 pos = 0;
	char *help;

	if( edit != -1) objc_edit( tree, edit, 0, &ev, ED_INIT);
	
	while( 1) {
		ev = evnt_multi( MU_BUTTON|MU_KEYBD, 
					258, 3, 0, 
     				0, 0, 0, 0, 0,
     				0, 0, 0, 0, 0, 
     				msg, 
					0L,
          			&mx, &my, &mbut,  
   					&dum, &keybd, &click);
	
		if( ev & MU_BUTTON) {
			obj = objc_find( tree, 0, 7, mx, my);
			if( obj != -1 && mbut & 0x1) {
				if( !form_button( tree, obj, click, &dum))
					return obj;
				if( tree[obj].ob_flags & EDITABLE && obj != edit) {
					objc_edit( tree, edit, 0, &pos, ED_END);
					edit = obj;
					objc_edit( tree, edit, 0, &pos, ED_INIT);			
				}
			} else if( obj != -1 && mbut & 0x2) {
				if(	BubbleFind( tree, obj, &help))
					BubbleModal( help, mx, my);
			}
		}
		
		if( ev & MU_KEYBD) {
			INT16 key;
			
			if( !form_keybd( tree, (edit==-1)?0:edit, 1, keybd, &obj, &key))
				return obj;
			if( key) 
				objc_edit( tree, edit, key, &pos, ED_CHAR);
			else {
				objc_edit( tree, edit, 0, &pos, ED_END);
				edit = obj;
				objc_edit( tree, edit, 0, &pos, ED_INIT);
			}	
		}
	}
}

