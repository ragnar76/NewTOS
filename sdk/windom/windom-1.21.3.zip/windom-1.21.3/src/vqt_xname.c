/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/vqt_xname.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 19:45:20 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include <string.h>
#include "globals.h"

/*
 *	Appel custom des fonctions vqt_extname, vqt_xfntinfo,
 *	vqt_fontheader.
 *	name: nom de la fonte (pas forc�ment sur 31 octets)
 *	flags: FNT_OUTLINE, fonte vectorielle (ou bitmap sinon)
 *		   FNT_MONO,	fonte non proportionnelle (ou proportionnelle sinon)
 *		   FNT_SPEEDO,  fonte vectorielle de type speedo
 *		   FNT_TRUETYPE,fonte vectorielle de type true type
 *		   FNT_TYPE1,	fonte vectorielle de type postscript type 1
 *	index: index fonte
 *	retour: id de la fonte
 */

int vqt_xname( int handle, int id, int index, char *name, int *flags) {
	int speedo;
	INT16 nvdi_fmt, nvdi_flg;
	long vers;
	int get_cookie( long, long*);

	if( index == 0) {
		for( index = 0; index < app.gdos; index++) {
			if( id == vqt_name( handle, index, name))
				break;
		}
		if( index == app.gdos) return -1;	/* erreur, id non trouv�e */
	} 
	
	id = vqt_extname( handle, index, name, &speedo, &nvdi_fmt, &nvdi_flg);

	*flags = 0;
	/* fonte vectorielle ? */
	if( speedo == 1 /*SP_OUTLINE*/) 
		*flags |= FNT_OUTLINE;
	/* fonte monospaced ? */
	if( nvdi_flg == 1 /*NVDI_MONO*/)
		*flags |= FNT_MONO;
	if( nvdi_fmt & 0x2 /*NVDI_SPEEDO*/)
		*flags |= FNT_SPEEDO;
	if( nvdi_fmt & 0x4 /*NVDI_TRUETYPE*/)
		*flags |= FNT_TRUETYPE;
	if( nvdi_fmt & 0x8 /*NVDI_TYPE1*/)
		*flags |= FNT_TYPE1;

	if( vq_nvdi() >= 0x0302) {
		XFNT_INFO xfnt;

		/* Le nom long sous Nvdi */
		if( speedo == 0)	return id;
		vqt_xfntinfo( handle, 0x1 /*XFNT_NAME*/, id, 0, &xfnt);
		strcpy( name, xfnt.font_name);
	} else 
#define _FSM 0x5F46534DUL
#define FSMC 0x46534D43UL
#define _SPD 0x5F535044UL
	if( vq_vgdos() == _FSM	 	 &&	/* Il faut speedo */
		get_cookie( FSMC, &vers) && /*				  */
		*(long*)vers == _SPD 	 && /*				  */
		speedo == 1 /*SP_OUTLINE*/ ) {		/* et une fonte vectorielle */
		char buf [421];
		char path[128];
	
		vst_font( handle, id);
		*(buf+24) = '\0';
		vqt_fontheader( handle, buf, path);
		/* le nom long sous Speedo */
		strcpy( name, buf+24);
		/* fonte monospaced ? */
		if( *(buf+263) & 0x2)
			*flags |= FNT_MONO;
		*flags |= FNT_SPEEDO;
	} else {
		/* vqt_fontheader() ne fonctionne pas avec
		 * les fontes bitmap Gdos */
		INT16 cellw1, cellw2, dum;
		#define l_ASCII	0x6C
		#define W_ASCII	0x57

		vqt_width( handle, l_ASCII, &cellw1, &dum, &dum);
		vqt_width( handle, W_ASCII, &cellw2, &dum, &dum);
		if( cellw1 == cellw2) *flags |= FNT_MONO;
	}
	return id;
}
