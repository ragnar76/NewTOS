/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/conf_read.c,v $
 *
 * CVS info:
 *   $Author: bereziat $
 *   $Date: 2003/07/17 15:22:59 $
 *   $Revision: 1.2 $
 */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"

/* r�pertoire courant, r�pertoires HOME[/Defaults], r�pertoires PATH,
   r�pertoire C:\
   valeur de  retour: -33 pas de fichier
                      -1  aucune balise pour l'application
                       0  pas d'erreur
*/

/* Test windom.cnf puis .windomrc */


static
FILE *fconf( char *path, char *subpath) {
	FILE *fp;
	
	strcpy( __confpath, path);
	add_slash( __confpath);
	strcat( __confpath, subpath);
	add_slash( __confpath);
	strcat( __confpath, "windom.cnf");
	fp = fopen( __confpath, "r");
	if( fp == NULL && vq_extfs(path)) {
		strcpy( __confpath, path);
		add_slash( __confpath);
		strcat( __confpath, subpath);
		add_slash( __confpath);
		strcat( __confpath, ".windomrc");
		fp = fopen( __confpath, "r");
	}
	return fp;
}

static void read_attrib( char *name, ATTRIB *attrib) {
	char buf[80];
	
	strcpy( buf, name);
	strcat( buf, ".color");
	ConfInquire( buf, "%d", &attrib->color);
	strcpy( buf, name);
	strcat( buf, ".size");
	ConfInquire( buf, "%d", &attrib->size);
	strcpy( buf, name);
	strcat( buf, ".font");
	if( ConfInquire( buf, "%S", buf) >= 1) {
		attrib->font = FontName2Id( buf);
		if(attrib->font == -1) attrib->font = 0;
	}
}


/* Trouve une balise et la charge */
/* Fichier, balise, et position de la config dans le fichier */

static
char *find_and_read( FILE *fp, char *tag, int *top) {
	int find = FALSE;
	int tagtop, real;
	int bottom = -1;
	char *buffer, *p;
	char buf[LINE_SIZE+1];
	
	rewind( fp);

	*top = 0;
	while( !feof( fp)) {
		/* indicateur de position pour ConfInquire() */
		tagtop = (int) ftell( fp);			
		p = fgets( buf, LINE_SIZE, fp);
		(*top) ++;
		if( p == NULL) break;
		if( *buf == '#' || *buf=='\n')
			continue;
		while( *p == ' ' || *p == '\t')
			p ++;		
		if( p == strstr( p, tag) ) {
			find = TRUE;
			break;
		}
	}	

	/* Balise non trouv�e */
	if( find == FALSE) 
		return NULL;
	
	/* Recherche de la balise [end] */	
	fseek( fp, tagtop, 0);
	while( !feof( fp)) {
		p = fgets( buf, LINE_SIZE, fp);
		if( p == NULL) break;
		if(*buf == '#' || *buf=='\n')
			continue;
		while( *p == ' ' || *p == '\t')
			p ++;
		if( p == strstr( p, "[end]")) {
			bottom = (int)ftell( fp);
			break;
		}
	}

	if (bottom == -1) {       /* la balise [end] n'existe pas */
		bottom = (int) ftell( fp);  /* feof(fp)==TRUE => bottom = end of the file */
	}

	buffer = (char*)malloc( sizeof(char)*(bottom-tagtop+1));
	fseek( fp, tagtop, 0);
	real = (int) fread( buffer, sizeof(char), bottom-tagtop, fp);
	buffer[MIN(real, bottom-tagtop)] = '\0';

	return buffer;
}


int ConfRead( void) {
	FILE *fp = NULL;
	char path[FILE_SIZE], *p;
	char buf[LINE_SIZE];
	int  dum;
	char nameprg[20];
	CONFIG *conf = app.conf;
	
	/* Recherche du fichier 'windom.cnf' */
	
	/* r�pertoire courant */
	
	fp = fconf( ".", "");
	
	/* r�pertoire HOME[\Defaults] */

	shel_envrn( &p, "HOME=");
	if( fp == NULL && p ) {
		fp = fconf( p, "Defaults");
		if( fp == NULL ) 
			fp = fconf( p, "");
	}

	/* r�pertorie ETCDIR */
	shel_envrn( &p, "ETCDIR=");
	if( fp == NULL && p )
		fp = fconf( p, "");
	
	/* r�pertoire PATH */
	
	if( fp == NULL) {
		strcpy( __confpath, "windom.cnf");
		shel_find( __confpath);
		fp = fopen( __confpath, "r");
	}
	
	/* r�pertoire C:\ */
	
	if( fp == NULL &&  Dsetdrv( Dgetdrv()) & 0x4)	 /* C: */
		fp = fconf( "C:\\", "");

	if( __confapp_buffer != NULL) {
		free( __confapp_buffer);
		__confapp_buffer = NULL;
	}
	if( __confdef_buffer != NULL) {
		free( __confdef_buffer);
		__confdef_buffer = NULL;
	}
				
	if( fp == NULL)
		return -33;

	get_appname( nameprg);
	
	/* On cherche la balise de notre application 
	 * et celle de la config par defaut, on les charges 
	 */

	__confapp_buffer = find_and_read( fp, nameprg, &__confapp_line_top);
	__confapp_line_pos = __confapp_line_top;	
	__confdef_buffer = find_and_read( fp, "[Default Settings]", &__confdef_line_top);
	__confdef_line_pos = __confdef_line_top;
	fclose( fp);
	
	/* Aucune balise n'a �t� trouv� */
	if( !__confapp_buffer && !__confdef_buffer)
		return -1;

	/*
	 * ICI, Interrogation du fichier 
	 */
	
	/* Ev�nements */
	if( ConfInquire( "windom.evnt.keybd", "%s", buf)>=1)
		SET_BIT( conf->flag, FLG_KEYMOUSE, !stricmp(buf,"mouse"));
	if( ConfInquire( "windom.evnt.button", "%s", buf)>=1)
		SET_BIT( conf->flag, FLG_BUTMOUSE, !stricmp(buf,"mouse"));

	/* Types �tendus */
	read_attrib( "windom.string", 	&conf->string);
	read_attrib( "windom.button", 	&conf->button);
	read_attrib( "windom.exit", 	&conf->exit);
	read_attrib( "windom.xedit.text", 	&conf->xedit_text);
	read_attrib( "windom.xedit.label", 	&conf->xedit_label);
	ConfInquire( "windom.xedit.cursor.color", "%d", &conf->xedit_curs_color);
	read_attrib( "windom.xlongedit", 	&conf->xlongedit);
	ConfInquire( "windom.xlongedit.smallsize", "%d", &conf->xlgedt_smlfnt);
	read_attrib( "windom.xtedinfo",		&conf->xtedinfo);
	ConfInquire( "windom.xtedinfo.smallsize", "%d", &conf->xtdinf_smlfnt);
	read_attrib( "windom.menu", 	&conf->title);
	read_attrib( "windom.bubble",	&conf->bubble);
	ConfInquire( "windom.relief.mono" , "%d", &conf->actmono);
	ConfInquire( "windom.relief.color", "%d", &conf->actcol);
	
	/* popup  */
	ConfInquire( "windom.popup.color",  "%d", &conf->popcolor);
	ConfInquire( "windom.popup.border", "%d", &conf->popborder);
	ConfInquire( "windom.popup.framec", "%d", &conf->popfcolor);
	ConfInquire( "windom.popup.pattern","%d", &conf->poppatt);
	if( ConfInquire( "windom.popup.relief", "%b", &dum) >= 1)
		if( dum) conf->poppatt |= 0x100;
	if( ConfInquire( "windom.popup.window", "%s", buf) >= 1 ) {
		if( !stricmp( buf, "default"))	conf->popwind = DEFVAL;
		if( !stricmp( buf, "false"))	conf->popwind = FALSE;
		if( !stricmp( buf, "true"))		conf->popwind = TRUE;
	}

	/* GrectCenter */
	if( ConfInquire( "windom.window.center", "%s", buf) >= 1) {
		if( !stricmp( buf, "screen"))	conf->wcenter = CENTER;
		if( !stricmp( buf, "mouse"))	conf->wcenter = WMOUSE;
		if( !stricmp( buf, "upleft"))	conf->wcenter = UP_LEFT;
		if( !stricmp( buf, "upright"))	conf->wcenter = UP_RIGHT;
		if( !stricmp( buf, "dnleft"))	conf->wcenter = DN_LEFT;
		if( !stricmp( buf, "dnright"))	conf->wcenter = DN_RIGHT;
		if( !stricmp( buf, "form"))		conf->wcenter = FCENTER;
	}

	/* Fen�tres */
	if( ConfInquire( "windom.window.effect", "%s", buf) >= 1) {
		if( !stricmp( buf, "default"))	conf->weffect = DEFVAL;
		if( !stricmp( buf, "false"))	conf->weffect = FALSE;
		if( !stricmp( buf, "true"))		conf->weffect = TRUE;
	}
	ConfInquire( "windom.mform.widget", "%x", &conf->mwidget);
	ConfInquire( "windom.window.bg.pattern", "%d", &conf->bgpatt);
	ConfInquire( "windom.window.bg.color", "%d", &conf->bgcolor);
	ConfInquire( "windom.window.bg.style", "%d", &conf->bgstyle);
	
	/* Autres */
	dum = TRUE;
	if( ConfInquire( "windom.fsel.fslx", "%b", &dum) > 0)
		SET_BIT( conf->flag, FLG_NOMGXFSEL, !dum);
	ConfInquire( "windom.shortcut.color", "%d", &conf->key_color);
	ConfInquire( "windom.menu.effect", "%d", &conf->menu_effect);
	ConfInquire( "windom.frame.widget.size", "%d", &conf->fwidsize);

/*	dum = FALSE;
	if( ConfInquire( "windom.menu.autokey", "%b", &dum))
		SET_BIT( conf->flag, FLG_NOKEYMENU, !dum); */

	dum = FALSE;
	if( ConfInquire( "windom.menu.scroll", "%b", &dum) > 0)
		SET_BIT( conf->flag, FLG_MNSCRL, dum);
	dum = FALSE;
	if( ConfInquire( "windom.menu.system", "%b", &dum) > 0)
		SET_BIT( conf->flag, FLG_MNSYSTEM, dum);
	ConfInquire( "windom.iconify.geometry", "%d,%d", &conf->wicon, &conf->hicon);
	if( ConfInquire( "windom.version", "%b", &dum)>=1 && dum) {
		sprintf( path, "[1][******* WinDom version *******|"
						   "version number: %x.%02x R%02d|"
						   "date : %s at %s|"
						   "compiler : %s ][Ok]",
				 WinDom.patchlevel>>8, WinDom.patchlevel&0x00FF,
				 WinDom.release, WinDom.date, WinDom.time, WinDom.cc_name);
		form_alert( 1, path);
	}
	return 0;
}

