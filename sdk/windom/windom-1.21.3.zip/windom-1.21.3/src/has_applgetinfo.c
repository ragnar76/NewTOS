/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/has_applgetinfo.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:14:14 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"
#include "cookie.h"

/*
 * appl_getinfo () accessible avec:
 * AES 4.00 (multitos,n_aes,geneva)
 * MagiC 3, Wdialog
 * WinX 2.2
 */

int has_appl_getinfo( void) {
	INT16 ign;
	
	if( _AESversion >= 0x0400    || 	/* AES 4 */
		appl_find( "?AGI") != -1 ||		/* MagiC >= 3 ou Wdialog ou winX >= 2.3 
										 * il semble que se soit la m�thode officielle
										 * pour tester la pr�sence de appl_getinfo(),
										 * ATTENTION : WinX  2.3 : "?AGI    " */
		/* et pour WinX >= 2.1 */
		( wind_get( 0, 1, &ign, &ign, &ign, &ign) == 0 &&				/* on v�rifie que wind_set() accepte les valeurs non l�gales */
		  wind_get( 0, WF_WINX, &ign, &ign, &ign, &ign) == WF_WINX))	/* et on teste la pr�sence de WinX */
		return 1;
	else
		return 0;
}
