/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_get.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.6 $
 */

#include <stdarg.h>
#include <stddef.h>
#include <stdlib.h>
#include "globals.h"
#include "cookie.h"

static int __CDECL (*icfs)( int f, ...);

/*
 *	WindGet()  -  Get window parameters
 */

#ifndef __MSHORT__

/* Version for 32 bits compilers */

int WindGet( WINDOW *win, int mode, INT16 *x, INT16 *y, INT16* w, INT16 *h ) {
	INT16 xc, yc, wc, hc;
	int res=0;
	GRECT gin, gout;
	void* proc;

#else 

/* Version for 16 bits compilers */

int WindGet( WINDOW *win, int mode, ...) {
	va_list args;
	INT16 *x, *y, *w, *h;
	INT16 xc, yc, wc, hc;
	int res=0;
	GRECT gin, gout;
	void* proc;

	va_start( args, mode);
	x = va_arg( args, INT16*);
	y = va_arg( args, INT16*);
	w = va_arg( args, INT16*);
	h = va_arg( args, INT16*);
	va_end( args);

#endif

	switch( mode) {
	case WF_MENU:
		*x = (WORD)( ((LONG)(win->menu.root)>>16) & 0x0000FFFF);
		*y = (WORD)( (LONG)(win->menu.root) & 0x0000FFFF);
		proc = EvntFind( win, MN_SELECTED);
		*w = (WORD)( ((LONG)(proc)>>16) & 0x0000FFFF);
		*h = (WORD)( (LONG)(proc) & 0x0000FFFF);		
		break;
	case WF_TOOLBAR:
		*x = (WORD)( ((LONG)(win->tool.root)>>16) & 0x0000FFFF);
		*y = (WORD)( (LONG)(win->tool.root) & 0x0000FFFF);
		proc = EvntFind( win, WM_TOOLBAR);
		*w = (WORD)( ((LONG)(proc)>>16) & 0x0000FFFF);
		*h = (WORD)( (LONG)(proc) & 0x0000FFFF);		
		break;
	case WF_HILIGHT:
		*x = (WORD)( ((LONG)(win->menu.hilight)>>16) & 0x0000FFFF);
		*y = (WORD)( (LONG)(win->menu.hilight) & 0x0000FFFF);		
		break;
	case WF_FTOOLBAR:
	case WF_NTOOLBAR:
		wind_get( win->handle, mode == WF_FTOOLBAR?WF_FIRSTXYWH:WF_NEXTXYWH,
				  &gin.g_x, &gin.g_y, &gin.g_w, &gin.g_h);
		rc_set( &gout, win->tool.root->ob_x, win->tool.root->ob_y,
			 		win->tool.root->ob_width, win->tool.root->ob_height);
		rc_intersect( &gin, &gout);
		*x = gout.g_x;
		*y = gout.g_y;
		*w = gout.g_w;
		*h = gout.g_h;
		break;
	case WF_WORKXYWH:
		if( win -> status & WS_FRAME) {
			res = (*__calc)( win, 0, x, y, w, h);
			break;
		}
		if( win -> status & WS_ICONIFY) {
			res = wind_get( win -> handle, mode, x, y, w, h);
			break;
		}
		res = wind_get( win -> handle, WF_CURRXYWH, &xc, &yc, &wc, &hc);
		if( wc == 0 && hc == 0) {
			WindCalc( 1, win, win->createsize.g_x, win->createsize.g_y, 
						win->createsize.g_w, win->createsize.g_h, x, y, w, h);
		} else
			WindCalc( 1, win, xc, yc, wc, hc, x, y, w, h);
		break;
	case WF_CURRXYWH:
		if( win -> status & WS_FRAME)
			res = (*__calc)( win, 1, x, y, w, h);
		else
			res = wind_get( win->handle, WF_CURRXYWH, x, y, w, h);
			if( *w == 0 && *h == 0) {
				*x = win->createsize.g_x;
				*y = win->createsize.g_y;
				*w = win->createsize.g_w;
				*h = win->createsize.g_h;
			}
		break;
	case WF_BEVENT:
		if( win->status & WS_UNTOPPABLE)
			*x |= BEVENT_WORK;
		else
			*x &= ~BEVENT_WORK;
		if( win->status & WS_MODAL)
			*x |= BEVENT_MODAL;
		else
			*x &= ~BEVENT_MODAL;
		break;
	case WF_ICONIFY:
		wind_get( win->handle, WF_CURRXYWH, x, h, y, w);
		*x=(win->status&WS_ICONIFY)?1:0;
		if( *x == 0 ) {
			if( get_cookie( ICFS_COOKIE, (long *)&icfs))
				(*icfs)( ICF_GETSIZE, y, w);
			else {
				*y = CONF(app)->wicon;
				*w = CONF(app)->hicon;
			}
		}
		break;
	case WF_UNICONIFY:
		*x=win->icon.x;
		*y=win->icon.y;
		*w=win->icon.w;
		*h=win->icon.h;
		break;
	case WF_BOTTOM:
		if( !(app.aes4 & AES4_BOTTOM))
			*x = __windowlist[0];
		else
			wind_get( 0, WF_BOTTOM, x, 0, 0, 0);
			
		break;
	case WF_TOP:
		/* Emulate WM_UNTOPPED 
		 * the previous topmost window will receive 
		 * a WM_UNTOPPED message */
		
		if( !(app.aes4 & AES4_UNTOPPED)){
			WINDOW *wtop;
			INT16 dum, dum2;
						
			wind_get( win->handle, WF_TOP, &dum, &dum2, &dum2, &dum2);
			wtop= WindHandle( dum);
			if( wtop)
				snd_msg( wtop, WM_UNTOPPED, 0, 0, 0, 0);
		}
		wind_get( 0, WF_TOP, x, 0, 0, 0);
		break;

	/* Sliders and frame */

	case WF_HSLIDE:
		if( win->status & WS_FRAME)
			*x=GETFINFO(win)->hsldpos;
		else
			wind_get( win->handle, mode, x, y, w, h);
		break;
	case WF_VSLIDE:
		if( win->status & WS_FRAME)
			*x=GETFINFO(win)->vsldpos;
		else
			wind_get( win->handle, mode, x, y, w, h);
		break;
	case WF_HSLSIZE:
		if( win->status & WS_FRAME)
			*x=GETFINFO(win)->hsldsize;
		else
			wind_get( win->handle, mode, x, y, w, h);
		break;
	case WF_VSLSIZE:
		if( win->status & WS_FRAME)
			*x=GETFINFO(win)->vsldsize;
		else
			wind_get( win->handle, mode, x, y, w, h);
		break;
	case WF_NAME:
		*x = (WORD)( ((LONG)(win->name)>>16) & 0x0000FFFF);
		*y = (WORD)( (LONG)(win->name) & 0x0000FFFF);
		break;
	case WF_ICONTITLE:
		*x = (WORD)( ((LONG)(win->icon.name)>>16) & 0x0000FFFF);
		*y = (WORD)( (LONG)(win->icon.name) & 0x0000FFFF);
		break;
	case WF_ICONDRAW:
		*x = (WORD)( ((LONG)(win->icon.draw)>>16) & 0x0000FFFF);
		*y = (WORD)( (LONG) (win->icon.draw) 	  & 0x0000FFFF);
		break;		
	default:
		res = wind_get( win?win->handle:0, mode, x, y, w, h);
		break;
	}
	return res;
}

