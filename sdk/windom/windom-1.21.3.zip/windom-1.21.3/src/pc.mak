#!make -f
#
# WinDom: a high level GEM library
# Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
#
# $Source: /cvsroot/windom/windom/src/pc.mak,v $
# Makefile for 'WinDOM' an its utility
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/02 19:29:44 $
#  $Revision: 1.3 $

# makefile for windom 
# pure c version


# note:
# CC_PUREC must point to your pcc.ttp program
# AR_PUREC must point to your plink.ttp program
# AS_PUREC must point to your pasm.ttp program
# PURECINC must point to your pure_c/include directory

CC     = $(CC_PUREC)
AS     = $(AS_PUREC)
AR     = $(AR_PUREC) -J

CFLAGS = -I$(PURECINC) -I../include -DMODIF_XEDIT $(XCFLAGS) -P

# no extra objects
EXTRAOBJ  =

include files.mak

.SUFFIXES:
.SUFFIXES: .c .s .o

# PCC.TTP crashes with long filename, so...
.c.o:
	cp $*.c tmppc.c
	$(CC) $(CFLAGS) -Otmppc.o tmppc.c
	mv -f tmppc.o $*.o

# PASM.TTP generates filename in UPPERCASE, so...
.s.o:
	$(AS) -OTMPPC.O $*.s
	mv TMPPC.O  $*.o

TARGET = $(LIB_PUREC)

all: $(TARGET)

$(TARGET): $(WINDOMOBJ)
	rm -f $@
	$(AR) $^
	mv -f Linker.Out $@

clean:
	$(RM) $(WINDOMOBJ)
