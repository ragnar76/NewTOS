/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/globals.c,v $
 * Module : global variables
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/06/29 18:19:27 $
 *   $Revision: 1.4 $
 */


#include "globals.h"

#define VERSION ((__WINDOM_MAJOR__ / 10) << 12) | ((__WINDOM_MAJOR__ % 10) << 8) | \
                ((__WINDOM_MINOR__ / 10) << 4 ) |  (__WINDOM_MINOR__ % 10)

#define RELEASE  __WINDOM_REVISION__

struct w_version  WinDom = 
#ifdef __PUREC__
			{ VERSION, RELEASE, __DATE__, __TIME__, "Pure C", __PUREC__};
#else
#ifdef __GNUC__
			{ VERSION, RELEASE, __DATE__, __TIME__, "Gnu C", __GNUC__};
#else
#ifdef __SOZOBONX__ 
			{ VERSION, RELEASE, __DATE__, __TIME__, "Sozobon X", __SOZOBONX__};

#endif
#endif
#endif

static CONFIG config = {  
				0,								/* flags */
				72, 72, 						/* icon size */
				WHITE,FIS_SOLID, 8,				/* window background style */
				LTMFLY_COLOR|BLACK,				/* keyshort color */
		
				/* sizes are in point units (not pixel) */
			 	/* font, size, color, [small size] */
				{SYSFONT, 13, BLACK},			/* string */
				{SYSFONT, 13, BLACK},			/* button */
				{SYSFONT, 13, BLACK},			/* exit */
				{SYSFONT, 13, BLACK},			/* title */
				{SYSFONT, 13, DEFVAL},			/* xedit texte */
				{SYSFONT, 13, DEFVAL},			/* xedit label */
				BLACK,							/* xedit cursor color */
				{SYSFONT, 10, DEFVAL}, 8,		/* xlongedit */
				{SYSFONT, 10, DEFVAL}, 8,		/* xtedinfo */
				0,								/* Mono */
				LWHITE,							/* Color */
				3,								/* Menu effect */
				{BLACK, 13, 1},					/* Bubble GEM */
				WHITE, 2, BLACK, 0x100, DEFVAL,	/* Popup */
				CENTER, DEFVAL,
				NAME|MOVER,
				-1 								/* Frame Widget Size, -1 (default) */
				};

APPvar app = {  &config,
				-1, 0, 0,
				0, 0, 0, 0,
				0, 0, NULL, NULL,
				{1,1,1,1,1,1,1,1,1,1,2}};

WINvar wglb = { NULL, NULL, NULL};

EVNTvar evnt = { 0L, 258, 3, 0,
				 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0,
				 {0,0,0,0,0,0,0,0},
				 0, 0, 0, 0,
				 0, 0 };



int    _res;					/* r�solution actuelle
								 * 0 - basse, 1 - haute	
								 */

WORD __windowlist[ MAX_WINDOW];	/*  handle fenetre suivante
								 *  0 fenetre ferme ou inexistante
								 *  -1 top fenetre
								 */

WORD __iconlist[ MAX_ICON];		/* position des icones
								 * 0 position libre
								 */

GRECT clip;						/* coordonn�es de la zone
								 * de masquage.
								 */

short *_AESglobal;				/* Tableau global de l'AES
								 */

/* Utilis�s pour lier les frames au noyau de windom */
int  (*__calc)( struct _window *, int, INT16 *, INT16 *, INT16 *, INT16 *);
void (*__swgt)( struct _window *, GRECT *, int);
int	 (*__rfrm)( struct _window *, struct _window *);

/* Utilis� par les modules Bubble et Appl */
int __bubble_quit = -1;

/* Utilis� par MenuEnable et MenuDisable */
int _menu_disabled = 0;

/* bubble */
struct bubble *bubble_index=NULL;     /* interne */
long __bubble_conf = -1;				 /* interne */


/* Pour WinConf */
char __confpath [FILE_SIZE];

/* Emulation des fonts Gdos */
struct fontid *listfontid;
int maxfontid=0;		/* non charg�e */


/* Configuration de l'application */
char *__confapp_buffer = NULL;
int __confapp_line_top;
int __confapp_line_pos;

/* Configuration par defaut (Default Settings) */
char *__confdef_buffer = NULL;
int __confdef_line_top;
int __confdef_line_pos;

/* avlib */
char *__av_name;					/* nom du client (notre appli) */
char __av_server[9];				/* nom du serveur AV */
INT16 __av_status[3]={0,0,0};	/* action support�s par le serveur */


/* EOF */
