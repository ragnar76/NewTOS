/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/rc_clip_on.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:03:53 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/* etablit un rectangle de masquage */

void rc_clip_on( int handle, GRECT *r) {
	INT16 xy[4];

	xy[0] = MAX( app.x, r->g_x);
	xy[1] = MAX( app.y, r->g_y);
	xy[2] = MIN( app.x+app.w-1, r->g_x+r->g_w-1);
	xy[3] = MIN( app.y+app.h-1, r->g_y+r->g_h-1);
	rc_set( &clip, xy[0], xy[1], xy[2]-xy[0]+1, xy[3]-xy[1]+1);
	vs_clip( handle, 1, xy);
}
