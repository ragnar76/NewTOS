/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/obj_fd_xtype.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:03:58 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 *	Recherche de type (�tendus)
 */

int obj_fd_xtype( OBJECT *dial, int racine, int type) {
	while( 1) {
		if( (dial[racine].ob_type>>8) == type)
			return( racine);
		racine = get_next_obj( dial, racine);
		if (racine == -1)
			return -1;
	}
}

