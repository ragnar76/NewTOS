/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/options.h,v $
 * Module : WinDom compilation options
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/25 19:32:16 $
 *   $Revision: 1.2 $
 */


/*
 *	WINDOMDEBUG   : write trace in a log file.
 */

/* #define WINDOMDEBUG */

/*
 *	GFORM      1  : WinDom g�re les click bouton des
 *					formulaire avant de retourner le
 *					message WM_FORM
 *             0  : WinDom se contente de retourner
 *					directement le message
 */

#define GFORM 1

/* taille des tableaux __windowlist et __iconlist */

#define MAX_WINDOW	100
#define MAX_ICON 	100

/* taille de buffers */
#define FILE_SIZE	255		/* nom fichier */
#define LINE_SIZE	150		/* longueur ligne pour fget() */
#define PIPE_SIZE	256		/* taille du pipeline GEM */

/* Seuil pour la r�allocation des objets XEDIT */
#define XEDIT_REALLOC 128
