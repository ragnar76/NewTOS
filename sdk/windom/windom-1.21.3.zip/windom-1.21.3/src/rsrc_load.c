/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/rsrc_load.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:00:30 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include <stdlib.h>
#ifdef __PUREC__
#include <tos.h>
#endif
#include <string.h>
#include "globals.h"

#ifndef FO_READ
#define FO_READ 0
#endif

/*
 *	RsrcLoad() en plus de l'appel de rsrc_load() initialise la
 *	variable app.ntree pour la fonction RsrcXtype().
 * 
 *  Sous Naes, les chemins TOS ne sont pas reconnus
 *  par rsrc_load(). La foncton conv_path() entre en action.
 */

int RsrcLoad( const char *name) {
	int res;
	RSHDR RSCheader;
	int fd;
	char path[255];
	
	strcpy( path, name);
	res = rsrc_load( path);
	if( !res) {
		/* try other format */
		conv_path(path);
		res = rsrc_load( path);
	}
	if( !res) return 0;
	fd = (int)Fopen( path, FO_READ);
	if( fd < 0 && shel_find( path))
		fd = (int)Fopen( path, FO_READ);
	if( fd < 0) {
		/* should not occured */
		rsrc_free();
		return 0;
	}
	Fread( fd, sizeof( RSHDR), &RSCheader);
	app.ntree = (signed int)RSCheader .  rsh_ntree;
	Fclose( fd);
	return 1 ;
}
