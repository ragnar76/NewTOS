/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/menu_tnormal.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2004/11/19 20:30:39 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

int MenuTnormal( WINDOW *win, int title, int mode) {
	int res=0;
	GRECT work;
	GRECT rect;

	if( win == NULL)
		res = menu_tnormal( app.menu, title, mode);
	else {
		wind_get_grect( win->handle, WF_WORKXYWH, &work);
		objc_offset(win->menu.root, title, &rect.g_x, &rect.g_y);
		rect.g_w = win->menu.root[title].ob_width;
		rect.g_h = win->menu.root[title].ob_width;
		
		if( mode)
			win->menu.root[title].ob_state &= ~SELECTED;
		else
			win->menu.root[title].ob_state |= SELECTED;
		
		if (rc_intersect( &work, &rect))
			res = ObjcWindDraw( win, win->menu.root, 1, 2, rect.g_x, rect.g_y, rect.g_w, rect.g_h);
	}
	return res;
}

