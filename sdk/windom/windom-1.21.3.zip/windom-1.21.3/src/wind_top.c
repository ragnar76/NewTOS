/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_top.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"


/* top a window */

void WindTop( WINDOW *win) {
	INT16 x, y, w, h;
	
	if( win -> status & WS_ICONIFY) {
		WindGet( win, WF_UNICONIFY, &x, &y, &w, &h);
		ApplWrite( app.id, WM_UNICONIFY, win->handle, x, y, w, h);
	} else if( win -> status & WS_OPEN) 
		/* window opened */
		wind_set( win -> handle, WF_TOP, 0, 0, 0, 0);
	else {
		wind_get( win->handle, WF_PREVXYWH, &x, &y, &w, &h);
		WindOpen( win, x, y, w, h);
	}
}

