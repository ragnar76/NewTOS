/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/wind_attach.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/10/21 21:24:18 $
 *   $Revision: 1.2 $
 */

#include <stddef.h>
#include <stdlib.h>
#include "globals.h"

/*
 * Create a new WINDOW structure, and attach an external window
 * (usefull for window created using wind_create() instead
 *  of its windom replacement WindCreate())
 */

WINDOW *WindAttach( int handle) {
	WINDOW *win;
	INT16 dum, _h;

	win = (WINDOW *)calloc( 1, sizeof(WINDOW));
	if( win == NULL) return NULL;
	win -> handle = handle;
	win -> status |= WS_OPEN;
	AddWindow( win);
	add_windowlist( handle);
	win->graf.handle = graf_handle( &dum, &dum, &dum, &dum);
	v_opnvwk( app.work_in, &win->graf.handle, app.work_out);
	win -> graf.palette = NULL;
	wind_get( handle, WF_TOP, &_h, &dum, &dum, &dum);
	if( _h == win->handle)
		wglb.front = wglb.appfront = win;
	return win;
}

