/*
 * WinDom: a high level GEM library
 * Copyright (c) 1997-2003 Dominique Bereziat & Arnaud Bercegeay
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Source: /cvsroot/windom/windom/src/frm_mvd.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/02/24 20:18:47 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "globals.h"

/*
 * Message WM_MOVED
 */
 
void frm_mvd( WINDOW *win) {
	INT16 x, y, w, h;
	int outlined = 0;
	W_FORM *dial = DataSearch( win, WD_WFRM);
	 	
 	x = evnt.buff[4];
	y = evnt.buff[5];
	w = evnt.buff[6];
	h = evnt.buff[7];
	wind_set( evnt.buff[3], WF_CURRXYWH, x, y, w, h);
	win->status &= ~WS_FULLSIZE;
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	if( dial->root->ob_state & OUTLINED )
		outlined = OUTLINED_WIDTH;
	dial->root[ROOT].ob_x = x + outlined - (int)win->xpos*win->w_u;
	dial->root[ROOT].ob_y = y + outlined - (int)win->ypos*win->h_u;
}

