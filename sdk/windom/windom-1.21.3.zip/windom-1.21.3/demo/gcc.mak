#!make -f
#
# $Source: /cvsroot/windom/windom/demo/gcc.mak,v $
# Makefile for 'WinDOM' demo program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2004/07/07 20:13:12 $
#  $Revision: 1.3 $

# gcc version

ifeq ($(CROSS),yes)
CC = m68k-atari-mint-gcc
else
CC = gcc
endif

CFLAGS = 
LDFLAGS = -Xlinker -L../lib/gcc

WARN = \
        -Wall \
        -Wmissing-prototypes \
        -Winline \
        -Wshadow \
        -Wpointer-arith \
        -Wcast-qual \
        -Waggregate-return

CFLAGS += -O2 -fomit-frame-pointer -I../include $(WARN)

include files.mak

demo.app : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS) ../lib/gcc/libwindom.a -lgem

