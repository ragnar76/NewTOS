/*
 * DEMO: This file is a part of WinDom Developer Kit
 * Copyright (c) 1996-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/demo/win-cust.c,v $
 * Full example of a customized window.
 * The window contains a menu, the work area displays geometric forms.
 * A timer is applied to the window to change its contain.
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/11/30 10:41:10 $
 *   $Revision: 1.4 $
 */

#include <stdlib.h>
#include <windom.h>
#include "demo.h"
#include "global.h"

/* First of all, we define the data related to
 * the window.
 */

typedef struct {
	int color;		/* foreground color */
	int type;		/* SQUARE, ELLIPSE or CIRCLE */
	int bckgrd;		/* background color */
} DRAW;

/* The WM_REDRAW event function. This function is
 * called when the window is drawn.
 * Notice we must not clip the redraw area (this is
 * done by EvntWindom()).
 */

static void draw_custom( WINDOW *win, DRAW *draw) {
	INT16 x,y,w,h;
	INT16 xy[4];
 	
	/* get the work area coordinates */
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);

	/* Background */
	xy[0] = x;xy[1] = y;xy[2] = x+w-1;xy[3] = y+h-1;
	switch( draw->bckgrd){
	case MN2_WHITE:
		vsf_color( win->graf.handle, WHITE);
		vsf_interior( win->graf.handle, FIS_SOLID);
		break;
	case MN2_BLACK:
		vsf_color( win->graf.handle, BLACK);
		vsf_interior( win->graf.handle, FIS_SOLID);
		break;
	case MN2_GREY:
		vsf_color( win->graf.handle, BLACK);
		vsf_style( win->graf.handle, 4);
		vsf_interior( win->graf.handle, FIS_PATTERN);
		break;
	}
	v_bar( win->graf.handle, xy);

	/* style */	
	if( app.color < 16) {
		/* low color resolution */
		vsf_interior( win->graf.handle, FIS_PATTERN);
		vsf_style( win->graf.handle, draw->color);
	} else {
		/* high color resolution */
		vsf_interior( win->graf.handle, FIS_SOLID);
		vsf_color( win->graf.handle, draw->color);
	}
	
	/* Foreground */
	switch( draw->type){
	case MN2_SQUARE:
		xy[0] += w/8;
		xy[1] += h/8;
		xy[2] -= w/8;
		xy[3] -= h/8;
		v_bar( win->graf.handle, xy);
		break;
	case MN2_CIRCLE:
		v_circle( win->graf.handle, x+w/2-1,y+h/2-1, MIN(w,h)/3);
		break;
	case MN2_ELLIPSE:
		v_ellipse( win->graf.handle, x+w/2-1,y+h/2-1, w/3, h/3);
		break;
	}
}

/*
 *	MU_TIMER event function.
 *	When a timer event occurs, the function changes
 *  the foreground color.
 */

static void timer_custom( WINDOW *win, DRAW *draw) {
	draw->color = ++draw->color % 16;
	snd_rdw( win);
}

/*
 * The WM_DESTROY event function.
 * The function releases the memory, closes,
 * and destroys the window.
 */

static void destroy_custom( WINDOW *win, DRAW *draw) {
	free(draw);
}

#ifdef OLDWAY_MENU_HANDLER

/* This is an example of old way to handle
 * object selection in a menu */

/*
 * The MN_SELECTED event function : the
 * fonction is called when the user selects an
 * item in the menu.
 */

static void menu_custom( WINDOW *win, DRAW *draw) {
	int title = evnt.buff[3];	/* keep in memory the
								 * selected menu title */
	switch( evnt.buff[4]){
	case MN2_INFO:
		/* Displays info about the window */
		display_info( win, 0);
		break;
	case MN2_CIRCLE:
	case MN2_SQUARE:
	case MN2_ELLIPSE:
		/* Set the pattern */
		draw->type = evnt.buff[4];
		snd_rdw( win);
		break;
		/* Timer control */
	case MN2_FAST:
		evnt.timer = MAX( evnt.timer-300,0);
		break;
	case MN2_SLOW:
		evnt.timer = MIN( evnt.timer+300,10000);
		break;
		/* Set the color */
	case MN2_WHITE:
	case MN2_BLACK:
	case MN2_GREY:
		draw->bckgrd = evnt.buff[4];
		snd_rdw( win);
		break;
	}
	MenuTnormal( win, title, 1);
}

#else

/* Here, there is an example of the new way to
 * handle object selection in a menu */


/* This callback function is called when the
 * user operates in a menu window */

static void menu_hilight( WINDOW *win) {
	MenuTnormal( win, evnt.buff[3], 1);
}

/* Other functions are callback binded on
 * specific menu item object */

static void mn2_info( WINDOW *win) {
	display_info( win, 0);	
}

static void mn2_fast( WINDOW *win) {
	evnt.timer = MAX( evnt.timer-300,0);
}

static void mn2_slow( WINDOW *win) {
	evnt.timer = MAX( evnt.timer+300,10000);
}

static void mn2_pattern( WINDOW *win, int index, int mode, int title, DRAW *draw) {
	draw->type = index; 
	snd_rdw( win);
}

static void mn2_color( WINDOW *win, int index, int mode, int title, DRAW *draw) {
	draw->bckgrd = index; 
	snd_rdw( win);
}
#endif

/* Create the window with its attributes */

void create_custom( void) {
	WINDOW *win;
	OBJECT *tree;
	DRAW *draw;
	
	/* Create the window */
	win = WindCreate( NAME|CLOSER|MOVER|SMALLER|MENUBAR, app.x, app.y, app.w, app.h);
	/* MENUBAR is a special widget usefull for system supporting
   * window menu (like xaAES). WinDom can support window menu but leaves the
	 * choice of menu handling (windom or system) to user (via WinDom Configuration)
	 */

	/* Create data */
	draw = (DRAW*)malloc(sizeof(DRAW));
	draw->bckgrd = MN2_GREY;
	draw->type   = MN2_SQUARE;
	draw->color = 0;
	/* Attach the menu */
	rsrc_gaddr( 0, MENU2, &tree);
#ifdef OLDWAY_MENU_HANDLER
	WindSetPtr( win, WF_MENU, tree, NULL);
	EvntDataAttach( win, MN_SELECTED, menu_custom, draw);
#else
	WindSetPtr( win, WF_MENU, tree, menu_hilight);

	/* Here we bind callback function to objects */
	ObjcAttach( OC_MENU, win, MN2_INFO,    BIND_FUNC, mn2_info);
	ObjcAttach( OC_MENU, win, MN2_FAST,    BIND_FUNC, mn2_fast);
	ObjcAttach( OC_MENU, win, MN2_SLOW,    BIND_FUNC, mn2_slow);
	ObjcAttach( OC_MENU, win, MN2_CIRCLE,  BIND_FUNC, mn2_pattern, draw);
	ObjcAttach( OC_MENU, win, MN2_SQUARE,  BIND_FUNC, mn2_pattern, draw);
	ObjcAttach( OC_MENU, win, MN2_ELLIPSE, BIND_FUNC, mn2_pattern, draw);
	ObjcAttach( OC_MENU, win, MN2_WHITE,   BIND_FUNC, mn2_color, draw);
	ObjcAttach( OC_MENU, win, MN2_BLACK,   BIND_FUNC, mn2_color, draw);
	ObjcAttach( OC_MENU, win, MN2_GREY,    BIND_FUNC, mn2_color, draw);
#endif

	/* Give a title to window */
	WindSetStr( win, WF_NAME, get_string( MENU_TITLE));
	/* Attach event functions */
	EvntDataAttach( win, WM_REDRAW, draw_custom, draw);
	EvntDataAdd( win, WM_DESTROY, destroy_custom, draw, EV_TOP);
	EvntDataAttach( win, WM_XTIMER, timer_custom, draw);

	create_infos( win, INFOS_MENU, MENU2);
	/* open the window */
	WindOpen( win, -1, -1, 280, 200);
}
