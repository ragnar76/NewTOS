/*
 * DEMO: This file is a part of WinDom Developer Kit
 * Copyright (c) 1996-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/demo/util.c,v $
 * Diverse and usefull functions
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/13 19:12:28 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <windom.h>
#include "global.h"
#include "demo.h"

/* Return a string from resource file */

char *get_string( int idx) {
	char *txt;	
	rsrc_gaddr( 5, idx,  &txt);
	return txt;
}

OBJECT *get_tree( int idx) {
  OBJECT *tree;
  rsrc_gaddr( 0, idx, &tree);
  return tree;
}

/*
 * Initialize the information of a window
 */

void create_infos( WINDOW *win, int type, int idx) {
	WINFO *inf;
	
	inf = DataSearch( win, WD_WINF);
	if( inf == NULL) {
		inf = (struct infos *)malloc( sizeof(struct infos));
		inf->menu = inf->toolbar = inf->form = -1;
	}
	switch( type) {
	case INFOS_MENU:
		inf->menu = idx;
		break;
	case INFOS_TOOL:
		inf->toolbar = idx;
		break;
	case INFOS_FORM:
		inf->form = idx;
		break;
	}
	DataAttach( win, WD_WINF, inf);
}

/*
 *	Display informations about a window 
 */

void display_info( WINDOW *win, int handle) {
	OBJECT *tree;

	rsrc_gaddr( 0, DIAL3, &tree);
	if( win != NULL) {
		sprintf( ObjcString( tree, DL3_GEM, NULL), "%d", win -> handle);
		if( win -> status & WS_FORM)
			strcpy( ObjcString( tree, DL3_TYPE, NULL), get_string( TYPE_FORM));
		else
			strcpy( ObjcString( tree, DL3_TYPE, NULL), get_string( TYPE_ANY));
		if( win -> attrib & SMALLER)
			strcpy( ObjcString( tree, DL3_ICON, NULL), get_string( ANS_YES));
		else
			strcpy( ObjcString( tree, DL3_ICON, NULL), get_string( ANS_NO));
		if( win -> status & WS_TOOLBAR)
			strcpy( ObjcString( tree, DL3_TOOL, NULL), get_string( ANS_YES));
		else
			strcpy( ObjcString( tree, DL3_TOOL, NULL), get_string( ANS_NO));
		if( win -> status & WS_MENU)
			strcpy( ObjcString( tree, DL3_MENU, NULL), get_string( TYPE_FORM));
		else
			strcpy( ObjcString( tree, DL3_MENU, NULL), get_string( TYPE_FORM));
	} else {
		sprintf( ObjcString( tree, DL3_GEM, NULL), "%d", handle);
		strcpy( ObjcString( tree, DL3_TYPE, NULL), get_string( TYPE_ALIEN));
		strcpy( ObjcString( tree, DL3_ICON, NULL), "-");
		strcpy( ObjcString( tree, DL3_TOOL, NULL), "-");
		strcpy( ObjcString( tree, DL3_MENU, NULL), "-");
	}
	FormWindBegin( tree, get_string( WINDNAME));
	FormWindDo(MU_MESAG|MU_KEYBD|MU_TIMER);
	FormWindEnd();
	ObjcChange( OC_OBJC, tree, DL3_OUI, NORMAL, 0);
}

/*
 * Example of window icon drawing function
 */

void draw_color_icon( WINDOW *win) {
	OBJECT *tree = get_tree( COLOR_ICON);
	INT16 w, h;
	
	WindGet( win, WF_WORKXYWH, &tree->ob_x, &tree->ob_y, &w, &h);
	objc_draw( tree, 0, 2, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
}

void draw_mono_icon( WINDOW *win) {
	OBJECT *tree = get_tree( MONO_ICON);
	INT16 w, h;
	
	WindGet( win, WF_WORKXYWH, &tree->ob_x, &tree->ob_y, &w, &h);
	objc_draw( tree, 0, 2, clip.g_x, clip.g_y, clip.g_w, clip.g_h);
}


/*
 *	User closer event function
 */

void stdDESTROY( WINDOW *win) {
	DataDelete( win, WD_WINF);
}
