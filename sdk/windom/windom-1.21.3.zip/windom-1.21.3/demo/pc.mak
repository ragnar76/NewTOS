#!make -f
#
# $Source: /cvsroot/windom/windom/demo/pc.mak,v $
# Makefile for 'WinDOM' demo program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/11/29 19:50:24 $
#  $Revision: 1.3 $

# pure c version

# note:
# CC_PUREC must point to your pcc.ttp program
# PURECINC must point to your pure_c/include directory

CC     = $(CC_PUREC)
LNK    = $(AR_PUREC)

CFLAGS = -I../include -I$(PURECINC) -DMODIF_XEDIT $(XCFLAGS) -P


include files.mak

.SUFFIXES:
.SUFFIXES: .c .s .o

# PCC.TTP crashes with long filename, so...
.c.o:
	cp $*.c tmppc.c
	$(CC) $(CFLAGS) -Otmppc.o tmppc.c
	mv -f tmppc.o $*.o

# PASM.TTP generates filename in UPPERCASE, so...
.s.o:
	$(AS) -OTMPPC.O $*.s
	mv TMPPC.O  $*.o

# a revoir...
demo.app : $(OBJ)
	$(LNK) -V -S=32000 -O=demo.app $(PURECLIB)/pcstart.o $(OBJ) \
	       ../lib/purec/windom.lib $(PURECLIB)/gem.lib $(PURECLIB)/pcstdlib.lib $(PURECLIB)/pctoslib.lib
