#!make -f
#
# $Source: /cvsroot/windom/windom/demo/sox.mak,v $
# Makefile for 'WinDOM' demo program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/13 19:12:36 $
#  $Revision: 1.1 $

# sozobonx version

# note:
# CC_SOX must point to your cc.ttp program

CC     = $(CC_SOX)

CFLAGS = -O -I../include
LDFLAGS=  +L-B2 -L../lib/sozobon -lwindom -lgem

include files.mak

demo.app : $(OBJ)
	$(CC) -odemo.app -scrt0.o -O +L-p $(OBJ) $(LDFLAGS)
