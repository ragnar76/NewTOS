#!make -f
#
# $Source: /cvsroot/windom/windom/demo/gcc281.mak,v $
# Makefile for 'WinDOM' demo program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/13 19:12:35 $
#  $Revision: 1.1 $

# gcc 2.81 version

# note:
# CC_GCC281 must point to your gcc.ttp program

CC = $(CC_GCC281)

CFLAGS= -O -fomit-frame-pointer -I../include
LDFLAGS=  -L../lib/gcc281 -lwindom -lgem

include files.mak

demo.app : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS)
