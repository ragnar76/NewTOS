/*
 * DEMO: This file is a part of WinDom Developer Kit
 * Copyright (c) 1996-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/demo/global.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/13 19:12:22 $
 *   $Revision: 1.1 $
 */

#include <stddef.h> /* for NULL definition */
#include <windom.h>

#ifdef __SOZOBON__
long _STKSIZ = 32000;
#endif

struct _param {
	OBJECT *desk;
	WINDOW *winuser;
	int setup;
	int	FrameWidth;
	int FrameColor;
} param = { NULL, NULL, 0, 0, LWHITE};
