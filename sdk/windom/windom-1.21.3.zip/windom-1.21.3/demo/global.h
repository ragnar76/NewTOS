/*
 * DEMO: This file is a part of WinDom Developer Kit
 * Copyright (c) 1996-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/demo/global.h,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/13 19:12:33 $
 *   $Revision: 1.1 $
 */


/*
 * Each window have the following structure. These data are
 * linked to a window using the DataAttach() function and the
 * magic number 'WINF'. Currently these data are used to save
 * the windows characteristics.
 */

typedef
struct infos {
	int menu;			/* index menu */
	int toolbar;		/* index toolbar */
	int form;			/* index form */
} WINFO;

#define INFOS_MENU	1
#define INFOS_TOOL 	2
#define INFOS_FORM	3

#define WD_WINF	0x57494E46L	/* 'WINF' */
#define WD_DRAW 0x44524157L	/* 'DRAW' */

#define SETUP_INSTALL_DESKTOP	0x1
#define SETUP_SAVE_WINDOWS		0x2
#define SETUP_AUTOSAVE			0x4
#define SETUP_XTYPE				0x8

struct _param {
	OBJECT *desk;
	WINDOW *winuser;
	int setup, FrameWidth, FrameColor;
};

extern struct _param param;

/* win-divr.c */
extern void create_simple( void);
extern void call_fontselector( void);
extern void call_fileselector( void);

/* win-cust.c */
extern void create_custom( void);

/* win-fram.c */
extern void create_two_frame(void);
extern void create_three_frame(void);

/* setup.c */
extern void setup_save( void);
extern void setup_read( void);
extern void create_form_conf( void);

/* load-bub.c */
extern int LoadBubble( char *filename);
extern void UnLoadBubble( void);

/* evnt-fnc.c */
extern void ap_term( void);
extern void av_sendclick( void);
extern void av_sendkey( void);
extern void mu_button( void);
extern void menu_binding( void);
extern void menu_desktop( void);

/* win-tool.c */
extern void create_windowtoolbar( void);
extern void create_windowtoolmenu( void);

/* win-form.c */
extern void create_info_form( void);
extern void create_modal_form( void);
extern void create_quit_form( void);
extern void create_widget_form( int dup);

/* utils.c */
extern char *get_string( int __index);
extern OBJECT *get_tree( int __index);
extern void create_infos( WINDOW *win, int type, int __index);
extern void display_info( WINDOW *win, int handle);
extern void draw_color_icon( WINDOW *win);
extern void draw_mono_icon( WINDOW *win);
extern void stdDESTROY( WINDOW *win);

/* evnt-av.c */
extern void av_status ( void );
extern void do_av_opendir( void);
extern void do_av_sendfile( void);
extern void do_av_view( void);
extern void do_av_sendkey( void);

/* windom */
extern void	frm_cls(  WINDOW *win);
extern int ConfWindom( void);
