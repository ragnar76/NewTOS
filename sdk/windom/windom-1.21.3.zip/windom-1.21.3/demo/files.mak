#!make -f
# $Source: /cvsroot/windom/windom/demo/files.mak,v $
# Makefile for 'WinDOM' demo program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/13 19:12:21 $
#  $Revision: 1.1 $

OBJ = global.o win-divr.o win-cust.o evnt-av.o win-fram.o win-tool.o \
 win-form.o setup.o util.o evnt-fnc.o load-bub.o main.o

#eof
