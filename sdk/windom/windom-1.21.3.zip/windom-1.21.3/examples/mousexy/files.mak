#!make -f
#
# $Source: /cvsroot/windom/windom/examples/mousexy/files.mak,v $
# Makefile for 'mousexy' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/28 16:13:21 $
#  $Revision: 1.1 $

OBJ = mousexy.o

#eof
