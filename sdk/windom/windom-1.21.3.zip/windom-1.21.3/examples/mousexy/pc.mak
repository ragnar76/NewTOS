#!make -f
#
# $Source: /cvsroot/windom/windom/examples/mousexy/pc.mak,v $
# Makefile for 'mousexy' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/28 16:13:22 $
#  $Revision: 1.1 $

# pure c version

# note:
# CC_PUREC must point to your pcc.ttp program
# PURECINC must point to your pure_c/include directory

CC     = $(CC_PUREC)
LNK    = $(AR_PUREC)

CFLAGS = -I$(PURECINC) -I../../include -DMODIF_XEDIT $(XCFLAGS) -P


include files.mak

.SUFFIXES:
.SUFFIXES: .c .s .o

# PCC.TTP crashes with long filename, so...
.c.o:
	cp $*.c tmppc.c
	$(CC) $(CFLAGS) -Otmppc.o tmppc.c
	mv -f tmppc.o $*.o

# PASM.TTP generates filename in UPPERCASE, so...
.s.o:
	$(AS) -OTMPPC.O $*.s
	mv TMPPC.O  $*.o

# a revoir...
mousexy.prg : $(OBJ)
	$(LNK) -V -S=32000 -O=$@ $(PURECLIB)/pcstart.o $(OBJ) \
	       ../../lib/purec/windom.lib $(PURECLIB)/gem.lib $(PURECLIB)/pcstdlib.lib $(PURECLIB)/pctoslib.lib
