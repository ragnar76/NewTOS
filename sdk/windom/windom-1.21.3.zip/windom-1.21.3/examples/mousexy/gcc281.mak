#!make -f
#
# $Source: /cvsroot/windom/windom/examples/mousexy/gcc281.mak,v $
# Makefile for 'mousexy' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/28 16:13:21 $
#  $Revision: 1.1 $

# gcc 2.81 version

# note:
# CC_GCC281 must point to your gcc.ttp program

CC = $(CC_GCC281)

CFLAGS= -O -fomit-frame-pointer -I../../include
LDFLAGS=  -L../../lib/gcc281 -lwindom -lgem

include files.mak

mousexy.prg : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS)
