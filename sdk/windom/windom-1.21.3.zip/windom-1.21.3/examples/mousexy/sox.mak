#!make -f
#
# $Source: /cvsroot/windom/windom/examples/mousexy/sox.mak,v $
# Makefile for 'mousexy' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/28 16:13:22 $
#  $Revision: 1.1 $

# sozobonx version

# note:
# CC_SOX must point to your cc.ttp program

CC     = $(CC_SOX)

CFLAGS = -O -I../../include
LDFLAGS=  +L-B2 -L../../lib/sozobon -lwindom -lgem

include files.mak

mousexy.prg : $(OBJ)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ) $(LDFLAGS)
