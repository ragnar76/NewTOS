#!make -f
#
# $Source: /cvsroot/windom/windom/examples/popup/gcc.mak,v $
# Makefile for 'ex_popup' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/11/30 20:17:23 $
#  $Revision: 1.2 $

# gcc version

ifeq ($(CROSS),yes)
CC = m68k-atari-mint-gcc
else
CC = gcc
endif

LDFLAGS = -Xlinker -L../../lib/gcc

WARN = \
        -Wall \
        -Wmissing-prototypes \
        -Winline \
        -Wshadow \
        -Wpointer-arith \
        -Wcast-qual \
        -Waggregate-return

CFLAGS += -O2 -fomit-frame-pointer -I../../include $(WARN)

include files.mak

ex_popup.prg : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS) -lwindom -lgem

