#!make -f
#
# $Source: /cvsroot/windom/windom/examples/popup/files.mak,v $
# Makefile for 'ex_popup' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/28 16:20:44 $
#  $Revision: 1.1 $

OBJ = ex_popup.o

#eof
