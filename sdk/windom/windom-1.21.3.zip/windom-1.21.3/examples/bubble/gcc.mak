#!make -f
#
# $Source: /cvsroot/windom/windom/examples/bubble/gcc.mak,v $
# Makefile for 'bubbltst' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2004/07/12 18:55:16 $
#  $Revision: 1.3 $

# gcc version

ifeq ($(CROSS),yes)
CC = m68k-atari-mint-gcc
else
CC = gcc
endif

LDFLAGS = 

WARN = \
        -Wall \
        -Wmissing-prototypes \
        -Winline \
        -Wshadow \
        -Wpointer-arith \
        -Wcast-qual \
        -Waggregate-return

CFLAGS += -O2 -fomit-frame-pointer -I../../include $(WARN)

include files.mak

bubbltst.prg : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS) ../../lib/gcc/libwindom.a -lgem

