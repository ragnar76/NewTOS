#!make -f
#
# $Source: /cvsroot/windom/windom/examples/bubble/files.mak,v $
# Makefile for 'bubbltst' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/21 17:40:27 $
#  $Revision: 1.1 $

OBJ = bubbltst.o

#eof
