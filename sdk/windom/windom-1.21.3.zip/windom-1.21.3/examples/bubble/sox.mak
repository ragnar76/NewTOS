#!make -f
#
# $Source: /cvsroot/windom/windom/examples/bubble/sox.mak,v $
# Makefile for 'bubbltst' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/21 17:40:27 $
#  $Revision: 1.1 $

# sozobonx version

# note:
# CC_SOX must point to your cc.ttp program

CC     = $(CC_SOX)

CFLAGS = -O -I../../include
LDFLAGS=  +L-B2 -L../../lib/sozobon -lwindom -lgem

include files.mak

bubbltst.prg : $(OBJ)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ) $(LDFLAGS)
