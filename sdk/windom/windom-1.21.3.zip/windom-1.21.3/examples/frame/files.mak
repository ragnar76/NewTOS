#!make -f
#
# $Source: /cvsroot/windom/windom/examples/frame/files.mak,v $
# Makefile for 'bubbltst' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/22 19:09:31 $
#  $Revision: 1.2 $

OBJ1 = marrant.o dragdrop.o viewtext.o

OBJ2 = tstframe.o

OBJ3 = wdiff.o dragdrop.o viewtext.o

OBJ4 = txtframe.o viewtext.o

#eof
