#!make -f
#
# $Source: /cvsroot/windom/windom/examples/frame/gcc.mak,v $
# Makefile for 'frame' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2004/11/22 21:03:29 $
#  $Revision: 1.4 $

# gcc version

ifeq ($(CROSS),yes)
CC = m68k-atari-mint-gcc
else
CC = gcc
endif

#LDFLAGS = -Xlinker -L../../lib/gcc

WARN = \
        -Wall \
        -Wmissing-prototypes \
        -Winline \
        -Wshadow \
        -Wpointer-arith \
        -Wcast-qual \
        -Waggregate-return

CFLAGS += -O2 -fomit-frame-pointer -I../../include $(WARN)

include files.mak

all: marrant.prg tstframe.prg wdiff.prg txtframe.prg

marrant.prg : $(OBJ1)
	$(CC) -o$@ $(OBJ1) $(LDFLAGS) ../../lib/gcc/libwindom.a -lgem

tstframe.prg : $(OBJ2)
	$(CC) -o$@ $(OBJ2) $(LDFLAGS) ../../lib/gcc/libwindom.a -lgem

wdiff.prg : $(OBJ3)
	$(CC) -o$@ $(OBJ3) $(LDFLAGS) ../../lib/gcc/libwindom.a -lgem

txtframe.prg : $(OBJ4)
	$(CC) -o$@ $(OBJ4) $(LDFLAGS) ../../lib/gcc/libwindom.a -lgem

