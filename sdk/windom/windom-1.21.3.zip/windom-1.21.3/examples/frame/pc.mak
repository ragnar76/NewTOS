#!make -f
#
# $Source: /cvsroot/windom/windom/examples/frame/pc.mak,v $
# Makefile for 'frame' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/22 19:09:32 $
#  $Revision: 1.2 $

# pure c version

# note:
# CC_PUREC must point to your pcc.ttp program
# PURECINC must point to your pure_c/include directory

CC     = $(CC_PUREC)
LNK    = $(AR_PUREC)

CFLAGS = -I$(PURECINC) -I../../include -DMODIF_XEDIT $(XCFLAGS) -P


include files.mak

.SUFFIXES:
.SUFFIXES: .c .s .o

# PCC.TTP crashes with long filename, so...
.c.o:
	cp $*.c tmppc.c
	$(CC) $(CFLAGS) -Otmppc.o tmppc.c
	mv -f tmppc.o $*.o

# PASM.TTP generates filename in UPPERCASE, so...
.s.o:
	$(AS) -OTMPPC.O $*.s
	mv TMPPC.O  $*.o

all: marrant.prg tstframe.prg wdiff.prg txtframe.prg

# a revoir...
marrant.prg : $(OBJ1)
	$(LNK) -V -S=32000 -O=$@ $(PURECLIB)/pcstart.o $(OBJ1) \
	       ../../lib/purec/windom.lib $(PURECLIB)/gem.lib $(PURECLIB)/pcstdlib.lib $(PURECLIB)/pctoslib.lib

# a revoir...
tstframe.prg : $(OBJ2)
	$(LNK) -V -S=32000 -O=$@ $(PURECLIB)/pcstart.o $(OBJ2) \
	       ../../lib/purec/windom.lib $(PURECLIB)/gem.lib $(PURECLIB)/pcstdlib.lib $(PURECLIB)/pctoslib.lib

# a revoir...
wdiff.prg : $(OBJ3)
	$(LNK) -V -S=32000 -O=$@ $(PURECLIB)/pcstart.o $(OBJ3) \
	       ../../lib/purec/windom.lib $(PURECLIB)/gem.lib $(PURECLIB)/pcstdlib.lib $(PURECLIB)/pctoslib.lib

# a revoir...
txtframe.prg : $(OBJ4)
	$(LNK) -V -S=32000 -O=$@ $(PURECLIB)/pcstart.o $(OBJ4) \
	       ../../lib/purec/windom.lib $(PURECLIB)/gem.lib $(PURECLIB)/pcstdlib.lib $(PURECLIB)/pctoslib.lib
