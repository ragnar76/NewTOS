/*
 * WDIFF: This file is a part of WinDom Developer Kit
 * Copyright (c) 2001-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/examples/frame/wdiff.c,v $
 * An example with Frame. Loading two text file in
 * two frames.
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/22 18:48:36 $
 *   $Revision: 1.1 $
 */

#ifdef __PUREC__
#include <tos.h>
#else
#include <osbind.h>
#endif

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "windom.h"

#include "dragdrop.h"
#include "viewtext.h"	/* A WinDom wrapper to display
						 * simple ascii file in a window */

int anim = 0;

static void ApTerm( void) {
	while( wglb.first) {
		ApplWrite( app.id, WM_DESTROY, wglb.first->handle, 0, 0, 0, 0);
		EvntWindom(MU_MESAG);
	}
	FrameExit();	
	ApplExit();
	exit( 0);
}

static void IconDraw( WINDOW *win) {
	INT16 x,y,w,h;
	WINDOW *frame;
	char *p;
	
	WindClear( win);
	WindGet( win, WF_WORKXYWH, &x, &y, &w, &h);
	switch( anim) {
	case 1:
		frame = FrameSearch( win, 0, 0);
		vst_color(  win->graf.handle, RED);
		p = strrchr( frame->info, '\\');
		v_gtext( win->graf.handle, x+1, y+h/2, p?(p+1):"No file");
		break;
	case 2:
		frame = FrameSearch( win, 1, 0);
		vst_color(  win->graf.handle, BLUE);
		p = strrchr( frame->info, '\\');
		v_gtext( win->graf.handle, x+1, y+h/2, p?(p+1):"No file");
		break;
	default:
		vst_color(  win->graf.handle, BLACK);
		v_gtext( win->graf.handle, x+1, y+h/2, "Frames!");
		break;
	}
}

static void TimerIcon( WINDOW *win) {
	if( win->status & WS_ICONIFY) {
		anim = anim ++ % 3	;
		snd_rdw( win);
	}
}

static void OpenText( WINDOW *win) {
	static char path[256];
	char name[64];

	if( (evnt.mbut & 0x02 || evnt.nb_click == 2) 
		&& FselInput( path, name, "*.*", "Select an ascii file ...", NULL, NULL)) {
		strcpy( win->info, path);
		strcat( win->info, name);
		
		ViewTextReCreate( win, win->info);
		WindSetStr( win, WF_INFO, win->info);
		snd_rdw( win);
	}
}

static void DragDrop( WINDOW *win) {	
	if( !(win->status & WS_ICONIFY)) {
		char file[128], name[ 128], *buff;
		int dd_hdl, dd_msg; /* pipe-handle */
		long size;
		char ext[32];

		/* on accepte le drag&drop */
		dd_hdl = ddopen( evnt.buff[7], DD_OK);
		if( dd_hdl<0)	return;	/* erreur, pipe non ouvert */
				
		/*	On envoit notre liste de prefs:
		 *	Notre liste de prefs se borne au type ARGS
		 *	qui a une signification sp�ciale: on attends
		 *	une liste de nom de fichiers dans le pipe
		 */
		memset( ext, 0, 32);
		strcpy( ext, "ARGS");
		dd_msg = ddsexts( dd_hdl, ext);
		if( dd_msg<0)	return;	/* erreur lecture du pipe */
		
		/* Lectures des infos re�us */	
		dd_msg = ddrtry( dd_hdl, name, file, ext, &size);
		if( !strncmp( ext, "ARGS", 4)) {
			/* on accepte les donn�es */
			ddreply(dd_hdl, DD_OK);
			/* On lit les "size" octets des donn�es dans le pipe */
			buff = (char*)malloc(sizeof(char)*size);
			if( Fread( dd_hdl, size, buff) == size) {
				WINDOW *frame;
				
				/* Dans quelle frame ? */
				frame = FrameFind( win, evnt.mx, evnt.my);
				if( frame) {					
					ViewTextReCreate( frame, buff);
					WindSetStr( frame, WF_INFO, buff);
					snd_rdw( frame);
				}
			} else
			/* erreur lecture pipe */
				;
			free( buff);
			ddclose( dd_hdl);	/* fin du protocole */
		} else
			ddreply(dd_hdl, DD_NAK);
		ddclose( dd_hdl);	/* fin du protocole */			 
	}
}

static void freeinfo( WINDOW *win) {
	free( win->info);
}

int main( int argc, char *argv[]){
	WINDOW *win, *frame;
	char *infoline;
		
	ApplInit();
	FrameInit();

	/* Create the main frame window */

	win = FrameCreate( NAME|MOVER|FULLER|SMALLER|CLOSER);
	WindSetStr( win, WF_NAME, "Frames are usefull no?");
	WindSetPtr( win, WF_ICONDRAW, IconDraw, NULL);
	WindSetStr( win, WF_ICONTITLE, "wdiff");
	FrameSet( win, FRAME_BORDER, 6, 0);
	FrameSet( win, FRAME_COLOR, LWHITE, 0);
	FrameSet( win, FRAME_NOBG, 1, 0);
	EvntAttach( win, AP_DRAGDROP, DragDrop);
	EvntAttach( win, WM_XTIMER, TimerIcon);	
	
	/* Create now each framed window */

	frame = ViewTextCreate( (argc>1)?argv[1]:NULL, WAT_ALL-SIZER);
	infoline = malloc(100);
	strcpy( infoline, (argc>1)?argv[1]:"No file");
	WindSetStr( frame, WF_INFO, infoline);
	EvntAttach( frame, WM_XBUTTON, OpenText);
	EvntAdd( frame, WM_DESTROY, freeinfo, EV_TOP);
	FrameAttach( win, frame, 0, 0, 100, 50, FRAME_WSCALE|FRAME_HSCALE|FRAME_SELECT);

	frame = ViewTextCreate( (argc>2)?argv[2]:NULL, WAT_ALL);
	infoline = malloc(100);
	strcpy( infoline, (argc>2)?argv[2]:"No file");
	WindSetStr( frame, WF_INFO, infoline);
	EvntAttach( frame, WM_XBUTTON, OpenText);
	EvntAdd( frame, WM_DESTROY, freeinfo, EV_TOP);
	FrameAttach( win, frame, 1, 0, 100, 50, FRAME_WSCALE|FRAME_HSCALE|FRAME_SELECT);

	/* Open the main frame at screen */
	WindOpen( win, 100, 100, 300, 300);
	FrameSet( win, FRAME_ACTIV, FrameSearch(win,0,0));

	evnt.timer = 1000;
	
	EvntAttach( NULL, AP_TERM, ApTerm);

	for( ;; ) EvntWindom( MU_MESAG|MU_BUTTON|MU_TIMER|MU_KEYBD);
}

