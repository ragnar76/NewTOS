#!make -f
#
# $Source: /cvsroot/windom/windom/examples/frame/gcc281.mak,v $
# Makefile for 'frame' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/22 19:09:32 $
#  $Revision: 1.2 $

# gcc 2.81 version

# note:
# CC_GCC281 must point to your gcc.ttp program

CC = $(CC_GCC281)

CFLAGS= -O -fomit-frame-pointer -I../../include
LDFLAGS=  -L../../lib/gcc281 -lwindom -lgem

include files.mak

all: marrant.prg tstframe.prg wdiff.prg txtframe.prg

marrant.prg : $(OBJ1)
	$(CC) -o$@ $(OBJ1) $(LDFLAGS)

tstframe.prg : $(OBJ2)
	$(CC) -o$@ $(OBJ2) $(LDFLAGS)

wdiff.prg : $(OBJ3)
	$(CC) -o$@ $(OBJ3) $(LDFLAGS)

txtframe.prg : $(OBJ4)
	$(CC) -o$@ $(OBJ4) $(LDFLAGS)
