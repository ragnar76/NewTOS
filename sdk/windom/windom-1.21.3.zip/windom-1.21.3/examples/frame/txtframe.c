/*
 * TXTFRAME: This file is a part of WinDom Developer Kit
 * Copyright (c) 2001-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/examples/frame/txtframe.c,v $
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/22 19:07:13 $
 *   $Revision: 1.1 $
 */

#include <stdlib.h>
#include "windom.h"
#include "viewtext.h"	/* A WinDom wrapper to display
						 * simple ascii file in a window */

#define SET_FLAGS 1


static void ApTerm( void) {
	while( wglb.first) {
		ApplWrite( WM_CLOSED, wglb.first->handle,0,0,0,0,0);
		EvntWindom(MU_MESAG);
	}
	FrameExit();	
	ApplExit();
	exit( 0);
}

void main( void) {
	WINDOW *win, *frame;
	
	ApplInit();
	FrameInit();
		
	win = FrameCreate( NAME|MOVER|FULLER|SMALLER|CLOSER);
	WindSetStr( win, WF_NAME, "Test Frame");
	FrameSet( win, FRAME_BORDER, 6, 0);
	FrameSet( win, FRAME_COLOR, LWHITE, 0);
	FrameSet( win, FRAME_NOBG, 1, 0);	

	frame = ViewTextCreate( "txtframe.c", WAT_ALL-SIZER);
	WindSetStr( frame, WF_INFO, "txtframe.c");
	FrameAttach( win, frame, 0, 0, 20, 50, FRAME_WSCALE|FRAME_HSCALE|FRAME_SELECT);
	
	frame = ViewTextCreate( "txtframe.c", WAT_ALL-SIZER);
	WindSetStr( frame, WF_INFO, "txtframe.c");
	FrameAttach( win, frame, 0, 1, 40, 50, FRAME_WSCALE|FRAME_HSCALE|FRAME_SELECT);

	frame = ViewTextCreate( "txtframe.c", WAT_ALL-SIZER);
	WindSetStr( frame, WF_INFO, "txtframe.c");
	FrameAttach( win, frame, 0, 2, 40, 50, FRAME_WSCALE|FRAME_HSCALE|FRAME_SELECT);

	frame = ViewTextCreate( "txtframe.c", WAT_ALL);
	WindSetStr( frame, WF_INFO, "txtframe.c");
	FrameAttach( win, frame, 1, 0, 100, 50, FRAME_WSCALE|FRAME_HSCALE|FRAME_SELECT);

	WindOpen( win, 100, 100, 300, 300);
	FrameSet( win, FRAME_ACTIV, FrameSearch(win,0,0));
	FrameSet( win, FRAME_TOPPED_ACTIV, TRUE);
	
	EvntAttach( NULL, AP_TERM, ApTerm);
	for( ;; ) EvntWindom( MU_MESAG|MU_BUTTON|MU_KEYBD|MU_TIMER);
}

