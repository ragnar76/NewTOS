#!make -f
#
# $Source: /cvsroot/windom/windom/examples/frame/sox.mak,v $
# Makefile for 'frame' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/22 19:09:32 $
#  $Revision: 1.2 $

# sozobonx version

# note:
# CC_SOX must point to your cc.ttp program

CC     = $(CC_SOX)

CFLAGS = -O -I../../include
LDFLAGS=  +L-B2 -L../../lib/sozobon -lwindom -lgem

include files.mak

all: marrant.prg tstframe.prg wdiff.prg txtframe.prg

marrant.prg : $(OBJ1)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ1) $(LDFLAGS)

tstframe.prg : $(OBJ2)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ2) $(LDFLAGS)

wdiff.prg : $(OBJ3)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ3) $(LDFLAGS)

txtframe.prg : $(OBJ4)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ4) $(LDFLAGS)
