/*
 * VIEWTEXT: This file is a part of WinDom Developer Kit
 * Copyright (c) 2001-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/examples/frame/viewtext.h,v $
 * Just display an ascii file in a WinDom window
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/22 18:48:36 $
 *   $Revision: 1.1 $
 */

#define WTXT 0x57545854L  /*'WTXT'*/

WINDOW *ViewTextCreate	( char *file, int attrib);
void    ViewTextOpen	( WINDOW *win, int x, int y, int w, int h);
void    ViewTextReCreate( WINDOW *win, char *file);
int     ViewTextSearch	( WINDOW *win, char *target, int lastpos, int capsens);
int 	ViewTextGet		( WINDOW *win, int mode, int *val);

