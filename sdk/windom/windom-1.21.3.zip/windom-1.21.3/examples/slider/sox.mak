#!make -f
#
# $Source: /cvsroot/windom/windom/examples/slider/sox.mak,v $
# Makefile for 'slider' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/11/30 12:49:30 $
#  $Revision: 1.2 $

# sozobonx version

# note:
# CC_SOX must point to your cc.ttp program

CC     = $(CC_SOX)

CFLAGS = -O -I../../include
LDFLAGS=  +L-B2 -L../../lib/sozobon -lwindom -lgem -lc

include files.mak

slider.prg : $(OBJ)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ) $(LDFLAGS)
