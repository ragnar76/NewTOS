#!make -f
#
# $Source: /cvsroot/windom/windom/examples/slider/files.mak,v $
# Makefile for 'slider' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/04/18 16:52:35 $
#  $Revision: 1.1 $

OBJ = slider.o

#eof
