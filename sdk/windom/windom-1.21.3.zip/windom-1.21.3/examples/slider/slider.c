/*
 * SLIDER: This file is a part of WinDom Developer Kit
 * Copyright (c) 1997-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/examples/slider/slider.c,v $
 * An example of Slider library
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/04/18 16:52:35 $
 *   $Revision: 1.1 $
 */

#include <stdio.h>
#include <stdlib.h>
#include "windom.h"

#include "slider.h"

void *slid1, *slid2;

static void ApTerm(void) {
	while( wglb.first) {
		ApplWrite( app.id, WM_DESTROY, wglb.first->handle, 0,0,0,0);
		EvntWindom( MU_MESAG);
	}
	free( slid1);
	RsrcXtype( 0, NULL, 0);
	RsrcFree();
	ApplExit();	
	exit( 0);
}

static void F1Close( WINDOW *win, int index) {
	/* ApplWrite ( app.id, WM_CLOSED, win->handle); */
	ApplWrite( app.id, AP_TERM, 0, 0,0,0,0);
	ObjcChange( OC_FORM, win, index, NORMAL, 1);
}

static void doslid( WINDOW *win, int mode, float value) {
	sprintf( ObjcString( FORM(win), F1_FIELD, NULL), "%04ld", (long)value);
	ObjcDraw( mode, win, F1_FIELD, 1);
}

static void doslid2( WINDOW *win, int mode, float value) {
	evnt_timer( 100);
	sprintf( ObjcString( FORM(win), C_VAL, NULL), "%2d", (int)value);
	ObjcDraw( mode, win, C_VAL, TRUE);
}

static void F1tr( WINDOW *win, int ind, int mode, void *slid) {
	static int tr = 0;
	tr = 1 - tr;
	if( tr) SlidSetUpdat( slid, SLD_IMME);
	else	SlidSetUpdat( slid, SLD_DIFF);
}

void main( void) {
	OBJECT *tree;
	WINDOW *win;
	
	ApplInit();
	RsrcLoad( "slider.rsc");
	RsrcXtype( RSRC_XTYPE, NULL, 0);
	
	rsrc_gaddr( 0, FORM1, &tree);
	win = FormCreate( tree, NAME|MOVER|CLOSER, NULL, "Slider & WinDom", NULL, 1, 0);

	slid1 = SlidCreate( 0, 1000, 1, 10, 0, SLD_VERT, SLD_DIFF);
	SlidAttach( slid1, OC_FORM, win, S_UP, S_PG, S_SL, S_DN);
	SlidSetFunc( slid1, doslid, NULL);
	SlidSetSize( slid1, 300);
	ObjcAttach( OC_FORM, win, F1_TR, BIND_FUNC, F1tr, slid1);

	slid2 = SlidCreate( 0, 99, 1, 10, 0, SLD_VERT, SLD_IMME);
	SlidAttach( slid2, OC_FORM, win, C_UP, -1, -1, C_DN);
	SlidSetFunc( slid2, doslid2, NULL);
	SlidSetValue( slid2, 10);
	
	ObjcAttach( OC_FORM, win, F1_CLOSE, BIND_FUNC, F1Close);

	EvntAttach( NULL, AP_TERM, ApTerm);
	/* Boucle Principale */
	for( ;;) EvntWindom( MU_MESAG);
}
