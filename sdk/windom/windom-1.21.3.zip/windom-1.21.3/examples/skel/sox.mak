#!make -f
#
# $Source: /cvsroot/windom/windom/examples/skel/sox.mak,v $
# Makefile for 'skel' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/10/22 18:13:35 $
#  $Revision: 1.1 $

# sozobonx version

# note:
# CC_SOX must point to your cc.ttp program

CC     = $(CC_SOX)

CFLAGS = -O 
LDFLAGS=  +L-B2 -lwindom -lgem

include files.mak

skel.prg : $(OBJ)
	$(CC) -o$@ -scrt0.o -O +L-p $(OBJ) $(LDFLAGS)
