#!make -f
#
# $Source: /cvsroot/windom/windom/examples/skel/gcc281.mak,v $
# Makefile for 'skel' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/10/22 18:13:35 $
#  $Revision: 1.1 $

# gcc 2.81 version

# note:
# CC_GCC281 must point to your gcc.ttp program

CC = $(CC_GCC281)

CFLAGS= -O -fomit-frame-pointer 
LDFLAGS=  -lwindom -lgem

include files.mak

skel.prg : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS)
