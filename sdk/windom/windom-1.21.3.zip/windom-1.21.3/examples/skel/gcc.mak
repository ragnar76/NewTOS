#!make -f
#
# $Source: /cvsroot/windom/windom/examples/skel/gcc.mak,v $
# Makefile for 'skel' example program
# 
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/11/30 20:17:23 $
#  $Revision: 1.2 $

# gcc version

ifeq ($(CROSS),yes)
CC = m68k-atari-mint-gcc
else
CC = gcc
endif

WARN = \
        -Wall \
        -Wmissing-prototypes \
        -Winline \
        -Wshadow \
        -Wpointer-arith \
        -Wcast-qual \
        -Waggregate-return

CFLAGS += -O2 -fomit-frame-pointer $(WARN)

include files.mak

skel.prg : $(OBJ)
	$(CC) -o$@ $(OBJ) $(LDFLAGS) -lwindom -lgem

