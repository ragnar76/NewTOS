#!make -f
#
# $Source: /cvsroot/windom/windom/examples/skel/files.mak,v $
# Makefile for 'skel' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/10/22 18:13:35 $
#  $Revision: 1.1 $

OBJ = ex-skel.o

#eof
