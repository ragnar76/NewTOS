#!make -f
#
# $Source: /cvsroot/windom/windom/examples/multifrm/files.mak,v $
# Makefile for 'multifrm' example program
#
# CVS Info :
#  $Author: bercegeay $
#  $Date: 2003/03/28 16:16:08 $
#  $Revision: 1.1 $

OBJ = multifrm.o

#eof
