/*
 * MULTIFRM: This file is a part of WinDom Developer Kit
 * Copyright (c) 1997-2003 Dominique Bereziat 
 *
 * $Source: /cvsroot/windom/windom/examples/multifrm/multifrm.c,v $
 * Exemple de gestion de formulaire multiple
 *
 * CVS info:
 *   $Author: bercegeay $
 *   $Date: 2003/03/28 16:16:08 $
 *   $Revision: 1.1 $
 */

#include <stddef.h>
#include "windom.h"
#include "multifrm.h"

/*
 *	Pour utiliser les objets �tendues de look calepin, il faut attribuer
 *	aux boutons radio et aux fond des formulaires le type �tendu 16.
 *	Les fond de formulaires ne doivent pas �tre radio. Enfin les boutons 
 *	radios doivent �tre dessin� apr�s les fond des formulaire (donc ils
 *	devraient avec un indx plus grand que ceux des fonds...).
 *	le bit FLAG8 des �tats des objets double la tailles des cadres. Enfin
 *	le bit Draw3D est pris en compte.
 */

static void closeform( WINDOW *win, int index) {
	ObjcChange( OC_FORM, win, index, ~SELECTED, TRUE);
	ApplWrite( app.id, WM_DESTROY, win->handle, 0,0,0,0);
}

int main(void) {
	OBJECT *tree;
	WINDOW *win;
	int frms[] = {FOND1, FOND2, FOND3};
	int buts[] = {BUT1, BUT2, BUT3};

	ApplInit();
	RsrcLoad( "multifrm.rsc");
	RsrcXtype( 1, NULL, 0);
	rsrc_gaddr( 0, FORM1, &tree);

	win = FormCreate( tree, WAT_FORM, NULL, "Formulaire multiple", 
					  NULL, TRUE, FALSE);
	FormThumb( win, frms, buts, 3);
	ObjcAttach( OC_FORM, win, OK, BIND_FUNC, closeform);
	ObjcAttach( OC_FORM, win, CANCEL, BIND_FUNC, closeform);

	while( wglb.first) EvntWindom(MU_MESAG);
	RsrcXtype( 0, NULL, 0);
	RsrcFree();
	ApplExit();
	return 0;
}
