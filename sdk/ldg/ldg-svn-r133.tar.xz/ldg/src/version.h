/* ---------------------------------------------------------
 *	Librairie Dynamique GEM
 *	Olivier Landemarre, Dominique B�r�ziat, Arnaud Bercegeay
 *	All rights reserved 1997-2003
 * ---------------------------------------------------------
 * $Id$
 */

/*
 *	Chaque mainteneur d'une version
 *	corrige la partie qui le concerne
 */

/* version Librairie de d�veloppement */
#define VERSION	"2.35"
#define LDG_NUM 	0x0235

#ifdef __PUREC__ 
#define LDG_NAME	VERSION __DATE__ " - Pure C"
#endif
#ifdef __VBCC__ 
#define LDG_NAME	VERSION __DATE__ " - VBCC"
#endif
#ifdef __SOZOBONX__
#define LDG_NAME	VERSION __DATE__  "-  Sozobon X"
#endif
#ifdef __GNUC__
#define LDG_NAME	VERSION __DATE__ " - GCC"
/* VERSION " Compiled by " __GNUC__ __DATE__ */
#endif


/* TSR */

#define TSR_VERSION_TEXT	"2.35"
#define	TSR_VERSION_NUMBER	0x0235

/* Manager */

#define MGR_VERSION_TEXT	"2.00"
#define MGR_VERSION_NUMBER	0x0200

/* D�mon */

#define LDGD_VERSION_TEXT   "1.11"

